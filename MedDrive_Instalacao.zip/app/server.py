import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, APIRouter, Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.cors import CORSMiddleware
import os
import logging
from pathlib import Path


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection (or JSON-file store when DB_MODE=file)
from lib.db import FILE_MODE, client, db, ensure_indexes  # noqa: E402
from lib import filestore  # noqa: E402
from routers.clinic import router as clinic_router  # noqa: E402
from routers.portable import router as portable_router  # noqa: E402
from routers.license import router as license_router  # noqa: E402
from routers.backup import router as backup_router  # noqa: E402
from routers.agenda import router as agenda_router  # noqa: E402
from routers.finance import router as finance_router  # noqa: E402
from routers.terms import router as terms_router  # noqa: E402


@asynccontextmanager
async def lifespan(app: FastAPI):
    if FILE_MODE:
        await filestore.load_all()
        if await db.workplaces.count_documents({}) == 0 and await db.medications.count_documents({}) == 0:
            from seed import seed
            await seed()
            await filestore.save(filestore.COLLECTIONS)
        elif not (filestore.data_dir() / "guidance.json").exists():
            # older pendrive data (before quick guidance existed): add the default phrases once
            from seed import GUIDANCE, seed_if_empty
            await seed_if_empty("guidance", GUIDANCE)
            await filestore.save(["guidance"])
        if not (filestore.data_dir() / "rx_templates.json").exists():
            # older pendrive data (before ready-made prescriptions existed): add the examples once
            from seed import seed_protocols
            await seed_protocols()
            await filestore.save(["rx_templates", "exam_groups"])
    from catalog import apply_catalog  # built-in medication/exam catalog: adds missing items once per version
    added = await apply_catalog()
    if any(added.values()):
        logging.getLogger(__name__).info("Catálogo aplicado: %s", added)
    app.state.index_task = asyncio.create_task(ensure_indexes())  # background: a big index build must not block boot
    yield
    try:
        client.close()
    except Exception:
        pass


app = FastAPI(lifespan=lifespan)

api_router = APIRouter(prefix="/api")


@api_router.get("/")
async def root():
    return {"message": "MedDrive API"}


api_router.include_router(clinic_router)
api_router.include_router(portable_router)
api_router.include_router(license_router)
api_router.include_router(backup_router)
api_router.include_router(agenda_router)
api_router.include_router(finance_router)
api_router.include_router(terms_router)

if FILE_MODE:
    @app.middleware("http")
    async def persist_writes(request: Request, call_next):
        response = await call_next(request)
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and response.status_code < 400:
            await filestore.save_for_path(request.url.path)
        return response

# Portable build: serve the built frontend (SPA) from the same process.
STATIC_DIR = os.environ.get("STATIC_DIR")
if STATIC_DIR and Path(STATIC_DIR).is_dir():
    static_root = Path(STATIC_DIR).resolve()
    if (static_root / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=static_root / "assets"), name="assets")

    @app.exception_handler(StarletteHTTPException)
    async def spa_fallback(request: Request, exc: StarletteHTTPException):
        path = request.url.path
        if exc.status_code == 404 and request.method == "GET" and not path.startswith("/api"):
            f = (static_root / path.lstrip("/")).resolve()
            if path != "/" and f.is_file() and static_root in f.parents:
                return FileResponse(f)
            return FileResponse(static_root / "index.html")
        return await http_exception_handler(request, exc)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Include the router in the main app — keep this the last statement
app.include_router(api_router)
