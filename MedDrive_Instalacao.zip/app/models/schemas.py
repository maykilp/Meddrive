"""Pydantic models — mirrored by hand in frontend/src/lib/types.ts."""

import uuid
from datetime import datetime, timezone
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator


def _id() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Stored(BaseModel):
    id: str = Field(default_factory=_id)
    created_at: datetime = Field(default_factory=_now)

    @field_validator("created_at")
    @classmethod
    def _aware(cls, v: datetime) -> datetime:
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v


# ---------- Workplaces ----------
class AgendaConfig(BaseModel):  # fixed slots of one workplace
    weekdays: list[int] = [0, 1, 2, 3, 4]  # 0 = Monday … 6 = Sunday
    start: str = "08:00"
    end: str = "17:00"
    slot_minutes: int = Field(default=20, ge=5, le=240)
    break_start: str = ""  # e.g. lunch 12:00–13:00 ("" = none)
    break_end: str = ""


class WorkplaceIn(BaseModel):
    name: str = Field(min_length=1)
    address: str = ""
    phone: str = ""
    logo: str = ""  # data URL (image) shown on documents
    agenda_enabled: bool = False  # show the Agenda for this workplace
    agenda: AgendaConfig = AgendaConfig()
    price_consulta: float = Field(default=0, ge=0)  # R$ charged per attendance at this workplace
    price_retorno: float = Field(default=0, ge=0)


class Workplace(Stored, WorkplaceIn):
    pass


# ---------- Patients ----------
class PatientIn(BaseModel):
    name: str = Field(min_length=1)
    birth_date: str = ""  # YYYY-MM-DD
    weight_kg: Optional[float] = None
    sex: str = ""
    cpf: str = ""
    phone: str = ""
    address: str = ""
    pregnant: bool = False  # on-screen alerts only, never printed
    breastfeeding: bool = False
    attention: bool = False  # "paciente difícil" — on-screen warning only, never printed
    attention_note: str = ""
    health_plan_id: str = ""  # plano de saúde habitual ("" = particular)
    plan_card: str = ""  # número da carteirinha
    allergies: str = ""
    notes: str = ""


class Patient(Stored, PatientIn):
    pass


# ---------- Medications ----------
class MedicationIn(BaseModel):
    name: str = Field(min_length=1)
    presentation: str = ""
    route: str = "Via oral"
    quantity: str = ""
    instructions: str = ""  # default posology (adult / without weight)
    notes: str = ""  # appended to computed pediatric posology
    action_verb: str = ""  # start of computed posology ("Aplicar", "Inalar"…); empty = derived from route
    pediatric: bool = False
    dose_mode: Literal["mg_kg_dose", "mg_kg_day"] = "mg_kg_dose"
    dose_mg_per_kg: Optional[float] = None
    doses_per_day: Optional[int] = None
    conc_mg: Optional[float] = None
    conc_ml: Optional[float] = None
    max_dose_mg: Optional[float] = None
    drops_per_ml: Optional[float] = None
    duration_days: Optional[int] = None
    pinned: bool = False
    controlled: bool = False  # goes on the 2-copy "Receituário de Controle Especial"
    # shown on screen only (never printed)
    pregnancy_category: Literal["", "A", "B", "C", "D", "X"] = ""
    lactation: Literal["", "compativel", "cautela", "contraindicado"] = ""
    pregnancy_lactation_notes: str = ""


class Medication(Stored, MedicationIn):
    usage_count: int = 0


# ---------- Exams ----------
class ExamIn(BaseModel):
    name: str = Field(min_length=1)
    category: str = ""
    preparation: str = ""


class Exam(Stored, ExamIn):
    pass


# ---------- Quick guidance (orientações rápidas) ----------
class GuidanceIn(BaseModel):
    name: str = Field(min_length=1)  # the guidance text itself


class Guidance(Stored, GuidanceIn):
    pass


# ---------- Ready-made prescriptions & exam groups ----------
class RxItemOverride(BaseModel):  # protocol-specific posology for one medication (empty = use the medication's own)
    instructions: str = ""
    quantity: str = ""


class RxTemplateIn(BaseModel):
    name: str = Field(min_length=1)  # e.g. "Amigdalite"
    medication_ids: list[str] = []
    notes: str = ""  # optional general guidance added to the prescription
    overrides: dict[str, RxItemOverride] = {}  # medication_id → posology used by this protocol


class RxTemplate(Stored, RxTemplateIn):
    pinned: bool = False  # fixed in the Nova Receita bar (max. 5)
    uses: int = 0  # times applied in Nova Receita


class ExamGroupIn(BaseModel):
    name: str = Field(min_length=1)  # e.g. "Check-up adulto"
    exam_ids: list[str] = []


class ExamGroup(Stored, ExamGroupIn):
    pinned: bool = False
    uses: int = 0


class PinIn(BaseModel):
    pinned: bool


# ---------- Settings ----------
class Specialty(BaseModel):
    name: str = ""
    rqe: str = ""


class Settings(BaseModel):  # stored document (key="main")
    doctor_name: str = ""
    crm: str = ""
    crm_uf: str = ""
    specialty: str = ""  # legacy single specialty (pre-RQE); migrated into `specialties`
    specialties: list[Specialty] = []
    active_workplace_id: Optional[str] = None
    doctor_sig: str = ""  # Ed25519 signature of the doctor data (see lib/admin_auth.py)


class SettingsOut(BaseModel):
    doctor_name: str = ""
    crm: str = ""
    crm_uf: str = ""
    specialty: str = ""
    specialties: list[Specialty] = []
    active_workplace_id: Optional[str] = None
    doctor_verified: bool = False  # signature valid
    doctor_tampered: bool = False  # data changed outside the system → documents blocked


class BackupConfigIn(BaseModel):  # PUT /api/backup/config
    email: str  # mailbox that logs in and sends
    password: str = ""  # app password; empty = keep the saved one
    send_to: str = ""  # optional other recipient (default: email)
    smtp_host: str = ""  # empty = auto from the e-mail domain
    smtp_port: int = 0
    smtp_security: Literal["ssl", "starttls", "none"] = "ssl"


class BackupConfigOut(BaseModel):
    email: str = ""
    send_to: str = ""
    smtp_host: str = ""
    smtp_port: int = 0
    smtp_security: str = "ssl"
    has_password: bool = False
    last_backup_at: str = ""
    last_backup_method: str = ""  # email | download
    due: bool = True  # no backup in the last 30 days
    days_since: Optional[int] = None


class BackupResult(BaseModel):
    ok: bool
    message: str
    filename: str = ""
    size: int = 0
    counts: dict[str, int] = {}


class RestoreIn(BaseModel):
    filename: str = ""
    data_b64: str
    confirm: bool = False  # the UI asks before replacing all data


class LicenseStatus(BaseModel):  # GET /api/license/status
    state: Literal["ok", "warning", "grace", "expired", "blocked"]
    reason: str  # ok | expiring | postponed | expired | expired_final | not_found | no_crm | unverified | tampered | clock
    allowed: bool
    message: str
    name: str = ""
    crm: str = ""
    expires: str = ""  # YYYY-MM-DD from the sheet
    days_left: Optional[int] = None
    grace_until: str = ""
    postpones_used: int = 0
    postpones_left: int = 0
    can_postpone: bool = False
    last_check: str = ""  # ISO datetime of the last successful online check
    contact: str = ""
    offline: bool = False  # this request tried to check online and had no internet


class DoctorIn(BaseModel):
    doctor_name: str = ""
    crm: str = ""
    crm_uf: str = ""
    specialties: list[Specialty] = []


class ActiveWorkplaceIn(BaseModel):
    active_workplace_id: str = Field(min_length=1)


# ---------- Documents (history) ----------
class DocItem(BaseModel):
    medication_id: Optional[str] = None
    name: str = Field(min_length=1)
    presentation: str = ""
    route: str = ""
    quantity: str = ""
    instructions: str = ""
    controlled: bool = False
    sheet: int = Field(default=1, ge=1, le=10)  # which prescription sheet (Receita 1, 2…) it prints on


class DocExam(BaseModel):
    exam_id: Optional[str] = None
    name: str = Field(min_length=1)
    preparation: str = ""


class Referral(BaseModel):
    destination: str = ""
    specialty: str = ""
    reason: str = ""
    guidance: str = ""


class Certificate(BaseModel):
    kind: Literal["afastamento", "comparecimento", "acompanhante"] = "afastamento"
    start_date: str = ""  # YYYY-MM-DD
    period: Literal["", "manha", "tarde", "noite"] = ""  # partial first day
    days: int = Field(default=0, ge=0, le=365)  # full days after the partial period
    time_from: str = ""  # HH:MM
    time_to: str = ""
    companion_name: str = ""
    companion_doc: str = ""
    cid: str = ""
    cid_authorized: bool = False


class ReportDoc(BaseModel):  # laudo médico (text already filled with the patient's data)
    title: str = "Laudo Médico"
    body: str = ""
    cid: str = ""
    cid_authorized: bool = False
    days: int = Field(default=0, ge=0, le=730)
    start_date: str = ""  # YYYY-MM-DD
    quesitos: bool = False  # print the INSS expert-exam block
    q_diagnostico: str = ""
    q_limitacoes: str = ""
    q_tempo: str = ""
    q_tratamento: str = ""


class ReportTemplateIn(BaseModel):  # modelo de laudo; body uses {NOME} {DOCUMENTO} {IDADE} {NASCIMENTO} {DATA} {CID} {DIAS}
    name: str = Field(min_length=1)
    category: str = ""
    body: str = ""
    cid: str = ""  # suggested
    days: int = Field(default=0, ge=0, le=730)  # suggested


class ReportTemplate(Stored, ReportTemplateIn):
    pass


class ReferralTemplateIn(BaseModel):  # modelo de encaminhamento; texts accept {NOME} {DOCUMENTO} {IDADE} {NASCIMENTO} {DATA}
    name: str = Field(min_length=1)
    specialty: str = ""
    destination: str = ""
    reason: str = ""
    guidance: str = ""


class ReferralTemplate(Stored, ReferralTemplateIn):
    pass


ClinicalField = Literal["history", "physical_exam", "conduct"]


class ClinicalPhraseIn(BaseModel):  # frase pronta da história clínica (sem dados do paciente)
    name: str = Field(min_length=1, max_length=40)  # short chip label
    field: ClinicalField
    text: str = Field(min_length=1)


class ClinicalPhrase(Stored, ClinicalPhraseIn):
    pass


class WorkplaceSnap(BaseModel):
    id: str = ""
    name: str = ""
    address: str = ""
    phone: str = ""
    logo: str = ""


class DoctorSnap(BaseModel):
    doctor_name: str = ""
    crm: str = ""
    crm_uf: str = ""
    specialty: str = ""
    specialties: list[Specialty] = []


class ClinicalNote(BaseModel):  # prontuário do atendimento — nunca impresso
    history: str = ""  # história clínica
    physical_exam: str = ""  # exame físico
    conduct: str = ""  # conduta


DocType = Literal["receita", "exames", "encaminhamento", "atestado", "laudo", "atendimento"]


class DocumentIn(BaseModel):
    type: DocType
    patient_id: Optional[str] = None
    patient_name: str = Field(min_length=1)
    patient_age: str = ""
    patient_weight: Optional[float] = None
    patient_address: str = ""
    items: list[DocItem] = []
    exams: list[DocExam] = []
    referral: Optional[Referral] = None
    certificate: Optional[Certificate] = None
    report: Optional[ReportDoc] = None
    clinical: Optional[ClinicalNote] = None  # saved only, never printed
    notes: str = ""  # general notes (printed on the last receita)
    sheet_notes: dict[str, str] = {}  # "2" -> notes printed on Receita 2 only
    appointment_id: Optional[str] = None  # agenda appointment this attendance came from (→ status "atendido")


class Document(Stored, DocumentIn):
    date: str
    workplace: WorkplaceSnap = WorkplaceSnap()
    doctor: DoctorSnap = DoctorSnap()


# ---------- Agenda ----------
AppointmentStatus = Literal["agendado", "aguardando", "atendido", "faltou", "cancelado"]
DATE_RE = r"^\d{4}-\d{2}-\d{2}$"
TIME_RE = r"^\d{2}:\d{2}$"


class AppointmentIn(BaseModel):
    workplace_id: str = Field(min_length=1)
    patient_id: str = Field(min_length=1)  # registered patients only
    date: str = Field(pattern=DATE_RE)
    time: str = Field(pattern=TIME_RE)
    kind: Literal["consulta", "retorno"] = "consulta"
    encaixe: bool = False  # outside the grid / over an occupied or blocked slot
    notes: str = ""
    price: Optional[float] = Field(default=None, ge=0)  # None = workplace/plan price for the kind (desconto/cortesia otherwise)
    payer: Literal["particular", "plano"] = "particular"
    health_plan_id: str = ""  # required when payer == "plano"


class Appointment(Stored, AppointmentIn):
    patient_name: str = ""
    patient_phone: str = ""
    health_plan_name: str = ""  # snapshot of the plan name
    status: AppointmentStatus = "agendado"
    document_id: str = ""  # set when the attendance is saved from the agenda
    paid: bool = False
    payment_method: str = ""  # dinheiro | pix | cartao | convenio | outro
    paid_at: str = ""  # YYYY-MM-DD
    reminder_sent: bool = False  # WhatsApp confirmation already sent (lembretes em lote)


class AppointmentStatusIn(BaseModel):
    status: AppointmentStatus


class AgendaBlockIn(BaseModel):  # closed period (vacation, lunch, meeting); start "" = whole day
    workplace_id: str = Field(min_length=1)
    date: str = Field(pattern=DATE_RE)
    start: str = ""
    end: str = ""
    reason: str = ""


class AgendaBlock(Stored, AgendaBlockIn):
    pass


# ---------- Financeiro ----------
PaymentMethod = Literal["dinheiro", "pix", "cartao", "convenio", "outro"]


class PaymentIn(BaseModel):  # PATCH /api/appointments/{id}/payment (allowed on past days)
    paid: bool
    payment_method: Literal["", "dinheiro", "pix", "cartao", "convenio", "outro"] = ""


class FinanceEntryIn(BaseModel):  # lançamento avulso (ganho fora da agenda ou despesa)
    kind: Literal["receita", "despesa"]
    date: str = Field(pattern=DATE_RE)
    description: str = Field(min_length=1)
    amount: float = Field(gt=0)
    workplace_id: str = ""  # "" = geral
    payment_method: Literal["", "dinheiro", "pix", "cartao", "convenio", "outro"] = ""


class FinanceEntry(Stored, FinanceEntryIn):
    recurring_id: str = ""  # generated from a despesa fixa


class RecurringExpenseIn(BaseModel):  # despesa fixa: enters by itself every month on `day`
    description: str = Field(min_length=1)
    amount: float = Field(gt=0)
    day: int = Field(default=5, ge=1, le=28)
    workplace_id: str = ""
    active: bool = True


class RecurringExpense(Stored, RecurringExpenseIn):
    start_month: str = ""  # YYYY-MM (first month generated)
    generated_months: list[str] = []  # months already launched (deleting an entry does not recreate it)


class ReceiptData(BaseModel):  # GET /api/appointments/{id}/receipt
    appointment: "Appointment"
    workplace: "Workplace"
    patient_cpf: str = ""
    doctor_name: str = ""
    crm: str = ""
    crm_uf: str = ""
    amount: float = 0  # value of the attendance (price / plan / workplace)


class GoalIn(BaseModel):
    goal: float = Field(ge=0)


class FinanceItem(BaseModel):  # attended appointment with its value
    id: str
    date: str
    time: str
    patient_id: str
    patient_name: str
    workplace_id: str
    workplace_name: str
    kind: str
    amount: float
    paid: bool
    payment_method: str
    paid_at: str
    payer: str = "particular"
    health_plan_id: str = ""
    health_plan_name: str = ""


class FinanceBucket(BaseModel):
    key: str  # month "YYYY-MM", workplace id or payment method
    label: str
    received: float = 0
    receivable: float = 0
    expenses: float = 0
    count: int = 0  # attendances in the bucket


class FinanceSummary(BaseModel):
    date_from: str
    date_to: str
    received: float  # paid appointments + receitas avulsas
    receivable: float  # attended, not paid yet
    expenses: float
    profit: float  # received - expenses
    attended: int
    goal: float
    goal_month: str  # YYYY-MM the goal bar refers to (month of date_to)
    goal_month_received: float
    items: list[FinanceItem]
    entries: list[FinanceEntry]
    by_month: list[FinanceBucket]  # 12 months ending at date_to
    by_workplace: list[FinanceBucket]
    by_method: list[FinanceBucket]
    by_plan: list[FinanceBucket]  # "particular" + each plano de saúde (key = plan id)


class SettleIn(BaseModel):  # dar baixa em lote nos atendimentos de um plano
    month: str = Field(pattern=r"^\d{4}-\d{2}$")
    workplace_id: str = ""


class SettleOut(BaseModel):
    count: int
    total: float



class MonthlyReceipt(BaseModel):  # GET /api/finance/monthly-receipt — all paid attendances of a patient in a month, one workplace
    month: str  # YYYY-MM
    patient_id: str
    patient_name: str
    patient_cpf: str = ""
    workplace: "Workplace"
    items: list[FinanceItem]
    total: float
    doctor_name: str = ""
    crm: str = ""
    crm_uf: str = ""


ReceiptData.model_rebuild()
MonthlyReceipt.model_rebuild()


# ---------- Planos de saúde ----------
class PlanPrice(BaseModel):  # value the plan pays at one workplace (overrides the default)
    workplace_id: str = Field(min_length=1)
    price_consulta: float = Field(default=0, ge=0)
    price_retorno: float = Field(default=0, ge=0)


class HealthPlanIn(BaseModel):
    name: str = Field(min_length=1)
    price_consulta: float = Field(default=0, ge=0)  # default for every workplace
    price_retorno: float = Field(default=0, ge=0)
    workplace_prices: list[PlanPrice] = []
    active: bool = True
    notes: str = ""


class HealthPlan(Stored, HealthPlanIn):
    pass


# ---------- Termo de uso ----------
class TermsSection(BaseModel):
    title: str
    body: list[str]


class TermsAcceptIn(BaseModel):
    version: str = Field(min_length=1)
    name: str = Field(min_length=3, max_length=120)  # full name typed by the doctor
    crm: str = Field(default="", max_length=20)
    crm_uf: str = Field(default="", max_length=2)
    agree: bool = False


class TermsAcceptance(Stored):  # created_at = date/time of the acceptance (UTC)
    version: str
    name: str
    crm: str = ""
    crm_uf: str = ""


class TermsOut(BaseModel):
    version: str
    date: str
    title: str
    sections: list[TermsSection]
    accepted: bool
    acceptance: Optional[TermsAcceptance] = None
    history: list[TermsAcceptance] = []
