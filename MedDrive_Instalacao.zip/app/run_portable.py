"""Portable launcher (Windows pendrive). Runs the app offline on this computer and opens the browser.

Self-update: the app downloads a new version into ../atualizacao and stops the server; this script
then starts a fresh copy of itself (--apply-update) that waits for this process to exit, copies the
new files over the old ones (the `dados` folder is never touched) and starts the new version.
"""

import filecmp
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

APP = Path(__file__).resolve().parent
ROOT = APP.parent
STAGE = ROOT / "atualizacao"

os.environ.setdefault("DB_MODE", "file")
os.environ.setdefault("DATA_DIR", str(ROOT / "dados"))
os.environ.setdefault("STATIC_DIR", str(APP / "static"))
os.environ.setdefault("APP_TZ", "America/Sao_Paulo")
os.environ.setdefault("MONGO_URL", "mongodb://unused")
os.environ.setdefault("DB_NAME", "meddrive")
os.environ.setdefault("CORS_ORIGINS", "http://127.0.0.1")

sys.path.insert(0, str(APP))

PORT = 8765

BANNER = r"""
==================================================================
   __  __          _ ____       _
  |  \/  | ___  __| |  _ \ _ __(_)_   _____
  | |\/| |/ _ \/ _` | | | | '__| \ \ / / _ \
  | |  | |  __/ (_| | |_| | |  | |\ V /  __/
  |_|  |_|\___|\__,_|____/|_|  |_| \_/ \___|

   Receituario medico  -  versao pendrive (offline)
=================================================================="""


def already_running(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/", timeout=1) as r:
            return b"MedDrive" in r.read()
    except Exception:
        return False


def port_free(port: int, reuse: bool = False) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if reuse and os.name != "nt":  # like uvicorn: ignore TIME_WAIT left by the previous process
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def open_when_ready(url: str) -> None:
    for _ in range(60):
        try:
            urllib.request.urlopen(url + "/api/", timeout=1)
            break
        except Exception:
            time.sleep(0.5)
    webbrowser.open(url)


def wait_process_exit(pid: int, timeout: float = 30) -> None:
    if os.name == "nt":
        import ctypes

        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if h:
            k32.WaitForSingleObject(h, int(timeout * 1000))
            k32.CloseHandle(h)
    else:
        end = time.time() + timeout
        while time.time() < end:
            try:
                os.kill(pid, 0)
            except OSError:
                break
            time.sleep(0.2)
    time.sleep(0.5)


def apply_update() -> None:
    """Copy the staged new version over the installation. Skips `dados/` and the running Python core."""
    src = STAGE / "MedDrive"
    if not (STAGE / "READY").is_file() or not (src / "app" / "server.py").is_file():
        shutil.rmtree(STAGE, ignore_errors=True)
        return
    print("Aplicando atualizacao do MedDrive... aguarde.")
    shutil.rmtree(APP / "static", ignore_errors=True)  # old hashed assets
    failed = 0
    for f in src.rglob("*"):
        if not f.is_file():
            continue
        rel = f.relative_to(src)
        if rel.parts[0] == "dados":
            continue
        if rel.parts[0] == "python" and rel.parts[1:3] != ("Lib", "site-packages"):
            continue  # python.exe / dll are in use by this process
        dst = ROOT / rel
        try:
            if dst.is_file() and filecmp.cmp(f, dst, shallow=False):
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)
        except OSError:
            failed += 1
    shutil.rmtree(STAGE, ignore_errors=True)
    print("Atualizacao concluida." + (f" ({failed} arquivo(s) em uso nao foram trocados)" if failed else ""))


def main() -> None:
    restart_port = None
    if len(sys.argv) >= 4 and sys.argv[1] == "--apply-update":
        wait_process_exit(int(sys.argv[2]))
        restart_port = int(sys.argv[3])
    if STAGE.exists():
        apply_update()
    os.chdir(APP)

    if restart_port is None and already_running(PORT):
        print("O MedDrive ja esta aberto. Abrindo o navegador...")
        webbrowser.open(f"http://127.0.0.1:{PORT}")
        return
    port = None
    if restart_port:  # keep the same address so the open browser tab reconnects
        for _ in range(30):
            if port_free(restart_port, reuse=True):
                port = restart_port
                break
            time.sleep(0.5)
    if port is None:
        port = next((p for p in range(PORT, PORT + 20) if port_free(p)), None)
    if port is None:
        print("Nenhuma porta livre encontrada (8765-8784).")
        return
    url = f"http://127.0.0.1:{port}"
    print(BANNER)
    print(f"   Endereco: {url}")
    print(f"   Dados salvos em: {os.environ['DATA_DIR']}")
    print("   Para encerrar, feche esta janela.")
    print("=" * 66)
    if restart_port is None:  # after an update the open browser tab reloads by itself
        threading.Thread(target=open_when_ready, args=(url,), daemon=True).start()

    import uvicorn
    from lib import updater
    from server import app

    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    updater.SERVER = server
    server.run()

    if (STAGE / "READY").is_file():
        print("Reiniciando o MedDrive para concluir a atualizacao...")
        subprocess.Popen([sys.executable, str(APP / "run_portable.py"), "--apply-update", str(os.getpid()), str(port)],
                         cwd=str(ROOT))


if __name__ == "__main__":
    main()
