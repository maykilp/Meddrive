"""Login/logout for the protected Settings area (httpOnly session cookie)."""

from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel

from lib import admin_auth

router = APIRouter(prefix="/admin")


class LoginIn(BaseModel):
    username: str
    password: str


class SessionOut(BaseModel):
    authenticated: bool


@router.post("/login", response_model=SessionOut)
async def login(body: LoginIn, request: Request, response: Response):
    key = admin_auth.check_credentials(body.username, body.password)
    if key is None:
        raise HTTPException(status_code=401, detail="Usuário ou senha incorretos")
    token = admin_auth.create_session(key)
    secure = request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
    response.set_cookie(
        admin_auth.COOKIE, token, httponly=True, samesite="lax", secure=secure,
        max_age=admin_auth.SESSION_TTL, path="/api",
    )
    return SessionOut(authenticated=True)


@router.post("/logout", response_model=SessionOut)
async def logout(request: Request, response: Response):
    admin_auth.drop_session(request.cookies.get(admin_auth.COOKIE))
    response.delete_cookie(admin_auth.COOKIE, path="/api")
    return SessionOut(authenticated=False)


@router.get("/session", response_model=SessionOut)
async def session(request: Request):
    return SessionOut(authenticated=admin_auth.session_key(request) is not None)
