"""Licence status / manual check / 7-day postponement (see lib/license.py)."""

from fastapi import APIRouter, HTTPException

from lib import license
from models.schemas import LicenseStatus
from routers.clinic import get_settings

router = APIRouter(prefix="/license")


@router.get("/status", response_model=LicenseStatus)
async def get_status():
    s = await get_settings()
    return LicenseStatus(**await license.status(s.crm))


@router.post("/check", response_model=LicenseStatus)
async def check_now():
    s = await get_settings()
    return LicenseStatus(**await license.status(s.crm, force=True))


@router.post("/postpone", response_model=LicenseStatus)
async def postpone():
    s = await get_settings()
    res = await license.postpone(s.crm)
    if res is None:
        raise HTTPException(status_code=400, detail="Não é possível postergar a licença agora")
    return LicenseStatus(**res)
