"""Agenda per workplace: appointments (fixed slots + encaixe) and blocked periods."""

from fastapi import APIRouter, HTTPException

from lib.dates import today_iso
from lib.db import db
from routers.finance import amount_for
from models.schemas import AgendaBlock, AgendaBlockIn, Appointment, AppointmentIn, AppointmentStatusIn, PaymentIn, ReceiptData, Workplace

router = APIRouter()


def _range_filter(workplace_id: str, date_from: str, date_to: str) -> dict:
    filt: dict = {}
    if workplace_id:
        filt["workplace_id"] = workplace_id
    rng: dict = {}
    if date_from:
        rng["$gte"] = date_from
    if date_to:
        rng["$lte"] = date_to
    if rng:
        filt["date"] = rng
    return filt


PAST_MSG = "Dias anteriores ficam só para visualização — não é possível alterar ou agendar"


def _not_past(date: str) -> None:
    if date < today_iso():
        raise HTTPException(status_code=400, detail=PAST_MSG)


async def _existing(col, id: str, label: str) -> dict:
    """Loads an appointment/block and refuses changes to past days."""
    doc = await col.find_one({"id": id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail=f"{label} não encontrado")
    _not_past(doc["date"])
    return doc


async def _validate(body: AppointmentIn, self_id: str = "") -> dict:
    """Checks date (no past days), patient/workplace and, unless encaixe, slot conflicts and blocks. Returns the patient."""
    _not_past(body.date)
    patient = await db.patients.find_one({"id": body.patient_id}, {"_id": 0})
    if not patient:
        raise HTTPException(status_code=400, detail="Paciente não encontrado — cadastre o paciente antes de agendar")
    wp = await db.workplaces.find_one({"id": body.workplace_id}, {"_id": 0, "agenda_enabled": 1})
    if not wp:
        raise HTTPException(status_code=400, detail="Local não encontrado")
    if not wp.get("agenda_enabled"):
        raise HTTPException(status_code=400, detail="A agenda não está ativada para este local")
    patient["_plan_name"] = ""
    if body.payer == "plano":
        plan = await db.health_plans.find_one({"id": body.health_plan_id}, {"_id": 0, "name": 1}) if body.health_plan_id else None
        if not plan:
            raise HTTPException(status_code=400, detail="Escolha o plano de saúde do atendimento")
        patient["_plan_name"] = plan["name"]
    else:
        body.health_plan_id = ""
    if not body.encaixe:
        busy = await db.appointments.find_one(
            {"workplace_id": body.workplace_id, "date": body.date, "time": body.time,
             "status": {"$ne": "cancelado"}, "encaixe": {"$ne": True}, "id": {"$ne": self_id}},
            {"_id": 0, "patient_name": 1},
        )
        if busy:
            raise HTTPException(status_code=409, detail=f"Horário já ocupado por {busy.get('patient_name', 'outro paciente')}. Marque como encaixe para agendar mesmo assim.")
        for b in await db.agenda_blocks.find({"workplace_id": body.workplace_id, "date": body.date}, {"_id": 0}).to_list(100):
            if not b.get("start") or (b["start"] <= body.time < (b.get("end") or "24:00")):
                raise HTTPException(status_code=409, detail=f"Horário bloqueado{': ' + b['reason'] if b.get('reason') else ''}. Marque como encaixe para agendar mesmo assim.")
    return patient


# ---------- Appointments ----------
@router.get("/appointments", response_model=list[Appointment])
async def list_appointments(workplace_id: str = "", date_from: str = "", date_to: str = "", patient_id: str = ""):
    filt = _range_filter(workplace_id, date_from, date_to)
    if patient_id:
        filt["patient_id"] = patient_id
    return await db.appointments.find(filt, {"_id": 0}).sort([("date", 1), ("time", 1)]).to_list(5000)


@router.post("/appointments", response_model=Appointment)
async def create_appointment(body: AppointmentIn):
    p = await _validate(body)
    obj = Appointment(**body.model_dump(), patient_name=p["name"], patient_phone=p.get("phone", ""), health_plan_name=p["_plan_name"])
    await db.appointments.insert_one(obj.model_dump())
    return obj


@router.put("/appointments/{id}", response_model=Appointment)
async def update_appointment(id: str, body: AppointmentIn):
    await _existing(db.appointments, id, "Agendamento")
    p = await _validate(body, self_id=id)
    await db.appointments.update_one(
        {"id": id}, {"$set": {**body.model_dump(), "patient_name": p["name"], "patient_phone": p.get("phone", ""), "health_plan_name": p["_plan_name"]}}
    )
    return await db.appointments.find_one({"id": id}, {"_id": 0})


@router.patch("/appointments/{id}/status", response_model=Appointment)
async def set_status(id: str, body: AppointmentStatusIn):
    await _existing(db.appointments, id, "Agendamento")
    await db.appointments.update_one({"id": id}, {"$set": {"status": body.status}})
    return await db.appointments.find_one({"id": id}, {"_id": 0})


@router.patch("/appointments/{id}/payment", response_model=Appointment)
async def set_payment(id: str, body: PaymentIn):
    """Mark an attendance paid / unpaid — allowed on past days (payments often come later)."""
    a = await db.appointments.find_one({"id": id}, {"_id": 0})
    if not a:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado")
    if body.paid and a.get("status") != "atendido":
        raise HTTPException(status_code=400, detail="Só é possível receber de atendimentos marcados como Atendido")
    if body.paid and not body.payment_method:
        raise HTTPException(status_code=400, detail="Escolha a forma de pagamento")
    upd = {"paid": body.paid, "payment_method": body.payment_method if body.paid else "", "paid_at": today_iso() if body.paid else ""}
    await db.appointments.update_one({"id": id}, {"$set": upd})
    return {**a, **upd}


@router.patch("/appointments/{id}/reminder", response_model=Appointment)
async def set_reminder(id: str):
    """Marks the WhatsApp confirmation as sent (lembretes em lote)."""
    a = await db.appointments.find_one({"id": id}, {"_id": 0})
    if not a:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado")
    await db.appointments.update_one({"id": id}, {"$set": {"reminder_sent": True}})
    return {**a, "reminder_sent": True}


@router.get("/appointments/{id}/receipt", response_model=ReceiptData)
async def receipt(id: str):
    """Data for the printed payment receipt (paid attendances only)."""
    a = await db.appointments.find_one({"id": id}, {"_id": 0})
    if not a:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado")
    if not a.get("paid"):
        raise HTTPException(status_code=400, detail="O recibo só pode ser emitido para atendimentos pagos")
    wp = await db.workplaces.find_one({"id": a["workplace_id"]}, {"_id": 0}) or {"id": a["workplace_id"], "name": "—"}
    p = await db.patients.find_one({"id": a["patient_id"]}, {"_id": 0, "cpf": 1}) or {}
    st = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    plan = await db.health_plans.find_one({"id": a.get("health_plan_id")}, {"_id": 0}) if a.get("health_plan_id") else None
    return ReceiptData(appointment=Appointment(**a), workplace=Workplace(**wp), patient_cpf=p.get("cpf", ""),
                       doctor_name=st.get("doctor_name", ""), crm=st.get("crm", ""), crm_uf=st.get("crm_uf", ""),
                       amount=amount_for(a, wp, plan))


@router.delete("/appointments/{id}")
async def delete_appointment(id: str):
    await _existing(db.appointments, id, "Agendamento")
    res = await db.appointments.delete_one({"id": id})
    if not res.deleted_count:
        raise HTTPException(status_code=404, detail="Agendamento não encontrado")
    return {"ok": True}


# ---------- Blocked periods ----------
@router.get("/agenda-blocks", response_model=list[AgendaBlock])
async def list_blocks(workplace_id: str = "", date_from: str = "", date_to: str = ""):
    return await db.agenda_blocks.find(_range_filter(workplace_id, date_from, date_to), {"_id": 0}).sort([("date", 1), ("start", 1)]).to_list(2000)


@router.post("/agenda-blocks", response_model=AgendaBlock)
async def create_block(body: AgendaBlockIn):
    _not_past(body.date)
    if bool(body.start) != bool(body.end) or (body.start and body.start >= body.end):
        raise HTTPException(status_code=400, detail="Informe início e fim do bloqueio (ou deixe ambos vazios para o dia inteiro)")
    obj = AgendaBlock(**body.model_dump())
    await db.agenda_blocks.insert_one(obj.model_dump())
    return obj


@router.delete("/agenda-blocks/{id}")
async def delete_block(id: str):
    await _existing(db.agenda_blocks, id, "Bloqueio")
    res = await db.agenda_blocks.delete_one({"id": id})
    if not res.deleted_count:
        raise HTTPException(status_code=404, detail="Bloqueio não encontrado")
    return {"ok": True}
