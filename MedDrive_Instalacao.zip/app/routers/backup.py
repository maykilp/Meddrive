"""Backup of the data (encrypted .meddrive): e-mail via the user's own mailbox, download, restore.
Not behind the Settings password (any user of the computer can back up / restore)."""

import asyncio
import base64
import binascii
import re
import smtplib
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response

from lib import backup
from models.schemas import BackupConfigIn, BackupConfigOut, BackupResult, RestoreIn

router = APIRouter(prefix="/backup")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
SAFETY_DIR = Path(__file__).resolve().parent.parent.parent / "backups"  # pendrive: MedDrive/backups


async def _out() -> BackupConfigOut:
    cfg = await backup.get_config()
    due, days = backup.is_due(cfg)
    return BackupConfigOut(
        email=cfg.get("email", ""), send_to=cfg.get("send_to", ""), smtp_host=cfg.get("smtp_host", ""),
        smtp_port=int(cfg.get("smtp_port") or 0), smtp_security=cfg.get("smtp_security", "ssl"),
        has_password=bool(cfg.get("password_enc")), last_backup_at=cfg.get("last_backup_at", ""),
        last_backup_method=cfg.get("last_backup_method", ""), due=due, days_since=days,
    )


@router.get("/config", response_model=BackupConfigOut)
async def get_config():
    return await _out()


@router.put("/config", response_model=BackupConfigOut)
async def put_config(body: BackupConfigIn):
    email = body.email.strip()
    if not EMAIL_RE.match(email):
        raise HTTPException(status_code=400, detail="E-mail inválido")
    if body.send_to.strip() and not EMAIL_RE.match(body.send_to.strip()):
        raise HTTPException(status_code=400, detail="E-mail de destino inválido")
    host, port, sec = body.smtp_host.strip(), body.smtp_port, body.smtp_security
    if not host:
        preset = backup.preset_for(email)
        if not preset:
            raise HTTPException(status_code=400, detail="Informe o servidor SMTP do seu provedor de e-mail")
        host, port, sec = preset
    changes = {"email": email, "send_to": body.send_to.strip(), "smtp_host": host, "smtp_port": port or 465, "smtp_security": sec}
    if body.password:
        changes["password_enc"] = backup.encrypt_password(body.password.replace(" ", ""))
    await backup.save_config(changes)
    return await _out()


@router.post("/send", response_model=BackupResult)
async def send():
    cfg = await backup.get_config()
    if not cfg.get("email") or not cfg.get("smtp_host"):
        raise HTTPException(status_code=400, detail="Cadastre o e-mail do backup primeiro")
    password = backup.decrypt_password(cfg.get("password_enc", ""))
    if not password and cfg.get("smtp_security") != "none":
        raise HTTPException(status_code=400, detail="Cadastre a senha de app do e-mail")
    filename, data, counts = await backup.build_backup()
    if len(data) > backup.MAX_BYTES:
        raise HTTPException(status_code=413, detail="Backup maior que 20 MB — use \"Baixar backup\" e guarde o arquivo")
    try:
        await asyncio.to_thread(backup.send_mail, cfg, password, filename, data, counts)
    except smtplib.SMTPAuthenticationError:
        raise HTTPException(status_code=401, detail="O e-mail recusou o login. Confira o e-mail e use uma SENHA DE APP (não a senha normal).")
    except smtplib.SMTPRecipientsRefused:
        raise HTTPException(status_code=400, detail="O e-mail de destino foi recusado")
    except (smtplib.SMTPException, OSError) as e:
        raise HTTPException(status_code=502, detail=f"Não foi possível enviar ({type(e).__name__}). Verifique a internet e o servidor de e-mail.")
    await backup.mark_done("email")
    return BackupResult(ok=True, message=f"Backup enviado para {cfg.get('send_to') or cfg['email']}", filename=filename, size=len(data), counts=counts)


@router.get("/download")
async def download():
    filename, data, _ = await backup.build_backup()
    await backup.mark_done("download")
    return Response(data, media_type="application/octet-stream", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.post("/restore", response_model=BackupResult)
async def restore(body: RestoreIn):
    try:
        data = base64.b64decode(body.data_b64.split(",", 1)[-1], validate=False)
        collections = backup.read_backup(data)
    except (ValueError, binascii.Error) as e:
        raise HTTPException(status_code=400, detail=str(e) or "Arquivo inválido")
    # safety copy of the current data before replacing it (explicit user action, confirmed in the UI)
    if not body.confirm:
        raise HTTPException(status_code=400, detail="Confirme a restauração")
    name, current, _ = await backup.build_backup()
    SAFETY_DIR.mkdir(parents=True, exist_ok=True)
    (SAFETY_DIR / f"antes-de-restaurar-{datetime.now():%Y%m%d-%H%M%S}.meddrive").write_bytes(current)
    counts = await backup.restore(collections)
    return BackupResult(ok=True, message="Backup restaurado", filename=body.filename, size=len(data), counts=counts)
