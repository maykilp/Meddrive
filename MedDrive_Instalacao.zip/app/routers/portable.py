"""Pendrive (portable) version: download, version info and self-update.

Online (mongo mode) this server publishes the package: /portable/download (code + data export, admin
only), /portable/update-package (code only, no data) and /portable/version. On the pendrive (file
mode) /portable/update-check asks the online server for its version and /portable/update downloads
the new code into `atualizacao/`, backs up `dados/` and restarts; run_portable.py copies the new
files over the old ones (never touching `dados/`) before starting again.
"""

import asyncio
import json
import os
import shutil
import tempfile
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

from lib import updater
from lib.db import FILE_MODE
from lib.filestore import COLLECTIONS, data_dir, dump_collection

router = APIRouter(prefix="/portable")

BASE_ZIP = Path(__file__).resolve().parent.parent.parent / "portable" / "build" / "base.zip"
BASE_VERSION = BASE_ZIP.parent / "VERSION"
APP_DIR = Path(__file__).resolve().parent.parent  # pendrive: MedDrive/app
ROOT_DIR = APP_DIR.parent  # pendrive: MedDrive/
STAGE = ROOT_DIR / "atualizacao"
BACKUPS = ROOT_DIR / "backups"
KEEP_BACKUPS = 3


class PortableInfo(BaseModel):
    mode: str  # "file" (running from the pendrive) | "mongo" (online)
    available: bool  # pendrive package can be downloaded from here
    data_dir: str = ""
    version: str = ""  # pendrive: installed version; online: version of the package published here
    update_url: str = ""  # pendrive: where updates come from


class UpdateCheck(BaseModel):
    current: str
    latest: str = ""
    available: bool = False
    online: bool = False  # the update server could be reached
    url: str = ""


class UpdateResult(BaseModel):
    ok: bool
    restarting: bool
    version: str
    message: str


def _read(p: Path) -> str:
    try:
        return p.read_text("utf-8").strip()
    except OSError:
        return ""


def _local_version() -> str:
    return _read(APP_DIR / "VERSION") if FILE_MODE else _read(BASE_VERSION)


def _update_url() -> str:
    try:
        return str(json.loads(_read(APP_DIR / "update.json") or "{}").get("url", "")).rstrip("/")
    except ValueError:
        return ""


def _origin(request: Request) -> str:
    proto = request.headers.get("x-forwarded-proto", request.url.scheme).split(",")[0].strip()
    host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
    return f"{proto}://{host.split(',')[0].strip()}"


def _package(request: Request) -> str:
    """Copy of base.zip + update.json (address of this server, used by the pendrive to update)."""
    if FILE_MODE or not BASE_ZIP.is_file():
        raise HTTPException(status_code=404, detail="Pacote do pendrive indisponível")
    fd, tmp = tempfile.mkstemp(suffix=".zip")
    os.close(fd)
    shutil.copyfile(BASE_ZIP, tmp)
    with zipfile.ZipFile(tmp, "a", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("MedDrive/app/update.json", json.dumps({"url": _origin(request)}))
    return tmp


@router.get("/info", response_model=PortableInfo)
async def info():
    if FILE_MODE:
        return PortableInfo(mode="file", available=False, data_dir=str(data_dir().resolve()),
                            version=_local_version(), update_url=_update_url())
    return PortableInfo(mode="mongo", available=BASE_ZIP.is_file(), version=_local_version())


@router.get("/version")
async def version():
    return {"version": _local_version()}


@router.get("/download")
async def download(request: Request, background: BackgroundTasks):
    tmp = _package(request)
    with zipfile.ZipFile(tmp, "a", compression=zipfile.ZIP_DEFLATED) as z:
        for name in COLLECTIONS:
            if name == "backup_config":  # e-mail login of the online server never goes to a pendrive
                continue
            z.writestr(f"MedDrive/dados/{name}.json", await dump_collection(name))
    background.add_task(os.remove, tmp)
    return FileResponse(tmp, media_type="application/zip", filename="MedDrive-Pendrive.zip")


@router.get("/update-package")
async def update_package(request: Request, background: BackgroundTasks):
    """Code only (no data): extracting it over an existing pendrive folder keeps `dados/`."""
    tmp = _package(request)
    background.add_task(os.remove, tmp)
    return FileResponse(tmp, media_type="application/zip", filename="MedDrive-Atualizacao.zip")


# ---------- pendrive self-update ----------
def _fetch_json(url: str, timeout: float) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "MedDrive/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


@router.get("/update-check", response_model=UpdateCheck)
async def update_check():
    current, url = _local_version(), _update_url()
    if not FILE_MODE or not url:
        return UpdateCheck(current=current, url=url)
    try:
        latest = str((await asyncio.to_thread(_fetch_json, f"{url}/api/portable/version", 6)).get("version", ""))
    except Exception:
        return UpdateCheck(current=current, url=url)  # offline
    return UpdateCheck(current=current, latest=latest, online=True, url=url,
                       available=bool(latest) and latest != current)


def _download_and_stage(url: str) -> str:
    fd, tmp = tempfile.mkstemp(suffix=".zip")
    os.close(fd)
    try:
        req = urllib.request.Request(f"{url}/api/portable/update-package", headers={"User-Agent": "MedDrive/1.0"})
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f, 1024 * 256)
        with zipfile.ZipFile(tmp) as z:
            names = z.namelist()
            if "MedDrive/app/server.py" not in names or "MedDrive/app/VERSION" not in names:
                raise RuntimeError("pacote de atualização inválido")
            new_version = z.read("MedDrive/app/VERSION").decode("utf-8").strip()
            shutil.rmtree(STAGE, ignore_errors=True)
            STAGE.mkdir(parents=True)
            for n in names:  # never extract data files
                if not n.startswith("MedDrive/dados/") and ".." not in n:
                    z.extract(n, STAGE)
        _backup_data()
        (STAGE / "READY").write_text(new_version, "utf-8")
        return new_version
    finally:
        os.remove(tmp)


def _backup_data() -> None:
    src = data_dir().resolve()
    if not src.is_dir():
        return
    BACKUPS.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, BACKUPS / f"dados-antes-da-atualizacao-{datetime.now():%Y%m%d-%H%M%S}")
    old = sorted(p for p in BACKUPS.iterdir() if p.is_dir() and p.name.startswith("dados-antes-da-atualizacao-"))
    for p in old[:-KEEP_BACKUPS]:
        shutil.rmtree(p, ignore_errors=True)


@router.post("/update", response_model=UpdateResult)
async def update():
    url = _update_url()
    if not FILE_MODE or not url:
        raise HTTPException(status_code=400, detail="Atualização disponível apenas na versão pendrive")
    try:
        new_version: Optional[str] = await asyncio.to_thread(_download_and_stage, url)
    except Exception as e:
        shutil.rmtree(STAGE, ignore_errors=True)
        raise HTTPException(status_code=502, detail=f"Não foi possível baixar a atualização ({e}). Verifique a internet.")
    restarting = updater.request_restart()
    msg = ("Atualização baixada. O MedDrive vai reiniciar sozinho em alguns segundos."
           if restarting else "Atualização baixada. Feche a janela preta do MedDrive e abra novamente para concluir.")
    return UpdateResult(ok=True, restarting=restarting, version=new_version or "", message=msg)
