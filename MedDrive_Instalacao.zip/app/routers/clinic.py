"""Settings, documents (history), quick medications, and server date."""

import re
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from lib import admin_auth, license
from lib.crud import crud_router
from lib.dates import today_iso
from lib.db import db
from models.schemas import (
    HealthPlan,
    HealthPlanIn,
    ReportTemplate,
    ReportTemplateIn,
    ReferralTemplate,
    ReferralTemplateIn,
    ClinicalPhrase,
    ClinicalPhraseIn,
    PinIn,
    DoctorSnap,
    Document,
    DocumentIn,
    Exam,
    ExamGroup,
    ExamGroupIn,
    ExamIn,
    Guidance,
    GuidanceIn,
    Medication,
    MedicationIn,
    Patient,
    PatientIn,
    RxTemplate,
    RxTemplateIn,
    ActiveWorkplaceIn,
    DoctorIn,
    Settings,
    SettingsOut,
    Specialty,
    Workplace,
    WorkplaceIn,
    WorkplaceSnap,
)

router = APIRouter()
router.include_router(crud_router("/workplaces", "workplaces", WorkplaceIn, Workplace))
router.include_router(crud_router("/patients", "patients", PatientIn, Patient))
router.include_router(crud_router("/medications", "medications", MedicationIn, Medication))
router.include_router(crud_router("/exams", "exams", ExamIn, Exam))
router.include_router(crud_router("/guidance", "guidance", GuidanceIn, Guidance))
router.include_router(crud_router("/report-templates", "report_templates", ReportTemplateIn, ReportTemplate))
router.include_router(crud_router("/referral-templates", "referral_templates", ReferralTemplateIn, ReferralTemplate))
router.include_router(crud_router("/clinical-phrases", "clinical_phrases", ClinicalPhraseIn, ClinicalPhrase))
router.include_router(crud_router("/rx-templates", "rx_templates", RxTemplateIn, RxTemplate))
router.include_router(crud_router("/exam-groups", "exam_groups", ExamGroupIn, ExamGroup))
router.include_router(crud_router("/health-plans", "health_plans", HealthPlanIn, HealthPlan))

MAX_PINNED = 5  # shortcuts shown in the Nova Receita bars


def _shortcut_routes(path: str, collection: str) -> APIRouter:
    """Pin (max. 5) and usage counter for ready-made prescriptions / exam groups."""
    r = APIRouter(prefix=path)
    col = db[collection]

    @r.patch("/{id}/pin")
    async def pin(id: str, body: PinIn):
        if body.pinned and await col.count_documents({"pinned": True, "id": {"$ne": id}}) >= MAX_PINNED:
            raise HTTPException(status_code=400, detail=f"Você pode fixar no máximo {MAX_PINNED}. Desafixe outro antes.")
        res = await col.update_one({"id": id}, {"$set": {"pinned": body.pinned}})
        if not res.matched_count:
            raise HTTPException(status_code=404, detail="Não encontrado")
        return {"ok": True, "pinned": body.pinned}

    @r.post("/{id}/use")
    async def use(id: str):
        await col.update_one({"id": id}, {"$inc": {"uses": 1}})
        return {"ok": True}

    return r


router.include_router(_shortcut_routes("/rx-templates", "rx_templates"))
router.include_router(_shortcut_routes("/exam-groups", "exam_groups"))


@router.get("/today")
async def get_today():
    return {"date": today_iso()}


# ---------- Settings ----------
async def _settings() -> Settings:
    doc = await db.settings.find_one({"key": "main"}, {"_id": 0, "key": 0})
    return Settings(**(doc or {}))


def _doctor_payload(s) -> dict:
    return {
        "doctor_name": s.doctor_name,
        "crm": s.crm,
        "crm_uf": s.crm_uf,
        "specialties": [sp.model_dump() for sp in s.specialties],
    }


@router.get("/settings", response_model=SettingsOut)
async def get_settings():
    s = await _settings()
    if s.active_workplace_id and not await db.workplaces.find_one({"id": s.active_workplace_id}, {"_id": 1}):
        s.active_workplace_id = None
    if not s.active_workplace_id:
        first = await db.workplaces.find_one({}, {"_id": 0, "id": 1}, sort=[("name", 1)])
        if first:
            s.active_workplace_id = first["id"]
    verified = bool(s.doctor_sig) and admin_auth.verify(_doctor_payload(s), s.doctor_sig)
    has_data = bool(s.doctor_name or s.crm or s.crm_uf or s.specialty or s.specialties)
    out = SettingsOut(active_workplace_id=s.active_workplace_id, doctor_verified=verified,
                      doctor_tampered=not verified and (has_data or bool(s.doctor_sig)))
    if verified:
        out.doctor_name, out.crm, out.crm_uf, out.specialties = s.doctor_name, s.crm, s.crm_uf, s.specialties
    return out


@router.put("/settings/doctor", response_model=SettingsOut)
async def put_doctor(body: DoctorIn):
    key = admin_auth.signing_key()
    clean = DoctorIn(
        doctor_name=body.doctor_name.strip(),
        crm=body.crm.strip(),
        crm_uf=body.crm_uf.strip().upper(),
        specialties=[Specialty(name=sp.name.strip(), rqe=sp.rqe.strip()) for sp in body.specialties if sp.name.strip() or sp.rqe.strip()],
    )
    payload = _doctor_payload(clean)
    await db.settings.update_one(
        {"key": "main"},
        {"$set": {**payload, "specialty": "", "doctor_sig": admin_auth.sign(key, payload)}},
        upsert=True,
    )
    return await get_settings()


@router.put("/settings/active-workplace", response_model=SettingsOut)
async def put_active_workplace(body: ActiveWorkplaceIn):
    if not await db.workplaces.find_one({"id": body.active_workplace_id}, {"_id": 1}):
        raise HTTPException(status_code=404, detail="Local não encontrado")
    await db.settings.update_one({"key": "main"}, {"$set": {"active_workplace_id": body.active_workplace_id}}, upsert=True)
    return await get_settings()


# ---------- Quick prescriptions (pinned first, then most prescribed) ----------
@router.get("/quick-medications", response_model=list[Medication])
async def quick_medications():
    pinned = (await db.medications.find({"pinned": True}, {"_id": 0}).sort("name", 1).limit(8).to_list(8))[:8]
    rest_n = max(0, 8 - len(pinned))
    rest = []
    if rest_n:
        rest = (
            await db.medications.find({"pinned": {"$ne": True}}, {"_id": 0})
            .sort([("usage_count", -1), ("name", 1)])
            .limit(rest_n)
            .to_list(rest_n)
        )[:rest_n]
    return pinned + rest


# ---------- Documents ----------
@router.post("/documents", response_model=Document)
async def create_document(body: DocumentIn):
    if body.type == "receita" and not body.items and not body.exams:
        raise HTTPException(status_code=400, detail="Adicione ao menos um medicamento ou exame")
    c = body.clinical
    if c and not (c.history.strip() or c.physical_exam.strip() or c.conduct.strip()):
        body.clinical = None
    if body.type == "atendimento" and not body.clinical:
        raise HTTPException(status_code=400, detail="Preencha a história clínica, o exame físico ou a conduta")
    s = await get_settings()
    if s.doctor_tampered:
        raise HTTPException(
            status_code=409,
            detail="Os dados do médico foram alterados fora do sistema. Entre em Configurações com sua senha e salve novamente.",
        )
    lic = await license.status(s.crm, online=False)
    if not lic["allowed"]:
        raise HTTPException(status_code=403, detail=f"Sistema bloqueado: {lic['message']}")
    wp = await db.workplaces.find_one({"id": s.active_workplace_id}, {"_id": 0}) if s.active_workplace_id else None
    doc = Document(
        **body.model_dump(),
        date=today_iso(),
        # logo is not duplicated into every document; it is resolved from the workplace on read
        workplace=WorkplaceSnap(**{**wp, "logo": ""}) if wp else WorkplaceSnap(),
        doctor=DoctorSnap(**s.model_dump()),
    )
    await db.documents.insert_one(doc.model_dump())
    if body.appointment_id:
        await db.appointments.update_one({"id": body.appointment_id}, {"$set": {"status": "atendido", "document_id": doc.id}})
    med_ids = [i.medication_id for i in body.items if i.medication_id]
    if med_ids:
        await db.medications.update_many({"id": {"$in": med_ids}}, {"$inc": {"usage_count": 1}})
    return await _with_logo(doc.model_dump())


async def _with_logo(doc: dict) -> dict:
    wp = doc.get("workplace") or {}
    if not wp.get("logo") and wp.get("id"):
        cur = await db.workplaces.find_one({"id": wp["id"]}, {"_id": 0, "logo": 1})
        if cur:
            doc["workplace"] = {**wp, "logo": cur.get("logo", "")}
    return doc


@router.get("/documents", response_model=list[Document])
async def list_documents(
    q: str = "",
    date_from: str = "",
    date_to: str = "",
    type: str = "",
    patient_id: str = "",
    workplace_id: str = "",
):
    filt: dict = {}
    if q:
        filt["patient_name"] = {"$regex": re.escape(q), "$options": "i"}
    if patient_id:
        filt["patient_id"] = patient_id
    if workplace_id:
        filt["workplace.id"] = workplace_id
    date: dict = {}
    if date_from:
        date["$gte"] = date_from
    if date_to:
        date["$lte"] = date_to
    if date:
        filt["date"] = date
    if type == "exames":
        filt["exams.0"] = {"$exists": True}
    elif type == "clinica":  # any attendance with a clinical note
        filt["clinical"] = {"$ne": None}
    elif type == "controlada":
        filt["items.controlled"] = True
    elif type == "receita":
        filt["type"] = "receita"
        filt["items.0"] = {"$exists": True}
    elif type:
        filt["type"] = type
    return (
        await db.documents.find(filt, {"_id": 0, "workplace.logo": 0})
        .sort([("date", -1), ("created_at", -1)])
        .to_list(1000)
    )


@router.get("/documents/{id}", response_model=Document)
async def get_document(id: str):
    doc: Optional[dict] = await db.documents.find_one({"id": id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Documento não encontrado")
    return await _with_logo(doc)


@router.delete("/documents/{id}")
async def delete_document(id: str):
    res = await db.documents.delete_one({"id": id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Documento não encontrado")
    return {"ok": True}
