"""Termo de uso/responsabilidade: precisa ser aceito (uma vez por versão) antes de usar o sistema.

Aceites só são criados — não há rota para alterar ou excluir.
"""

from fastapi import APIRouter, HTTPException

from lib import terms
from lib.db import db
from models.schemas import TermsAcceptance, TermsAcceptIn, TermsOut, TermsSection

router = APIRouter(prefix="/terms")


async def _latest() -> dict | None:
    return await db.terms_acceptance.find_one({"version": terms.TERMS_VERSION}, {"_id": 0}, sort=[("created_at", -1)])


@router.get("", response_model=TermsOut)
async def get_terms():
    acc = await _latest()
    history = await db.terms_acceptance.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return TermsOut(
        version=terms.TERMS_VERSION,
        date=terms.TERMS_DATE,
        title=terms.TITLE,
        sections=[TermsSection(**s) for s in terms.SECTIONS],
        accepted=acc is not None,
        acceptance=acc,
        history=history,
    )


@router.post("/accept", response_model=TermsAcceptance)
async def accept_terms(body: TermsAcceptIn):
    if body.version != terms.TERMS_VERSION:
        raise HTTPException(status_code=400, detail="Versão do termo desatualizada — recarregue a página")
    if not body.agree:
        raise HTTPException(status_code=400, detail="É preciso marcar que leu e concorda com o termo")
    existing = await _latest()
    if existing:  # already accepted: the record never changes
        return existing
    acc = TermsAcceptance(**body.model_dump(exclude={"agree"}))
    await db.terms_acceptance.insert_one(acc.model_dump())
    return acc
