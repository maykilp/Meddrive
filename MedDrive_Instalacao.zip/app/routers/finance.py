"""Financeiro: values of attended appointments (a receber / recebido), avulso entries, monthly goal and charts data."""

from fastapi import APIRouter, HTTPException

from lib.dates import today_iso
from lib.db import db
from models.schemas import (
    FinanceBucket, FinanceEntry, FinanceEntryIn, FinanceItem, FinanceSummary, GoalIn, MonthlyReceipt, RecurringExpense,
    RecurringExpenseIn, SettleIn, SettleOut, Workplace,
)

router = APIRouter(prefix="/finance")

METHODS = {"dinheiro": "Dinheiro", "pix": "PIX", "cartao": "Cartão", "convenio": "Convênio", "outro": "Outro", "": "A receber"}
MONTHS = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]


def _month_add(ym: str, n: int) -> str:
    y, m = int(ym[:4]), int(ym[5:7]) - 1 + n
    return f"{y + m // 12:04d}-{m % 12 + 1:02d}"


def amount_for(a: dict, wp: dict, plan: dict | None = None) -> float:
    """Own price (desconto/cortesia) > plan price (per-workplace override > plan default) > workplace price."""
    if a.get("price") is not None:
        return float(a["price"])
    field = "price_retorno" if a.get("kind") == "retorno" else "price_consulta"
    if a.get("payer") == "plano" and plan:
        over = next((p for p in plan.get("workplace_prices", []) if p.get("workplace_id") == a.get("workplace_id")), None)
        return float((over or plan).get(field, 0) or 0)
    return float(wp.get(field, 0) or 0)


async def plans_map() -> dict[str, dict]:
    return {p["id"]: p for p in await db.health_plans.find({}, {"_id": 0}).to_list(500)}


def _amount(a: dict, wp: dict, plans: dict[str, dict] | None = None) -> float:
    return amount_for(a, wp, (plans or {}).get(a.get("health_plan_id", "")))


async def _goal() -> float:
    doc = await db.settings.find_one({"key": "finance"}, {"_id": 0})
    return float((doc or {}).get("goal", 0))


async def materialize_recurring() -> None:
    """Launch each active despesa fixa once per month, from its start month up to today (idempotent)."""
    today = today_iso()
    for r in await db.finance_recurring.find({"active": True}, {"_id": 0}).to_list(500):
        done = set(r.get("generated_months", []))
        ym = r.get("start_month") or today[:7]
        new: list[str] = []
        while ym <= today[:7]:
            date = f"{ym}-{int(r['day']):02d}"
            if ym not in done and date <= today:
                e = FinanceEntry(kind="despesa", date=date, description=r["description"], amount=r["amount"],
                                 workplace_id=r.get("workplace_id", ""), recurring_id=r["id"])
                await db.finance_entries.insert_one(e.model_dump())
                new.append(ym)
            ym = _month_add(ym, 1)
        if new:
            await db.finance_recurring.update_one({"id": r["id"]}, {"$addToSet": {"generated_months": {"$each": new}}})


@router.get("/summary", response_model=FinanceSummary)
async def summary(date_from: str = "", date_to: str = "", workplace_id: str = ""):
    await materialize_recurring()
    today = today_iso()
    date_to = date_to or today
    date_from = date_from or f"{date_to[:7]}-01"
    wps = {w["id"]: w for w in await db.workplaces.find({}, {"_id": 0, "logo": 0}).to_list(500)}
    plans = await plans_map()
    # 12 months ending at date_to → wide query, then split per period
    m_first = _month_add(date_to[:7], -11)
    wide_from = min(date_from, f"{m_first}-01")
    afilt: dict = {"status": "atendido", "date": {"$gte": wide_from, "$lte": date_to}}
    efilt: dict = {"date": {"$gte": wide_from, "$lte": date_to}}
    if workplace_id:
        afilt["workplace_id"] = workplace_id
        efilt["workplace_id"] = workplace_id
    appts = await db.appointments.find(afilt, {"_id": 0}).sort([("date", 1), ("time", 1)]).to_list(20000)
    entries = await db.finance_entries.find(efilt, {"_id": 0}).sort("date", 1).to_list(20000)

    months = {(_month_add(m_first, i)): FinanceBucket(key=_month_add(m_first, i), label=f"{MONTHS[int(_month_add(m_first, i)[5:7]) - 1]}/{_month_add(m_first, i)[2:4]}") for i in range(12)}
    by_wp: dict[str, FinanceBucket] = {}
    by_method: dict[str, FinanceBucket] = {}
    by_plan: dict[str, FinanceBucket] = {}
    items: list[FinanceItem] = []
    received = receivable = expenses = 0.0

    def bucket(d: dict, key: str, label: str) -> FinanceBucket:
        return d.setdefault(key, FinanceBucket(key=key, label=label))

    for a in appts:
        wp = wps.get(a["workplace_id"], {})
        amt = _amount(a, wp, plans)
        paid = bool(a.get("paid"))
        if a["date"][:7] in months:
            mb = months[a["date"][:7]]
            if paid:
                mb.received += amt
            else:
                mb.receivable += amt
        if not (date_from <= a["date"] <= date_to):
            continue
        items.append(FinanceItem(id=a["id"], date=a["date"], time=a["time"], patient_id=a["patient_id"], patient_name=a.get("patient_name", ""),
                                 workplace_id=a["workplace_id"], workplace_name=wp.get("name", "—"), kind=a.get("kind", "consulta"), amount=amt,
                                 paid=paid, payment_method=a.get("payment_method", ""), paid_at=a.get("paid_at", ""),
                                 payer=a.get("payer", "particular"), health_plan_id=a.get("health_plan_id", ""), health_plan_name=a.get("health_plan_name", "")))
        wb = bucket(by_wp, a["workplace_id"], wp.get("name", "—"))
        is_plan = a.get("payer") == "plano" and a.get("health_plan_id")
        pb = bucket(by_plan, a["health_plan_id"], plans.get(a["health_plan_id"], {}).get("name") or a.get("health_plan_name") or "Plano") if is_plan else bucket(by_plan, "particular", "Particular")
        pb.count += 1
        if paid:
            pb.received += amt
        else:
            pb.receivable += amt
        meth = a.get("payment_method", "") if paid else ""
        mt = bucket(by_method, meth, METHODS.get(meth, meth))
        if paid:
            received += amt
            wb.received += amt
            mt.received += amt
        else:
            receivable += amt
            wb.receivable += amt
            mt.receivable += amt

    period_entries = []
    for e in entries:
        amt = float(e["amount"])
        if e["date"][:7] in months:
            if e["kind"] == "receita":
                months[e["date"][:7]].received += amt
            else:
                months[e["date"][:7]].expenses += amt
        if not (date_from <= e["date"] <= date_to):
            continue
        period_entries.append(FinanceEntry(**e))
        wb = bucket(by_wp, e.get("workplace_id") or "geral", wps.get(e.get("workplace_id", ""), {}).get("name", "Geral"))
        if e["kind"] == "receita":
            received += amt
            wb.received += amt
            meth = e.get("payment_method") or "outro"
            bucket(by_method, meth, METHODS.get(meth, meth)).received += amt
        else:
            expenses += amt
            wb.expenses += amt

    goal_month = date_to[:7]
    return FinanceSummary(
        date_from=date_from, date_to=date_to, received=received, receivable=receivable, expenses=expenses,
        profit=received - expenses, attended=len(items), goal=await _goal(), goal_month=goal_month,
        goal_month_received=months[goal_month].received, items=items, entries=period_entries,
        by_month=list(months.values()), by_workplace=list(by_wp.values()), by_method=[b for b in by_method.values() if b.received or b.receivable],
        by_plan=sorted(by_plan.values(), key=lambda b: (b.key != "particular", b.label)),
    )


@router.post("/plans/{plan_id}/settle", response_model=SettleOut)
async def settle_plan(plan_id: str, body: SettleIn):
    """Dar baixa em lote: marks every attended, unpaid attendance of the plan in the month as paid (convênio)."""
    plan = await db.health_plans.find_one({"id": plan_id}, {"_id": 0})
    if not plan:
        raise HTTPException(status_code=404, detail="Plano não encontrado")
    filt: dict = {"payer": "plano", "health_plan_id": plan_id, "status": "atendido", "paid": {"$ne": True},
                  "date": {"$gte": f"{body.month}-01", "$lte": f"{body.month}-31"}}
    if body.workplace_id:
        filt["workplace_id"] = body.workplace_id
    appts = await db.appointments.find(filt, {"_id": 0}).to_list(5000)
    if not appts:
        raise HTTPException(status_code=400, detail="Nenhum atendimento a receber deste plano neste mês")
    wps = {w["id"]: w for w in await db.workplaces.find({}, {"_id": 0, "logo": 0}).to_list(500)}
    total = sum(amount_for(a, wps.get(a["workplace_id"], {}), plan) for a in appts)
    await db.appointments.update_many({"id": {"$in": [a["id"] for a in appts]}},
                                      {"$set": {"paid": True, "payment_method": "convenio", "paid_at": today_iso()}})
    return SettleOut(count=len(appts), total=total)


@router.get("/monthly-receipt", response_model=MonthlyReceipt)
async def monthly_receipt(patient_id: str, month: str, workplace_id: str):
    """One receipt with every paid attendance of the patient in the month at one workplace (reembolso de convênio)."""
    if len(month) != 7 or month[4] != "-":
        raise HTTPException(status_code=400, detail="Mês inválido (use AAAA-MM)")
    patient = await db.patients.find_one({"id": patient_id}, {"_id": 0, "name": 1, "cpf": 1})
    wp = await db.workplaces.find_one({"id": workplace_id}, {"_id": 0})
    if not patient or not wp:
        raise HTTPException(status_code=404, detail="Paciente ou local não encontrado")
    plans = await plans_map()
    appts = await db.appointments.find(
        {"patient_id": patient_id, "workplace_id": workplace_id, "status": "atendido", "paid": True,
         "date": {"$gte": f"{month}-01", "$lte": f"{month}-31"}},
        {"_id": 0},
    ).sort([("date", 1), ("time", 1)]).to_list(500)
    if not appts:
        raise HTTPException(status_code=400, detail="Nenhuma consulta paga deste paciente neste mês e local")
    items = [FinanceItem(id=a["id"], date=a["date"], time=a["time"], patient_id=patient_id, patient_name=patient["name"],
                         workplace_id=workplace_id, workplace_name=wp["name"], kind=a.get("kind", "consulta"), amount=_amount(a, wp, plans),
                         paid=True, payment_method=a.get("payment_method", ""), paid_at=a.get("paid_at", "")) for a in appts]
    st = await db.settings.find_one({"key": "main"}, {"_id": 0}) or {}
    return MonthlyReceipt(month=month, patient_id=patient_id, patient_name=patient["name"], patient_cpf=patient.get("cpf", ""),
                          workplace=Workplace(**wp), items=items, total=sum(i.amount for i in items),
                          doctor_name=st.get("doctor_name", ""), crm=st.get("crm", ""), crm_uf=st.get("crm_uf", ""))


@router.put("/goal")
async def put_goal(body: GoalIn):
    await db.settings.update_one({"key": "finance"}, {"$set": {"goal": body.goal}}, upsert=True)
    return {"goal": body.goal}


@router.post("/entries", response_model=FinanceEntry)
async def create_entry(body: FinanceEntryIn):
    obj = FinanceEntry(**{**body.model_dump(), "description": body.description.strip()})
    await db.finance_entries.insert_one(obj.model_dump())
    return obj


@router.delete("/entries/{id}")
async def delete_entry(id: str):
    res = await db.finance_entries.delete_one({"id": id})
    if not res.deleted_count:
        raise HTTPException(status_code=404, detail="Lançamento não encontrado")
    return {"ok": True}


# ---------- Despesas fixas ----------
@router.get("/recurring", response_model=list[RecurringExpense])
async def list_recurring():
    return await db.finance_recurring.find({}, {"_id": 0}).sort("created_at", 1).to_list(500)


@router.post("/recurring", response_model=RecurringExpense)
async def create_recurring(body: RecurringExpenseIn):
    obj = RecurringExpense(**{**body.model_dump(), "description": body.description.strip()}, start_month=today_iso()[:7])
    await db.finance_recurring.insert_one(obj.model_dump())
    await materialize_recurring()
    return obj


@router.put("/recurring/{id}", response_model=RecurringExpense)
async def update_recurring(id: str, body: RecurringExpenseIn):
    res = await db.finance_recurring.update_one({"id": id}, {"$set": {**body.model_dump(), "description": body.description.strip()}})
    if not res.matched_count:
        raise HTTPException(status_code=404, detail="Despesa fixa não encontrada")
    await materialize_recurring()
    return await db.finance_recurring.find_one({"id": id}, {"_id": 0})


@router.delete("/recurring/{id}")
async def delete_recurring(id: str):
    """Stops future launches; entries already launched stay in the history."""
    res = await db.finance_recurring.delete_one({"id": id})
    if not res.deleted_count:
        raise HTTPException(status_code=404, detail="Despesa fixa não encontrada")
    return {"ok": True}
