"""Idempotent seed: only fills empty collections. Run: cd /app/backend && python seed.py"""

import asyncio
import base64

from lib.db import db, ensure_indexes
from models.schemas import Exam, ExamGroup, Guidance, Medication, Patient, RxTemplate, Settings, Workplace


def svg_logo(initials: str, color: str) -> str:
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" viewBox="0 0 160 160">'
        f'<rect width="160" height="160" rx="32" fill="{color}"/>'
        f'<path d="M70 38h20v32h32v20H90v32H70V90H38V70h32z" fill="#ffffff" opacity="0.18"/>'
        f'<text x="80" y="98" font-family="Arial, sans-serif" font-size="52" font-weight="700" '
        f'fill="#ffffff" text-anchor="middle">{initials}</text></svg>'
    )
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()


WORKPLACES = [
    Workplace(name="Clínica São Lucas", address="Av. Paulista, 1500 - Sala 804, Bela Vista, São Paulo - SP", phone="(11) 3251-4400", logo=svg_logo("SL", "#0284C7")),
    Workplace(name="Hospital Materno-Infantil", address="Rua das Acácias, 220, Centro, Campinas - SP", phone="(19) 3232-1010", logo=svg_logo("HMI", "#16A34A")),
    Workplace(name="Consultório Central", address="Rua XV de Novembro, 87, Centro, Santos - SP", phone="(13) 3222-5566", logo=svg_logo("CC", "#0F172A")),
]

MEDS = [
    Medication(name="Amoxicilina", presentation="Suspensão oral 250mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=50, doses_per_day=3, conc_mg=250, conc_ml=5, max_dose_mg=500, duration_days=7, instructions="Tomar 5 mL de 8 em 8 horas por 7 dias.", pinned=True, usage_count=12),
    Medication(name="Amoxicilina + Clavulanato", presentation="Suspensão oral 400mg + 57mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=45, doses_per_day=2, conc_mg=400, conc_ml=5, max_dose_mg=875, duration_days=10, instructions="Tomar 5 mL de 12 em 12 horas por 10 dias.", usage_count=6),
    Medication(name="Azitromicina", presentation="Suspensão oral 200mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_dose", dose_mg_per_kg=10, doses_per_day=1, conc_mg=200, conc_ml=5, max_dose_mg=500, duration_days=5, instructions="Tomar 12,5 mL 1 vez ao dia por 5 dias.", pinned=True, usage_count=9),
    Medication(name="Dipirona", presentation="Solução oral gotas 500mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_dose", dose_mg_per_kg=15, doses_per_day=4, conc_mg=500, conc_ml=1, max_dose_mg=1000, drops_per_ml=20, notes="Se dor ou febre.", instructions="Tomar 40 gotas de 6 em 6 horas se dor ou febre.", pinned=True, usage_count=20),
    Medication(name="Paracetamol", presentation="Solução oral gotas 200mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_dose", dose_mg_per_kg=15, doses_per_day=4, conc_mg=200, conc_ml=1, max_dose_mg=750, drops_per_ml=20, notes="Se dor ou febre.", instructions="Tomar 35 gotas de 6 em 6 horas se dor ou febre.", pinned=True, usage_count=15),
    Medication(name="Ibuprofeno", presentation="Suspensão oral gotas 50mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_dose", dose_mg_per_kg=10, doses_per_day=3, conc_mg=50, conc_ml=1, max_dose_mg=400, drops_per_ml=10, notes="Se dor ou febre persistente.", instructions="Tomar 40 gotas de 8 em 8 horas se dor.", pinned=True, usage_count=11),
    Medication(name="Prednisolona", presentation="Solução oral 3mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=1, doses_per_day=1, conc_mg=3, conc_ml=1, max_dose_mg=40, duration_days=5, notes="Tomar pela manhã, após o café.", instructions="Tomar 13 mL pela manhã por 5 dias.", usage_count=5),
    Medication(name="Cefalexina", presentation="Suspensão oral 250mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=50, doses_per_day=4, conc_mg=250, conc_ml=5, max_dose_mg=500, duration_days=7, instructions="Tomar 10 mL de 6 em 6 horas por 7 dias.", usage_count=4),
    Medication(name="Sais para Reidratação Oral", presentation="Pó para solução oral - envelope", quantity="5 envelopes", instructions="Diluir 1 envelope em 1 litro de água filtrada. Oferecer em pequenos goles após cada evacuação líquida.", usage_count=8),
    Medication(name="Loratadina", presentation="Comprimido 10mg", quantity="10 comprimidos", instructions="Tomar 1 comprimido 1 vez ao dia por 5 dias.", usage_count=3),
    Medication(name="Dipirona", presentation="Comprimido 1g", quantity="10 comprimidos", instructions="Tomar 1 comprimido de 6 em 6 horas se dor ou febre.", usage_count=7),
    Medication(name="Amoxicilina", presentation="Cápsula 500mg", quantity="21 cápsulas", instructions="Tomar 1 cápsula de 8 em 8 horas por 7 dias.", usage_count=6),
    Medication(name="Omeprazol", presentation="Cápsula 20mg", quantity="30 cápsulas", instructions="Tomar 1 cápsula em jejum, 30 minutos antes do café da manhã.", usage_count=2),
    Medication(name="Losartana Potássica", presentation="Comprimido 50mg", quantity="Uso contínuo", instructions="Tomar 1 comprimido 1 vez ao dia.", usage_count=1),
]

EXTRA_MEDS = [
    Medication(name="Cefadroxila", presentation="Suspensão oral 250mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=30, doses_per_day=2, conc_mg=250, conc_ml=5, max_dose_mg=1000, duration_days=10, instructions="Tomar 5 mL de 12 em 12 horas por 10 dias."),
    Medication(name="Cefuroxima", presentation="Suspensão oral 250mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=30, doses_per_day=2, conc_mg=250, conc_ml=5, max_dose_mg=500, duration_days=10, instructions="Tomar 5 mL de 12 em 12 horas por 10 dias."),
    Medication(name="Claritromicina", presentation="Suspensão oral 250mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=15, doses_per_day=2, conc_mg=250, conc_ml=5, max_dose_mg=500, duration_days=10, instructions="Tomar 5 mL de 12 em 12 horas por 10 dias."),
    Medication(name="Sulfametoxazol + Trimetoprima", presentation="Suspensão oral 200mg + 40mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=8, doses_per_day=2, conc_mg=40, conc_ml=5, max_dose_mg=160, duration_days=10, notes="(Dose calculada pelo trimetoprima.)", instructions="Tomar 10 mL de 12 em 12 horas por 10 dias."),
    Medication(name="Metronidazol (benzoilmetronidazol)", presentation="Suspensão oral 40mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=30, doses_per_day=3, conc_mg=40, conc_ml=1, max_dose_mg=500, duration_days=7, instructions="Tomar 5 mL de 8 em 8 horas por 7 dias."),
    Medication(name="Nitazoxanida", presentation="Pó para suspensão oral 20mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_dose", dose_mg_per_kg=7.5, doses_per_day=2, conc_mg=20, conc_ml=1, max_dose_mg=500, duration_days=3, notes="Tomar junto com alimentos.", instructions="Tomar 7,5 mL de 12 em 12 horas por 3 dias."),
    Medication(name="Dexclorfeniramina", presentation="Solução oral 2mg/5mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=0.15, doses_per_day=3, conc_mg=2, conc_ml=5, max_dose_mg=2, duration_days=5, instructions="Tomar 5 mL de 8 em 8 horas por 5 dias."),
    Medication(name="Hidroxizina", presentation="Solução oral 2mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=2, doses_per_day=3, conc_mg=2, conc_ml=1, max_dose_mg=25, duration_days=5, notes="Pode causar sonolência.", instructions="Tomar 10 mL de 8 em 8 horas por 5 dias."),
    Medication(name="Dexametasona", presentation="Elixir 0,1mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_dose", dose_mg_per_kg=0.15, doses_per_day=1, conc_mg=0.1, conc_ml=1, max_dose_mg=10, notes="Dose única.", instructions="Tomar dose única conforme orientação."),
    Medication(name="Sulfato Ferroso", presentation="Solução oral gotas 25mg Fe/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=1, doses_per_day=1, conc_mg=25, conc_ml=1, max_dose_mg=60, drops_per_ml=20, notes="Profilaxia. Tomar 30 minutos antes de uma refeição, com suco cítrico.", instructions="Tomar 1 gota por kg 1 vez ao dia."),
    Medication(name="Cetirizina", presentation="Solução oral 1mg/mL", quantity="1 frasco", instructions="2 a 6 anos: tomar 2,5 mL de 12 em 12 horas. 6 a 12 anos: tomar 5 mL de 12 em 12 horas. Por 5 dias."),
    Medication(name="Desloratadina", presentation="Xarope 0,5mg/mL", quantity="1 frasco", instructions="1 a 5 anos: tomar 2,5 mL 1 vez ao dia. 6 a 11 anos: tomar 5 mL 1 vez ao dia. Por 5 dias."),
    Medication(name="Albendazol", presentation="Suspensão oral 400mg/10mL", quantity="1 frasco", instructions="Maiores de 2 anos: tomar 10 mL em dose única. Repetir após 14 dias."),
    Medication(name="Nistatina", presentation="Suspensão oral 100.000 UI/mL", quantity="1 frasco", route="Uso tópico oral", instructions="Aplicar 1 mL em cada lado da boca 4 vezes ao dia, por 7 dias."),
    Medication(name="Simeticona", presentation="Emulsão oral gotas 75mg/mL", quantity="1 frasco", instructions="Lactentes: 3 a 5 gotas até 3 vezes ao dia, se cólicas."),
    Medication(name="Salbutamol", presentation="Aerossol 100mcg/jato", quantity="1 frasco", route="Via inalatória", instructions="Fazer 2 a 4 jatos com espaçador de 4 em 4 horas se tosse ou falta de ar."),
    Medication(name="Cloreto de Sódio 0,9%", presentation="Solução nasal", quantity="1 frasco", route="Via nasal", instructions="Aplicar 2 a 3 gotas ou jatos em cada narina várias vezes ao dia."),
    Medication(name="Vitamina D3 (colecalciferol)", presentation="Solução oral gotas 200 UI/gota", quantity="1 frasco", instructions="Tomar 2 gotas (400 UI) 1 vez ao dia, uso contínuo."),
    Medication(name="Ondansetrona", presentation="Comprimido orodispersível 4mg", quantity="6 comprimidos", route="Via sublingual", instructions="Dissolver 1 comprimido na boca de 8 em 8 horas se náuseas ou vômitos."),
    Medication(name="Oseltamivir", presentation="Cápsula 30mg / 45mg / 75mg", quantity="10 cápsulas", instructions="Até 15 kg: 30 mg; 15–23 kg: 45 mg; 23–40 kg: 60 mg; acima de 40 kg: 75 mg — de 12 em 12 horas por 5 dias."),
    # Controle especial (Portaria 344/98 — lista C1): saem na receita de 2 vias
    Medication(name="Carbamazepina", presentation="Suspensão oral 20mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=10, doses_per_day=2, conc_mg=20, conc_ml=1, max_dose_mg=400, notes="Uso contínuo.", instructions="Tomar conforme orientação, de 12 em 12 horas, uso contínuo.", controlled=True),
    Medication(name="Ácido Valproico", presentation="Xarope 50mg/mL", quantity="1 frasco", pediatric=True, dose_mode="mg_kg_day", dose_mg_per_kg=15, doses_per_day=2, conc_mg=50, conc_ml=1, max_dose_mg=500, notes="Uso contínuo.", instructions="Tomar conforme orientação, de 12 em 12 horas, uso contínuo.", controlled=True),
    Medication(name="Risperidona", presentation="Solução oral 1mg/mL", quantity="1 frasco", instructions="Tomar 0,25 mL 1 vez ao dia, à noite, uso contínuo.", controlled=True),
    Medication(name="Amitriptilina", presentation="Comprimido 25mg", quantity="30 comprimidos", instructions="Tomar 1 comprimido à noite, uso contínuo.", controlled=True),
    Medication(name="Sertralina", presentation="Comprimido 50mg", quantity="30 comprimidos", instructions="Tomar 1 comprimido pela manhã, uso contínuo.", controlled=True),
    Medication(name="Fluoxetina", presentation="Cápsula 20mg", quantity="30 cápsulas", instructions="Tomar 1 cápsula pela manhã, uso contínuo.", controlled=True),
]

EXAMS = [
    Exam(name="Hemograma completo", category="Laboratorial"),
    Exam(name="Proteína C reativa (PCR)", category="Laboratorial"),
    Exam(name="Glicemia de jejum", category="Laboratorial", preparation="Jejum de 8 horas."),
    Exam(name="Perfil lipídico", category="Laboratorial", preparation="Jejum de 12 horas."),
    Exam(name="TSH e T4 livre", category="Laboratorial"),
    Exam(name="Ureia e Creatinina", category="Laboratorial"),
    Exam(name="Urina tipo 1 (EAS)", category="Laboratorial", preparation="Primeira urina da manhã, jato médio."),
    Exam(name="Urocultura com antibiograma", category="Laboratorial", preparation="Higiene local, jato médio."),
    Exam(name="Parasitológico de fezes", category="Laboratorial"),
    Exam(name="Raio-X de tórax PA e perfil", category="Imagem"),
    Exam(name="Ultrassonografia de abdome total", category="Imagem", preparation="Jejum de 6 horas."),
    Exam(name="Eletrocardiograma", category="Cardiológico"),
]

GUIDANCE = [
    Guidance(name="Levar este encaminhamento, documentos pessoais e exames anteriores no dia da consulta."),
    Guidance(name="Manter as medicações em uso até a avaliação do especialista."),
    Guidance(name="Retornar ao serviço em caso de piora dos sintomas."),
    Guidance(name="Procurar o pronto-socorro em caso de febre persistente, falta de ar ou dor intensa."),
    Guidance(name="Agendar a consulta pela Unidade Básica de Saúde de referência."),
]

PATIENTS = [
    Patient(name="Maria Clara Souza", birth_date="2020-03-14", weight_kg=18.5, sex="F", phone="(11) 98877-1234", allergies=""),
    Patient(name="João Pedro Oliveira", birth_date="2022-08-02", weight_kg=12.0, sex="M", phone="(11) 97766-4321", allergies="Dipirona"),
    Patient(name="Helena Martins", birth_date="2017-11-21", weight_kg=27.0, sex="F", phone="(19) 99654-0011"),
    Patient(name="Lucas Ferreira", birth_date="2024-01-10", weight_kg=9.2, sex="M", phone="(13) 99123-8877"),
    Patient(name="Ana Beatriz Lima", birth_date="1988-05-30", weight_kg=64.0, sex="F", phone="(11) 99555-3322"),
    Patient(name="Carlos Alberto Santos", birth_date="1962-09-17", weight_kg=82.0, sex="M", phone="(11) 98444-2211", allergies="Penicilina"),
]


async def seed_if_empty(col: str, items: list) -> None:
    if await db[col].count_documents({}) == 0:
        await db[col].insert_many([i.model_dump() for i in items])
        print(f"seeded {col}: {len(items)}")


# Usual (FDA-style) pregnancy category and lactation reference — prefilled only where empty; doctor must review.
SAFETY = {
    "Amoxicilina": ("B", "compativel"), "Amoxicilina + Clavulanato": ("B", "compativel"), "Azitromicina": ("B", "compativel"),
    "Dipirona": ("C", "cautela"), "Paracetamol": ("B", "compativel"), "Ibuprofeno": ("C", "compativel"),
    "Prednisolona": ("C", "compativel"), "Cefalexina": ("B", "compativel"), "Loratadina": ("B", "compativel"),
    "Omeprazol": ("C", "compativel"), "Losartana Potássica": ("D", "cautela"), "Cefadroxila": ("B", "compativel"),
    "Cefuroxima": ("B", "compativel"), "Claritromicina": ("C", "compativel"), "Sulfametoxazol + Trimetoprima": ("C", "cautela"),
    "Metronidazol (benzoilmetronidazol)": ("B", "cautela"), "Nitazoxanida": ("B", "cautela"), "Dexclorfeniramina": ("B", "cautela"),
    "Hidroxizina": ("C", "cautela"), "Dexametasona": ("C", "compativel"), "Sulfato Ferroso": ("A", "compativel"),
    "Cetirizina": ("B", "compativel"), "Desloratadina": ("C", "compativel"), "Albendazol": ("C", "cautela"),
    "Nistatina": ("C", "compativel"), "Salbutamol": ("C", "compativel"), "Ondansetrona": ("B", "compativel"),
    "Oseltamivir": ("C", "compativel"), "Carbamazepina": ("D", "compativel"), "Ácido Valproico": ("D", "cautela"),
    "Risperidona": ("C", "cautela"), "Amitriptilina": ("C", "compativel"), "Sertralina": ("C", "compativel"),
    "Fluoxetina": ("C", "cautela"), "Sais para Reidratação Oral": ("A", "compativel"), "Cloreto de Sódio 0,9%": ("A", "compativel"),
}
SAFETY_NOTES = {
    "Ibuprofeno": "Evitar no 3º trimestre (categoria D).",
    "Dipirona": "Evitar no 1º e 3º trimestres.",
    "Losartana Potássica": "Contraindicada no 2º e 3º trimestres.",
    "Sulfametoxazol + Trimetoprima": "Evitar no 1º trimestre e próximo ao parto.",
}


async def apply_safety_defaults() -> int:
    """Fill pregnancy/lactation only on medications where both are still empty."""
    n = 0
    for name, (cat, lact) in SAFETY.items():
        res = await db.medications.update_many(
            {"name": name, "pregnancy_category": {"$in": ["", None]}, "lactation": {"$in": ["", None]}},
            {"$set": {"pregnancy_category": cat, "lactation": lact, "pregnancy_lactation_notes": SAFETY_NOTES.get(name, "")}},
        )
        n += res.modified_count
    return n


PROTOCOLS = [
    ("Amigdalite", [("Azitromicina", "Suspensão oral 200mg/5mL"), ("Ibuprofeno", "Suspensão oral gotas 50mg/mL")], "Repouso, boa hidratação e alimentos pastosos/frios. Retornar se febre persistir por mais de 48 horas."),
    ("Febre e dor", [("Dipirona", "Solução oral gotas 500mg/mL"), ("Paracetamol", "Solução oral gotas 200mg/mL")], "Alternar os antitérmicos somente se necessário. Oferecer bastante líquido."),
    ("Diarreia aguda", [("Sais para Reidratação Oral", "Pó para solução oral - envelope"), ("Nitazoxanida", "Pó para suspensão oral 20mg/mL")], "Manter alimentação e aumentar a oferta de líquidos. Retornar se sangue nas fezes, vômitos persistentes ou sinais de desidratação."),
]

EXAM_GROUPS = [
    ("Check-up adulto", ["Hemograma completo", "Glicemia de jejum", "Perfil lipídico", "TSH e T4 livre", "Ureia e Creatinina", "Urina tipo 1 (EAS)"]),
    ("Infecção urinária", ["Urina tipo 1 (EAS)", "Urocultura com antibiograma"]),
    ("Investigação de febre", ["Hemograma completo", "Proteína C reativa (PCR)", "Urina tipo 1 (EAS)", "Raio-X de tórax PA e perfil"]),
]


async def seed_protocols() -> None:
    """Example ready-made prescriptions and exam groups (only when their collections are empty)."""
    if await db.rx_templates.count_documents({}) == 0:
        for name, meds, notes in PROTOCOLS:
            ids = []
            for mname, pres in meds:
                m = await db.medications.find_one({"name": mname, "presentation": pres}, {"_id": 0, "id": 1})
                if m:
                    ids.append(m["id"])
            if ids:
                await db.rx_templates.insert_one(RxTemplate(name=name, medication_ids=ids, notes=notes).model_dump())
        print("seeded rx_templates")
    if await db.exam_groups.count_documents({}) == 0:
        for name, exams in EXAM_GROUPS:
            docs = await db.exams.find({"name": {"$in": exams}}, {"_id": 0, "id": 1}).to_list(100)
            if docs:
                await db.exam_groups.insert_one(ExamGroup(name=name, exam_ids=[d["id"] for d in docs]).model_dump())
        print("seeded exam_groups")


async def add_missing_meds(items: list[Medication]) -> int:
    """Add medications whose name+presentation don't exist yet (never touches existing ones)."""
    added = 0
    for m in items:
        if not await db.medications.find_one({"name": m.name, "presentation": m.presentation}):
            await db.medications.insert_one(m.model_dump())
            added += 1
    return added


async def seed() -> None:
    await ensure_indexes()
    await seed_if_empty("workplaces", WORKPLACES)
    await seed_if_empty("medications", MEDS + EXTRA_MEDS)
    await apply_safety_defaults()
    await seed_if_empty("exams", EXAMS)
    await seed_if_empty("guidance", GUIDANCE)
    await seed_if_empty("patients", PATIENTS)
    await seed_protocols()
    if not await db.settings.find_one({"key": "main"}):
        first = await db.workplaces.find_one({}, sort=[("name", 1)])
        s = Settings(active_workplace_id=first["id"] if first else None)  # doctor data is set (and signed) in Configurações
        await db.settings.insert_one({"key": "main", **s.model_dump()})
        print("seeded settings")


async def main() -> None:
    import sys

    await seed()
    if "--extras" in sys.argv:
        print("extra medications added:", await add_missing_meds(EXTRA_MEDS))
    if "--safety" in sys.argv:
        print("pregnancy/lactation prefilled:", await apply_safety_defaults())


if __name__ == "__main__":
    asyncio.run(main())
