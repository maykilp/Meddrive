"""Encrypted data backup (.meddrive), restore, and sending through the user's own mailbox (SMTP).

The file is a zip of the data collections (no license, no e-mail settings), encrypted with Fernet:
only MedDrive opens it. The mailbox app password is stored encrypted in `backup_config`.
"""

import base64
import hashlib
import io
import json
import smtplib
import ssl
import zipfile
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken

from lib import filestore
from lib.db import FILE_MODE, db

MAGIC = b"MEDDRIVE-BACKUP-1\n"
BACKUP_COLLECTIONS = [c for c in filestore.COLLECTIONS if c not in ("license", "backup_config")]
REMIND_AFTER = timedelta(days=30)
MAX_BYTES = 20 * 1024 * 1024  # stays under the 25 MB attachment limit of Gmail/Outlook/Yahoo

_FILE_KEY = base64.urlsafe_b64encode(hashlib.sha256(b"MedDrive-backup-v1|7f3c9a2e5b8d41f0a6c3e9b2d7f14a58").digest())
_PASS_KEY = base64.urlsafe_b64encode(hashlib.sha256(b"MedDrive-smtp-v1|c41e8b7a2d9f63e05b1a7c4d8e2f9b36").digest())

# e-mail domain → (SMTP host, port, security)
PRESETS = {
    "gmail.com": ("smtp.gmail.com", 465, "ssl"),
    "googlemail.com": ("smtp.gmail.com", 465, "ssl"),
    "outlook.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "hotmail.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "live.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "msn.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "yahoo.com": ("smtp.mail.yahoo.com", 465, "ssl"),
    "yahoo.com.br": ("smtp.mail.yahoo.com", 465, "ssl"),
    "icloud.com": ("smtp.mail.me.com", 587, "starttls"),
    "me.com": ("smtp.mail.me.com", 587, "starttls"),
    "uol.com.br": ("smtps.uol.com.br", 587, "starttls"),
    "bol.com.br": ("smtps.bol.com.br", 587, "starttls"),
}


def preset_for(email: str) -> Optional[tuple[str, int, str]]:
    return PRESETS.get(email.rsplit("@", 1)[-1].strip().lower()) if "@" in email else None


def encrypt_password(p: str) -> str:
    return Fernet(_PASS_KEY).encrypt(p.encode()).decode()


def decrypt_password(token: str) -> str:
    try:
        return Fernet(_PASS_KEY).decrypt(token.encode()).decode()
    except (InvalidToken, ValueError):
        return ""


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def get_config() -> dict:
    return await db.backup_config.find_one({"key": "main"}, {"_id": 0}) or {"key": "main"}


async def save_config(changes: dict) -> dict:
    await db.backup_config.update_one({"key": "main"}, {"$set": changes}, upsert=True)
    if FILE_MODE:
        await filestore.save(["backup_config"])
    return await get_config()


def is_due(cfg: dict) -> tuple[bool, Optional[int]]:
    last = cfg.get("last_backup_at")
    if not last:
        return True, None
    days = (_now() - datetime.fromisoformat(last)).days
    return _now() - datetime.fromisoformat(last) >= REMIND_AFTER, days


async def build_backup() -> tuple[str, bytes, dict]:
    """(filename, encrypted bytes, counts)."""
    buf = io.BytesIO()
    counts = {}
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name in BACKUP_COLLECTIONS:
            raw = await filestore.dump_collection(name)
            z.writestr(f"{name}.json", raw)
            counts[name] = len(json.loads(raw))
        z.writestr("meta.json", json.dumps({"app": "MedDrive", "created_at": _now().isoformat(), "counts": counts}))
    data = MAGIC + Fernet(_FILE_KEY).encrypt(buf.getvalue())
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    return f"MedDrive-backup-{stamp}.meddrive", data, counts


def read_backup(data: bytes) -> dict[str, list]:
    """Decrypt + parse; raises ValueError with a user-facing message."""
    if not data.startswith(MAGIC):
        raise ValueError("Este arquivo não é um backup do MedDrive")
    try:
        raw = Fernet(_FILE_KEY).decrypt(data[len(MAGIC):])
    except InvalidToken:
        raise ValueError("Backup corrompido ou alterado")
    out: dict[str, list] = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names = set(z.namelist())
        if "meta.json" not in names:
            raise ValueError("Backup incompleto")
        for name in BACKUP_COLLECTIONS:
            if f"{name}.json" in names:
                docs = json.loads(z.read(f"{name}.json").decode("utf-8"), object_hook=filestore._hook)
                if not isinstance(docs, list):
                    raise ValueError(f"Backup inválido ({name})")
                out[name] = docs
    return out


async def restore(collections: dict[str, list]) -> dict:
    counts = {}
    for name, docs in collections.items():
        await db[name].delete_many({})
        clean = [{k: v for k, v in d.items() if k != "_id"} for d in docs if isinstance(d, dict)]
        if clean:
            await db[name].insert_many(clean)
        counts[name] = len(clean)
    if FILE_MODE:
        await filestore.save(list(collections))
    return counts


async def mark_done(method: str) -> None:
    await save_config({"last_backup_at": _now().isoformat(), "last_backup_method": method})


def send_mail(cfg: dict, password: str, filename: str, data: bytes, counts: dict) -> None:
    """Blocking SMTP send (call via asyncio.to_thread)."""
    sender, to = cfg["email"], cfg.get("send_to") or cfg["email"]
    msg = EmailMessage()
    msg["From"], msg["To"] = sender, to
    msg["Subject"] = f"Backup MedDrive — {datetime.now():%d/%m/%Y %H:%M}"
    summary = ", ".join(f"{k}: {v}" for k, v in counts.items())
    msg.set_content(
        "Backup automático dos dados do MedDrive em anexo.\n\n"
        "O arquivo é protegido: só pode ser aberto pelo MedDrive, em Configurações > Backup > Restaurar backup.\n\n"
        f"Conteúdo: {summary}\n"
    )
    msg.add_attachment(data, maintype="application", subtype="octet-stream", filename=filename)
    host, port, sec = cfg["smtp_host"], int(cfg["smtp_port"]), cfg.get("smtp_security", "ssl")
    ctx = ssl.create_default_context()
    if sec == "ssl":
        with smtplib.SMTP_SSL(host, port, context=ctx, timeout=40) as s:
            s.login(sender, password)
            s.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=40) as s:
            s.ehlo()
            if sec == "starttls":
                s.starttls(context=ctx)
                s.ehlo()
            if password and (sec == "starttls" or s.has_extn("auth")):
                s.login(sender, password)
            s.send_message(msg)
