"""MedDrive licence: online check (max. once a day) against a read-only Google Sheet.

Sheet columns: A nome | B CRM | C data de vencimento (dd/mm/aaaa) | D status (Ativo/Inativo).
The last result is kept locally (collection `license`, on the pendrive `dados/license.json`) and
signed with HMAC-SHA256, so editing the date/status/postponements by hand is detected and refused.
A clock set back (earlier than the last use) blocks too; a successful online check uses the
server time from Google's HTTP `Date` header as the trusted clock. Offline: no check, the saved
expiry date keeps being enforced.
"""

import asyncio
import csv
import hashlib
import hmac
import io
import json
import logging
import os
import re
import time
import urllib.request
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Optional
from zoneinfo import ZoneInfo

from lib import filestore
from lib.db import FILE_MODE, db

logger = logging.getLogger(__name__)

SHEET_ID = "1KYwz8r6PQkpltlkbniK_ZXcKB5Ltc7DbP3ql6AudnV0"
SHEET_URL = f"https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv"
CONTACT = "+5546999722834"
WARN_DAYS = 7
GRACE_DAYS = 7
MAX_POSTPONES = 2
CLOCK_TOLERANCE = timedelta(hours=26)
OFFLINE_RETRY_SECONDS = 3600  # after a failed (offline) attempt, try again at most once an hour
TOUCH_EVERY = timedelta(minutes=10)

_KEY = hashlib.sha256(
    bytes.fromhex("d01361b3b55519e0a8e491b2b447b39f069724748dc2a1972676fbb5c9605c19") + b"|MedDrive-licenca-v1"
).digest()

_lock = asyncio.Lock()
_last_fail: dict[str, Optional[float]] = {"t": None}


# ---------- helpers ----------
def _tz() -> ZoneInfo:
    return ZoneInfo(os.environ.get("APP_TZ", "UTC"))


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s or "")


def _dt(s: str) -> datetime:
    d = datetime.fromisoformat(s)
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _br(d: str) -> str:
    return "/".join(reversed(d.split("-"))) if d else ""


def _parse_date(s: str) -> Optional[date]:
    s = (s or "").strip()
    for fmt in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d", "%d-%m-%Y", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def _sign(st: dict) -> str:
    payload = {k: v for k, v in st.items() if k not in ("sig", "key", "_id")}
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    return hmac.new(_KEY, raw, hashlib.sha256).hexdigest()


def _valid(st: Optional[dict]) -> bool:
    if not st or not isinstance(st.get("sig"), str):
        return False
    try:
        return hmac.compare_digest(_sign(st), st["sig"])
    except Exception:
        return False


async def _load() -> Optional[dict]:
    return await db.license.find_one({"key": "main"}, {"_id": 0})


async def _store(st: dict) -> dict:
    st = {k: v for k, v in st.items() if k not in ("_id", "sig", "key")}
    st["sig"] = _sign(st)
    await db.license.replace_one({"key": "main"}, {**st, "key": "main"}, upsert=True)
    if FILE_MODE:
        await filestore.save(["license"])
    return st


def _today(st: dict) -> date:
    """Trusted 'today': never earlier than the last recorded use."""
    return max(_utcnow(), _dt(st["last_seen"])).astimezone(_tz()).date()


# ---------- online check ----------
def _fetch_sheet() -> tuple[list[list[str]], Optional[datetime]]:
    req = urllib.request.Request(SHEET_URL, headers={"User-Agent": "MedDrive/1.0"})
    with urllib.request.urlopen(req, timeout=8) as r:
        ctype = r.headers.get("Content-Type", "")
        body = r.read().decode("utf-8-sig", errors="replace")
        hdr = r.headers.get("Date")
    if "csv" not in ctype:
        raise RuntimeError(f"planilha indisponível ({ctype})")
    server_time = None
    if hdr:
        try:
            server_time = parsedate_to_datetime(hdr)
        except (TypeError, ValueError):
            server_time = None
    return list(csv.reader(io.StringIO(body))), server_time


async def _check_online(crm: str, old: Optional[dict], had_state: bool) -> Optional[dict]:
    try:
        rows, server_time = await asyncio.to_thread(_fetch_sheet)
    except Exception as e:  # offline / blocked → keep the saved result
        logger.info("Verificação de licença não realizada: %s", e)
        _last_fail["t"] = time.monotonic()
        return None
    _last_fail["t"] = None
    now = (server_time or _utcnow()).astimezone(timezone.utc)
    today = now.astimezone(_tz()).date()

    row = next((r for r in rows[1:] if len(r) >= 2 and _digits(r[1]) and _digits(r[1]) == crm), None)
    if row is None:
        status, expires, name = "nao_encontrado", "", ""
    else:
        name = row[0].strip()
        d = _parse_date(row[2]) if len(row) > 2 else None
        expires = d.isoformat() if d else ""
        active = len(row) > 3 and row[3].strip().lower() == "ativo"
        status = "ativo" if (active and d) else "inativo"

    if old:
        st = dict(old)
    else:
        # no (valid) local record: deleting/altering the file must not hand out fresh postponements
        st = {"postpones": MAX_POSTPONES if had_state else 0, "grace_until": ""}
    expired = status != "ativo" or date.fromisoformat(expires) < today
    if status == "ativo" and not expired:  # renewed / valid → postponements start over next time
        st["postpones"], st["grace_until"] = 0, ""
    st.update(crm=crm, name=name, status=status, expires=expires,
              checked_at=now.isoformat(), last_seen=now.isoformat())
    return await _store(st)


# ---------- evaluation ----------
def _result(state: str, reason: str, message: str, **kw) -> dict:
    base = {
        "state": state, "reason": reason, "allowed": state in ("ok", "warning", "grace"), "message": message,
        "name": "", "crm": "", "expires": "", "days_left": None, "grace_until": "", "postpones_used": 0,
        "postpones_left": MAX_POSTPONES, "can_postpone": False, "last_check": "", "contact": CONTACT, "offline": False,
    }
    base.update(kw)
    return base


def _evaluate(st: Optional[dict], tampered: bool, crm: str) -> dict:
    if not crm:
        return _result("blocked", "no_crm", "Cadastre seu CRM em Configurações para verificar a licença do sistema.")
    if tampered:
        return _result("blocked", "tampered", "Os dados da licença foram alterados fora do sistema. "
                       "Conecte o computador à internet e clique em \"Verificar novamente\".", crm=crm)
    if not st or st.get("crm") != crm:
        return _result("blocked", "unverified", "A licença ainda não foi verificada para este CRM. "
                       "Conecte o computador à internet e clique em \"Verificar novamente\".", crm=crm)
    if _utcnow() < _dt(st["last_seen"]) - CLOCK_TOLERANCE:
        return _result("blocked", "clock", "A data do computador está incorreta (anterior à última utilização). "
                       "Corrija a data e a hora do Windows ou conecte à internet.", crm=crm)

    today = _today(st)
    used = int(st.get("postpones", 0))
    info = dict(crm=crm, name=st.get("name", ""), expires=st.get("expires", ""), last_check=st.get("checked_at", ""),
                postpones_used=used, postpones_left=max(0, MAX_POSTPONES - used))
    if st.get("status") == "nao_encontrado":
        return _result("blocked", "not_found", f"O CRM {crm} não está cadastrado na lista de licenças. "
                       "Entre em contato para liberar o sistema.", **info)

    exp = date.fromisoformat(st["expires"]) if st.get("expires") else None
    inactive = st.get("status") != "ativo"
    if not inactive and exp and today <= exp:
        days = (exp - today).days
        if days <= WARN_DAYS:
            when = "hoje" if days == 0 else ("amanhã" if days == 1 else f"em {days} dias")
            return _result("warning", "expiring", f"Sua licença vence {when} ({_br(st['expires'])}). "
                           "Entre em contato para renovar.", days_left=days, **info)
        return _result("ok", "ok", f"Licença válida até {_br(st['expires'])}.", days_left=days, **info)

    grace = st.get("grace_until") or ""
    why = "está inativa" if inactive else f"venceu em {_br(st.get('expires', ''))}"
    if grace and today <= date.fromisoformat(grace):
        days = (date.fromisoformat(grace) - today).days
        return _result("grace", "postponed", f"Sua licença {why}. Uso postergado até {_br(grace)}. "
                       "Entre em contato para renovar.", days_left=days, grace_until=grace, **info)
    if used < MAX_POSTPONES:
        return _result("expired", "expired", f"Sua licença {why}. Deseja postergar por mais {GRACE_DAYS} dias "
                       "até a renovação?", can_postpone=True, grace_until=grace, **info)
    return _result("blocked", "expired_final", f"Sua licença {why} e os prazos extras já foram utilizados. "
                   "Entre em contato para renovar e liberar o sistema.", grace_until=grace, **info)


# ---------- public API ----------
async def status(crm: str, online: bool = True, force: bool = False) -> dict:
    """Current licence state. `online`: allowed to do the daily check; `force`: check now."""
    crm = _digits(crm)
    async with _lock:
        st = await _load()
        valid = _valid(st)
        offline = False
        if crm and (online or force):
            today_local = _utcnow().astimezone(_tz()).date()
            checked = valid and st.get("crm") == crm and _dt(st["checked_at"]).astimezone(_tz()).date() == today_local
            backoff = _last_fail["t"] is not None and time.monotonic() - _last_fail["t"] < OFFLINE_RETRY_SECONDS
            if force or (not checked and not backoff):
                new = await _check_online(crm, st if valid else None, had_state=st is not None)
                if new:
                    st, valid = new, True
                else:
                    offline = True
        result = _evaluate(st if valid else None, st is not None and not valid, crm)
        if valid and result["reason"] != "clock" and _utcnow() - _dt(st["last_seen"]) > TOUCH_EVERY:
            st["last_seen"] = _utcnow().isoformat()
            await _store(st)
        result["offline"] = offline
        return result


async def postpone(crm: str) -> Optional[dict]:
    """Grant 7 more days (max. MAX_POSTPONES per expiry). Returns the new state, or None if not allowed."""
    crm = _digits(crm)
    async with _lock:
        st = await _load()
        if not _valid(st):
            return None
        if not _evaluate(st, False, crm)["can_postpone"]:
            return None
        st["grace_until"] = (_today(st) + timedelta(days=GRACE_DAYS)).isoformat()
        st["postpones"] = int(st.get("postpones", 0)) + 1
        st["last_seen"] = max(_utcnow(), _dt(st["last_seen"])).isoformat()
        st = await _store(st)
        return _evaluate(st, False, crm)
