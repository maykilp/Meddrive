"""JSON-file persistence for the portable (pendrive) build, plus the export used to create it."""

import asyncio
import json
import os
from datetime import datetime
from pathlib import Path

from lib.db import db

COLLECTIONS = ["workplaces", "patients", "medications", "exams", "guidance", "rx_templates", "exam_groups", "settings", "documents", "license", "backup_config", "report_templates", "appointments", "agenda_blocks", "finance_entries", "finance_recurring", "health_plans", "referral_templates", "clinical_phrases", "terms_acceptance"]

# Which collections a write under each /api prefix can touch.
WRITE_MAP = {
    "/api/documents": ["documents", "medications", "appointments"],
    "/api/appointments": ["appointments"],
    "/api/agenda-blocks": ["agenda_blocks"],
    "/api/finance": ["finance_entries", "finance_recurring", "settings", "appointments"],
    "/api/health-plans": ["health_plans"],
    "/api/referral-templates": ["referral_templates"],
    "/api/clinical-phrases": ["clinical_phrases"],
    "/api/terms": ["terms_acceptance"],
    "/api/workplaces": ["workplaces", "settings"],
    "/api/patients": ["patients"],
    "/api/medications": ["medications"],
    "/api/exams": ["exams"],
    "/api/exam-groups": ["exam_groups"],
    "/api/rx-templates": ["rx_templates"],
    "/api/guidance": ["guidance"],
    "/api/settings": ["settings"],
    "/api/license": ["license"],
    "/api/portable": [],
    "/api/backup": ["backup_config"],
    "/api/report-templates": ["report_templates"],
}

_lock = asyncio.Lock()


def data_dir() -> Path:
    return Path(os.environ.get("DATA_DIR", "dados"))


def _default(o):
    if isinstance(o, datetime):
        return {"$dt": o.isoformat()}
    raise TypeError(f"not serializable: {type(o)}")


def _hook(d: dict):
    if len(d) == 1 and "$dt" in d:
        return datetime.fromisoformat(d["$dt"])
    return d


async def dump_collection(name: str) -> str:
    docs = await db[name].find({}, {"_id": 0}).to_list(None)
    return json.dumps(docs, default=_default, ensure_ascii=False)


async def load_all() -> None:
    d = data_dir()
    d.mkdir(parents=True, exist_ok=True)
    for name in COLLECTIONS:
        p = d / f"{name}.json"
        if p.exists():
            docs = json.loads(p.read_text("utf-8") or "[]", object_hook=_hook)
            if docs:
                await db[name].insert_many(docs)


async def save(names: list[str]) -> None:
    async with _lock:
        d = data_dir()
        d.mkdir(parents=True, exist_ok=True)
        for name in names:
            p = d / f"{name}.json"
            tmp = p.with_suffix(".tmp")
            tmp.write_text(await dump_collection(name), "utf-8")
            os.replace(tmp, p)


async def save_for_path(path: str) -> None:
    for prefix, names in WRITE_MAP.items():
        if path.startswith(prefix):
            return await save(names)
    await save(COLLECTIONS)
