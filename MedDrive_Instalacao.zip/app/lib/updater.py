"""Restart hook for the pendrive self-update: run_portable.py registers its uvicorn Server here."""

import asyncio
from typing import Any, Optional

SERVER: Optional[Any] = None  # uvicorn.Server when started by run_portable.py


def request_restart(delay: float = 1.5) -> bool:
    """Stop the server shortly (after the HTTP response is sent); run_portable.py then applies the
    staged update and starts again. False when not running under run_portable.py."""
    if SERVER is None:
        return False
    asyncio.get_running_loop().call_later(delay, lambda: setattr(SERVER, "should_exit", True))
    return True
