"""Generic CRUD router factory for simple name-searchable collections."""

import re

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from lib.db import db


def crud_router(prefix: str, collection: str, model_in: type[BaseModel], model: type[BaseModel]) -> APIRouter:
    router = APIRouter(prefix=prefix)
    col = db[collection]

    @router.get("", response_model=list[model])
    async def list_items(q: str = ""):
        filt = {"name": {"$regex": re.escape(q), "$options": "i"}} if q else {}
        return await col.find(filt, {"_id": 0}).sort("name", 1).to_list(5000)

    @router.get("/{id}", response_model=model)
    async def get_item(id: str):
        doc = await col.find_one({"id": id}, {"_id": 0})
        if not doc:
            raise HTTPException(status_code=404, detail="Não encontrado")
        return doc

    @router.post("", response_model=model)
    async def create_item(body: model_in):  # type: ignore[valid-type]
        obj = model(**body.model_dump())
        await col.insert_one(obj.model_dump())
        return obj

    @router.put("/{id}", response_model=model)
    async def update_item(id: str, body: model_in):  # type: ignore[valid-type]
        res = await col.update_one({"id": id}, {"$set": body.model_dump()})
        if res.matched_count == 0:
            raise HTTPException(status_code=404, detail="Não encontrado")
        return await col.find_one({"id": id}, {"_id": 0})

    @router.delete("/{id}")
    async def delete_item(id: str):
        res = await col.delete_one({"id": id})
        if res.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Não encontrado")
        return {"ok": True}

    return router
