"""Tamper-proof doctor data (name, CRM, RQEs) — Settings has no password anymore.

The doctor data is signed with an Ed25519 key embedded in the app; only data saved through the
app (PUT /api/settings/doctor) carries a valid signature, so editing the database by hand is
detected and refused (documents are blocked until the data is saved again in Settings).
Access to the system itself is controlled by the licence (Google Sheet, by CRM).
"""

import json

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

# same key pair as before (signatures already saved stay valid)
_SIGNING_KEY = Ed25519PrivateKey.from_private_bytes(bytes.fromhex("37bf586bf2155fd595ca2894d803bbcae097cf4fe8ad30013d8dc68dc6d8a872"))
PUBLIC_KEY = bytes.fromhex("026e57fef7a491c45392a1ac57572005888f9b48d1d90e21963078b4327159f8")


def signing_key() -> Ed25519PrivateKey:
    return _SIGNING_KEY


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()


def sign(key: Ed25519PrivateKey, payload: dict) -> str:
    return key.sign(_canonical(payload)).hex()


def verify(payload: dict, sig_hex: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(PUBLIC_KEY).verify(bytes.fromhex(sig_hex), _canonical(payload))
        return True
    except (InvalidSignature, ValueError):
        return False
