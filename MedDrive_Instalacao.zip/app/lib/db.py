"""Shared Mongo handle — import `client`/`db` from here (server.py, routers, seed.py)."""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from pymongo import ASCENDING, DESCENDING, IndexModel

load_dotenv(Path(__file__).parent.parent / ".env")

# DB_MODE=file → in-process store persisted as JSON files in DATA_DIR (portable/offline pendrive build).
FILE_MODE = os.environ.get("DB_MODE", "mongo") == "file"

if FILE_MODE:
    from mongomock_motor import AsyncMongoMockClient

    client = AsyncMongoMockClient()
    db = client[os.environ.get("DB_NAME", "receituario")]
else:
    from motor.motor_asyncio import AsyncIOMotorClient

    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]

logger = logging.getLogger(__name__)

# One entry per collection: every field a route filters, sorts, or dedupes on. Applied by ensure_indexes() at startup.
INDEXES: dict[str, list[IndexModel]] = {
    "status_checks": [IndexModel([("timestamp", DESCENDING)], name="timestamp_desc")],
    "workplaces": [IndexModel([("id", ASCENDING)], name="id", unique=True), IndexModel([("name", ASCENDING)], name="name")],
    "patients": [IndexModel([("id", ASCENDING)], name="id", unique=True), IndexModel([("name", ASCENDING)], name="name")],
    "medications": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("name", ASCENDING)], name="name"),
        IndexModel([("pinned", ASCENDING), ("usage_count", DESCENDING)], name="pinned_usage"),
    ],
    "exams": [IndexModel([("id", ASCENDING)], name="id", unique=True), IndexModel([("name", ASCENDING)], name="name")],
    "guidance": [IndexModel([("id", ASCENDING)], name="id", unique=True)],
    "clinical_phrases": [IndexModel([("id", ASCENDING)], name="id", unique=True)],
    "terms_acceptance": [IndexModel([("id", ASCENDING)], name="id", unique=True), IndexModel([("version", ASCENDING)], name="version")],
    "rx_templates": [IndexModel([("id", ASCENDING)], name="id", unique=True)],
    "exam_groups": [IndexModel([("id", ASCENDING)], name="id", unique=True)],
    "settings": [IndexModel([("key", ASCENDING)], name="key", unique=True)],
    "appointments": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("workplace_id", ASCENDING), ("date", ASCENDING), ("time", ASCENDING)], name="wp_date_time"),
        IndexModel([("patient_id", ASCENDING)], name="patient"),
    ],
    "finance_recurring": [IndexModel([("id", ASCENDING)], name="id", unique=True)],
    "finance_entries": [IndexModel([("id", ASCENDING)], name="id", unique=True), IndexModel([("date", ASCENDING)], name="date")],
    "agenda_blocks": [IndexModel([("id", ASCENDING)], name="id", unique=True), IndexModel([("workplace_id", ASCENDING), ("date", ASCENDING)], name="wp_date")],
    "documents": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("date", DESCENDING), ("created_at", DESCENDING)], name="date_created"),
        IndexModel([("patient_name", ASCENDING)], name="patient_name"),
        IndexModel([("patient_id", ASCENDING), ("date", DESCENDING)], name="patient_date"),
    ],
}


async def ensure_indexes() -> None:
    for collection, models in INDEXES.items():
        for model in models:  # one at a time so a bad spec skips only itself
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:  # never block boot on an index; the log line names what to fix
                logger.error("ensure_indexes(%s.%s): %s", collection, model.document["name"], exc)
