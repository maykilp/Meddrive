"""Termo de Uso, Responsabilidade e Consentimento do MedDrive.

Mudar o texto => subir TERMS_VERSION: todos os usuários terão de aceitar a nova versão (o aceite antigo fica guardado).
"""

TERMS_VERSION = "1.0"
TERMS_DATE = "20/11/2026"
TITLE = "Termo de Uso, Responsabilidade e Consentimento — MedDrive"

OWNER = "Mayki Pereira Lopes, inscrito no CPF sob o nº 011.210.252-26"
ADDRESS = "Rua Marechal Cândido Rondon, nº 466, Bairro Centro, Prudentópolis/PR, CEP 84400-000"
CONTACT = "WhatsApp +55 (46) 99972-2834"

SECTIONS: list[dict] = [
    {
        "title": "1. Partes e objeto",
        "body": [
            f"Este Termo regula o uso do sistema MedDrive (\"SISTEMA\"), software de apoio à emissão de receitas, atestados, declarações, laudos, encaminhamentos, agenda e controle financeiro, disponibilizado por {OWNER}, com endereço na {ADDRESS} (\"MEDDRIVE\" ou \"DESENVOLVEDOR\").",
            "\"USUÁRIO\" é o(a) médico(a) regularmente inscrito(a) no Conselho Regional de Medicina (CRM) que instala, acessa ou utiliza o SISTEMA, inclusive na versão portátil (pendrive).",
            "Ao clicar em \"Li e aceito\", o USUÁRIO declara ter lido, compreendido e concordado integralmente com este Termo, que tem validade jurídica nos termos do art. 107 do Código Civil (Lei nº 10.406/2002) e da Lei nº 14.063/2020 (aceite eletrônico).",
        ],
    },
    {
        "title": "2. Natureza do sistema: ferramenta de APOIO",
        "body": [
            "O SISTEMA é exclusivamente uma ferramenta de apoio administrativo e de organização. Ele NÃO realiza diagnóstico, NÃO define tratamento, NÃO substitui o raciocínio clínico, o exame do paciente, a consulta a bulas e protocolos oficiais, nem o julgamento profissional do médico.",
            "Cálculos de dose (inclusive pediátricos por peso), doses máximas, sugestões de posologia, protocolos e prescrições prontas, catálogos de medicamentos e exames, alertas de alergia, gestação e lactação, frases prontas, modelos de laudo, atestado e encaminhamento são REFERÊNCIAS genéricas, podem conter erros, desatualizações ou não se aplicar ao caso concreto, e DEVEM ser conferidos e, quando necessário, corrigidos pelo USUÁRIO antes de qualquer emissão.",
            "A ausência de um alerta não significa ausência de risco. O SISTEMA não verifica todas as interações medicamentosas, contraindicações, ajustes por função renal/hepática, idade ou comorbidades.",
        ],
    },
    {
        "title": "3. Responsabilidade exclusiva do médico",
        "body": [
            "Nos termos da Lei nº 12.842/2013 (Lei do Ato Médico), a indicação e execução de tratamentos, a prescrição e a emissão de atestados e laudos são atos privativos do médico. Toda conduta, prescrição, dose, via, duração, exame solicitado, atestado, declaração, laudo e encaminhamento emitido com o auxílio do SISTEMA é de responsabilidade INTEGRAL, PESSOAL e EXCLUSIVA do USUÁRIO que o assina.",
            "O USUÁRIO declara conhecer e se compromete a cumprir o Código de Ética Médica (Resolução CFM nº 2.217/2018), em especial: o dever de não causar dano ao paciente por ação ou omissão, caracterizável como imperícia, imprudência ou negligência (art. 1º); de não receitar ou atestar de forma secreta ou ilegível nem assinar em branco (art. 11); de não expedir documento médico sem ter praticado o ato que o justifique ou que não corresponda à verdade (art. 80); e de guardar sigilo profissional (art. 73).",
            "Antes de assinar e entregar qualquer documento, o USUÁRIO deve revisar todo o seu conteúdo: dados do paciente, medicamento, concentração, dose, posologia, quantidade, CID (somente com autorização do paciente, conforme Resolução CFM nº 1.658/2002 e art. 73 do Código de Ética Médica), datas e período de afastamento.",
            "O USUÁRIO é responsável por manter corretos e atualizados os seus dados (nome, CRM, UF, especialidades e RQE), os dados dos locais de atendimento e os cadastros de pacientes e medicamentos.",
        ],
    },
    {
        "title": "4. Isenção de responsabilidade do MedDrive",
        "body": [
            "O DESENVOLVEDOR e o SISTEMA MedDrive NÃO se responsabilizam, em nenhuma hipótese e na máxima extensão permitida pela lei, por: (a) diagnósticos, condutas, prescrições, doses, documentos e decisões clínicas do USUÁRIO; (b) danos ao paciente, ao USUÁRIO ou a terceiros decorrentes do uso, mau uso ou falta de conferência das informações do SISTEMA; (c) erros de cálculo, de cadastro, de digitação ou de catálogo não conferidos pelo USUÁRIO; (d) glosas, recusas de farmácias, de empregadores, do INSS ou de planos de saúde; (e) sanções éticas, administrativas, civis ou penais aplicadas ao USUÁRIO.",
            "O DESENVOLVEDOR também não se responsabiliza por perda, corrupção, vazamento ou indisponibilidade de dados causados por perda, furto, defeito ou formatação do pendrive ou do computador, vírus, falta de energia, falta de backup, uso compartilhado do equipamento, senhas de e-mail do USUÁRIO ou qualquer fator fora do seu controle.",
            "O SISTEMA é fornecido \"no estado em que se encontra\", sem garantia de funcionamento ininterrupto ou livre de falhas. Recomenda-se não atualizar o sistema durante plantões e manter alternativa (receituário em papel) para eventual indisponibilidade.",
            "Caso alguma limitação seja afastada judicialmente, a responsabilidade do DESENVOLVEDOR ficará limitada ao valor efetivamente pago pelo USUÁRIO pela licença nos 12 (doze) meses anteriores ao fato.",
        ],
    },
    {
        "title": "5. Documentos médicos, receitas e medicamentos controlados",
        "body": [
            "Os documentos gerados pelo SISTEMA destinam-se à impressão e à assinatura manual do USUÁRIO (com carimbo ou identificação legível com nome e CRM). O SISTEMA NÃO realiza assinatura digital. Documentos médicos eletrônicos só têm validade com assinatura digital ICP-Brasil (padrão NGS2) feita pelo próprio médico em plataforma adequada, conforme a Resolução CFM nº 2.299/2021 e a Lei nº 14.063/2020 — providência de responsabilidade do USUÁRIO.",
            "As receitas devem observar a Lei nº 5.991/1973 e o Decreto nº 20.931/1932 (identificação do paciente e do prescritor, legibilidade, modo de uso). Antimicrobianos seguem a RDC ANVISA nº 471/2021 (receita em 2 vias, validade de 10 dias).",
            "Medicamentos sujeitos a controle especial seguem a Portaria SVS/MS nº 344/1998 e normas complementares. O SISTEMA imprime apenas o modelo de Receituário de Controle Especial (2 vias). Notificações de Receita (A amarela, B azul, B2 e outras) exigem talonário oficial numerado e NÃO são emitidas pelo SISTEMA. Cabe ao USUÁRIO escolher o documento correto para cada medicamento.",
            "Atestados e declarações devem corresponder à verdade e ao ato médico efetivamente realizado (art. 80 do Código de Ética Médica e Resolução CFM nº 1.658/2002). A emissão de atestado falso é crime (art. 302 do Código Penal).",
        ],
    },
    {
        "title": "6. Prontuário e história clínica",
        "body": [
            "Os registros de história clínica, exame físico e conduta servem como apoio. O USUÁRIO é responsável por manter o prontuário do paciente conforme a Resolução CFM nº 1.638/2002, a Resolução CFM nº 1.821/2007 e a Lei nº 13.787/2018 (guarda mínima de 20 anos a partir do último registro), inclusive no sistema oficial da instituição onde atende (UPA, hospital, UBS).",
            "Por ser um sistema local, a guarda, a cópia de segurança (backup) e a integridade desses registros dependem do USUÁRIO.",
        ],
    },
    {
        "title": "7. Proteção de dados pessoais (LGPD — Lei nº 13.709/2018)",
        "body": [
            "Dados de saúde são dados pessoais sensíveis (art. 5º, II, da LGPD). O SISTEMA funciona localmente: os dados de pacientes ficam armazenados no computador ou pendrive do USUÁRIO e NÃO são enviados ao DESENVOLVEDOR. O USUÁRIO é o CONTROLADOR desses dados (art. 5º, VI) e responde pelo seu tratamento.",
            "O tratamento de dados de saúde pelo médico encontra base legal no art. 11, II, \"a\" (cumprimento de obrigação legal/regulatória) e \"f\" (tutela da saúde, em procedimento realizado por profissional de saúde) da LGPD. O USUÁRIO compromete-se a tratar apenas os dados necessários, a garantir os direitos dos titulares (art. 18) e a adotar medidas de segurança (art. 46), como: não deixar o pendrive desacompanhado, não compartilhar o computador sem proteção, manter antivírus e fazer backups protegidos.",
            "O backup por e-mail é feito com arquivo criptografado e enviado pela conta de e-mail do próprio USUÁRIO; a escolha e a guarda da conta e da senha de aplicativo são de responsabilidade do USUÁRIO.",
            "Dados tratados pelo DESENVOLVEDOR: apenas o nome, o CRM e a UF do USUÁRIO, usados para verificação da licença (consulta a planilha de licenças) e o registro deste aceite (data, hora, versão, nome e CRM), guardado localmente como prova, com base no art. 7º, V e VI, da LGPD. Envios de mensagens (WhatsApp) são feitos pelo próprio USUÁRIO, em seu aparelho.",
            "Em caso de incidente de segurança envolvendo dados de pacientes, cabe ao USUÁRIO, como controlador, avaliar e realizar as comunicações exigidas pelo art. 48 da LGPD.",
        ],
    },
    {
        "title": "8. Sigilo profissional",
        "body": [
            "O USUÁRIO deve preservar o sigilo das informações dos pacientes (art. 73 do Código de Ética Médica e art. 154 do Código Penal), inclusive ao copiar prescrições para outros sistemas, imprimir, enviar mensagens ou compartilhar documentos e backups.",
        ],
    },
    {
        "title": "9. Licença, propriedade intelectual e uso adequado",
        "body": [
            "O SISTEMA é protegido pela Lei nº 9.609/1998 (Lei do Software) e pela Lei nº 9.610/1998 (Direitos Autorais). É concedida ao USUÁRIO licença de uso pessoal, intransferível e não exclusiva, condicionada à licença ativa vinculada ao seu CRM. É proibido copiar, revender, ceder, modificar, descompilar ou permitir o uso por terceiros, especialmente por pessoa que não seja médico(a) inscrito(a) no CRM.",
            "O uso em desacordo com este Termo ou com a lei autoriza o bloqueio da licença, sem prejuízo das medidas cabíveis.",
        ],
    },
    {
        "title": "10. Atualizações do sistema e deste Termo",
        "body": [
            "O SISTEMA pode receber atualizações. As atualizações não apagam a pasta de dados, mas o USUÁRIO deve manter backups atualizados.",
            "Este Termo pode ser alterado. Sempre que houver nova versão, o USUÁRIO deverá ler e aceitar novamente para continuar usando o SISTEMA. Os aceites anteriores permanecem registrados e não podem ser alterados nem excluídos pelo SISTEMA.",
        ],
    },
    {
        "title": "11. Legislação aplicável e foro",
        "body": [
            "Este Termo é regido pelas leis da República Federativa do Brasil, em especial: Constituição Federal (art. 5º, X e LXXIX); Código Civil (Lei nº 10.406/2002); Código de Defesa do Consumidor (Lei nº 8.078/1990), no que couber; Marco Civil da Internet (Lei nº 12.965/2014); LGPD (Lei nº 13.709/2018); Lei nº 12.842/2013; Lei nº 13.787/2018; Lei nº 14.063/2020; Lei nº 5.991/1973; Portaria SVS/MS nº 344/1998; RDC ANVISA nº 471/2021; Código de Ética Médica (Resolução CFM nº 2.217/2018) e Resoluções CFM nº 1.638/2002, 1.658/2002, 1.821/2007 e 2.299/2021.",
            "Fica eleito o foro da Comarca de Prudentópolis/PR para dirimir quaisquer questões oriundas deste Termo, ressalvado o direito do consumidor de propor ação em seu domicílio, quando aplicável.",
            f"Dúvidas sobre este Termo ou sobre dados pessoais: {CONTACT}.",
        ],
    },
    {
        "title": "12. Declaração do usuário",
        "body": [
            "Declaro que sou médico(a) regularmente inscrito(a) no CRM; que li e compreendi este Termo; que o MedDrive é apenas uma ferramenta de apoio; que conferirei todo o conteúdo antes de assinar qualquer documento; que a responsabilidade pelas condutas, prescrições e documentos emitidos é exclusivamente minha; e que o DESENVOLVEDOR e o sistema MedDrive não se responsabilizam pelos atos praticados por mim com o auxílio do sistema.",
        ],
    },
]
