"""Built-in catalog of common medications (adult + pediatric formulas) and exams.

Applied once per CATALOG_VERSION (online and on the pendrive, at startup): only adds items whose
name+presentation (exams: name) don't exist yet — never changes or deletes what the doctor registered.
Doses, formulas and pregnancy/lactation tags are usual references and must be reviewed by the doctor.
"""

from lib.db import FILE_MODE, db
from models.schemas import ClinicalPhrase, Exam, ExamGroup, Medication, ReferralTemplate, ReportTemplate, RxItemOverride, RxTemplate

CATALOG_VERSION = 5

D, DAY = "mg_kg_dose", "mg_kg_day"
LACT = {"c": "compativel", "u": "cautela", "x": "contraindicado"}
VO, TOP, OFT, OTO, NAS, INAL, NEB, VAG, IM = (
    "Via oral", "Uso tópico", "Uso oftálmico", "Uso otológico", "Via nasal",
    "Via inalatória", "Via inalatória (nebulização)", "Via vaginal", "Via intramuscular",
)


def P(mode, mgkg, per_day, cmg, cml, max_mg, days=None, drops=None, notes=""):
    """Pediatric weight-based formula."""
    return dict(pediatric=True, dose_mode=mode, dose_mg_per_kg=mgkg, doses_per_day=per_day, conc_mg=cmg,
                conc_ml=cml, max_dose_mg=max_mg, duration_days=days, drops_per_ml=drops, notes=notes)


def M(name, pres, instr, qty="1 frasco", route=VO, ped=None, s="", note="", ctrl=False, verb=""):
    """s = 'C u' → pregnancy category C, lactation cautela (c compatível · u cautela · x contraindicado)."""
    cat, lact = (s.split(" ", 1) + ["", ""])[:2] if s else ("", "")
    return Medication(name=name, presentation=pres, instructions=instr, quantity=qty, route=route,
                      pregnancy_category=cat, lactation=LACT.get(lact, ""), pregnancy_lactation_notes=note,
                      controlled=ctrl, action_verb=verb, **(ped or {}))


NSAID3 = "Evitar no 3º trimestre."
ARB = "Contraindicado no 2º e 3º trimestres."
CTRL = "Receita de controle especial (2 vias)."

MEDS = [
    # ---------- Analgésicos, antitérmicos, anti-inflamatórios ----------
    M("Dipirona", "Solução oral 50mg/mL", "Tomar 10 a 20 mL de 6 em 6 horas se dor ou febre.", ped=P(D, 15, 4, 50, 1, 1000, notes="Se dor ou febre."), s="C u", note="Evitar no 1º e 3º trimestres."),
    M("Dipirona", "Comprimido 500mg", "Tomar 1 a 2 comprimidos de 6 em 6 horas se dor ou febre.", "20 comprimidos", s="C u", note="Evitar no 1º e 3º trimestres."),
    M("Dipirona", "Solução injetável 500mg/mL - ampola 2mL", "Aplicar 1 ampola intramuscular ou endovenosa diluída, dose única.", "1 ampola", route=IM, s="C u"),
    M("Paracetamol", "Suspensão oral 100mg/mL", "Tomar conforme peso de 6 em 6 horas se dor ou febre.", ped=P(D, 15, 4, 100, 1, 750, notes="Se dor ou febre."), s="B c"),
    M("Paracetamol", "Suspensão oral 32mg/mL", "Tomar conforme peso de 6 em 6 horas se dor ou febre.", ped=P(D, 15, 4, 32, 1, 750, notes="Se dor ou febre."), s="B c"),
    M("Paracetamol", "Comprimido 500mg", "Tomar 1 a 2 comprimidos de 6 em 6 horas se dor ou febre (máx. 4 g/dia).", "20 comprimidos", s="B c"),
    M("Paracetamol", "Comprimido 750mg", "Tomar 1 comprimido de 6 em 6 horas se dor ou febre.", "20 comprimidos", s="B c"),
    M("Ibuprofeno", "Suspensão oral gotas 100mg/mL", "Tomar conforme peso de 8 em 8 horas se dor ou febre.", ped=P(D, 10, 3, 100, 1, 400, drops=20, notes="Se dor ou febre. Tomar após alimentação."), s="C c", note=NSAID3),
    M("Ibuprofeno", "Suspensão oral 20mg/mL", "Tomar conforme peso de 8 em 8 horas se dor ou febre.", ped=P(D, 10, 3, 20, 1, 400, notes="Se dor ou febre. Tomar após alimentação."), s="C c", note=NSAID3),
    M("Ibuprofeno", "Comprimido 400mg", "Tomar 1 comprimido de 8 em 8 horas, após as refeições, por 5 dias.", "15 comprimidos", s="C c", note=NSAID3),
    M("Ibuprofeno", "Comprimido 600mg", "Tomar 1 comprimido de 8 em 8 horas, após as refeições, por 5 dias.", "15 comprimidos", s="C c", note=NSAID3),
    M("Diclofenaco Potássico", "Suspensão oral gotas 15mg/mL", "Acima de 1 ano: tomar conforme peso de 8 em 8 horas, após alimentação.", ped=P(DAY, 1.5, 3, 15, 1, 50, days=5, drops=30, notes="Tomar após alimentação."), s="C c", note=NSAID3),
    M("Diclofenaco Potássico", "Comprimido 50mg", "Tomar 1 comprimido de 8 em 8 horas, após as refeições, por 5 dias.", "15 comprimidos", s="C c", note=NSAID3),
    M("Diclofenaco Sódico", "Comprimido 50mg", "Tomar 1 comprimido de 8 em 8 horas, após as refeições, por 5 dias.", "15 comprimidos", s="C c", note=NSAID3),
    M("Diclofenaco Sódico", "Solução injetável 75mg/3mL", "Aplicar 1 ampola intramuscular profunda, dose única.", "1 ampola", route=IM, s="C c", note=NSAID3),
    M("Nimesulida", "Comprimido 100mg", "Tomar 1 comprimido de 12 em 12 horas, após as refeições, por 5 dias.", "10 comprimidos", s="C u", note=NSAID3),
    M("Cetoprofeno", "Comprimido 100mg", "Tomar 1 comprimido de 12 em 12 horas, após as refeições, por 5 dias.", "10 comprimidos", s="C u", note=NSAID3),
    M("Cetoprofeno", "Solução injetável 100mg/2mL", "Aplicar 1 ampola intramuscular, dose única.", "1 ampola", route=IM, s="C u", note=NSAID3),
    M("Naproxeno", "Comprimido 500mg", "Tomar 1 comprimido de 12 em 12 horas, após as refeições, por 5 dias.", "10 comprimidos", s="C c", note=NSAID3),
    M("Cetorolaco de Trometamina", "Comprimido sublingual 10mg", "Dissolver 1 comprimido sob a língua de 8 em 8 horas se dor, no máximo 5 dias.", "10 comprimidos", route="Via sublingual", s="C u", note=NSAID3),
    M("Butilbrometo de Escopolamina", "Comprimido 10mg", "Tomar 1 a 2 comprimidos de 8 em 8 horas se cólica.", "20 comprimidos", s="C c"),
    M("Butilbrometo de Escopolamina", "Solução oral gotas 10mg/mL", "Adultos: 20 a 40 gotas de 8 em 8 horas. Crianças 1–6 anos: 5 a 10 gotas de 8 em 8 horas, se cólica.", s="C c"),
    M("Butilbrometo de Escopolamina + Dipirona", "Comprimido 10mg + 250mg", "Tomar 1 a 2 comprimidos de 8 em 8 horas se cólica.", "20 comprimidos", s="C u"),
    M("Orfenadrina + Dipirona + Cafeína", "Comprimido 35mg + 300mg + 50mg", "Tomar 1 a 2 comprimidos de 8 em 8 horas se dor.", "20 comprimidos", s="C u"),
    M("Ciclobenzaprina", "Comprimido 5mg", "Tomar 1 comprimido à noite por 7 dias. Pode causar sonolência.", "10 comprimidos", s="B u"),
    M("Ciclobenzaprina", "Comprimido 10mg", "Tomar 1 comprimido à noite por 7 dias. Pode causar sonolência.", "10 comprimidos", s="B u"),
    M("Tramadol", "Cápsula 50mg", "Tomar 1 cápsula de 8 em 8 horas se dor forte, por até 5 dias.", "15 cápsulas", s="C u", ctrl=True),
    M("Paracetamol + Codeína", "Comprimido 500mg + 30mg", "Tomar 1 comprimido de 6 em 6 horas se dor forte, por até 5 dias.", "20 comprimidos", s="C x", ctrl=True),
    M("Prednisona", "Comprimido 20mg", "Tomar 1 comprimido pela manhã, após o café, por 5 dias.", "5 comprimidos", s="C c"),
    M("Prednisona", "Comprimido 5mg", "Tomar conforme orientação, pela manhã, após o café.", "20 comprimidos", s="C c"),
    M("Prednisolona", "Solução oral 1mg/mL", "Tomar pela manhã conforme peso.", ped=P(DAY, 1, 1, 1, 1, 40, days=5, notes="Tomar pela manhã, após o café."), s="C c"),
    M("Prednisolona", "Comprimido 20mg", "Tomar 1 comprimido pela manhã, após o café, por 5 dias.", "5 comprimidos", s="C c"),
    M("Dexametasona", "Comprimido 4mg", "Tomar 1 comprimido pela manhã por 3 dias.", "3 comprimidos", s="C c"),
    M("Dexametasona", "Solução injetável 4mg/mL - ampola 2,5mL", "Aplicar 1 ampola intramuscular, dose única.", "1 ampola", route=IM, s="C c"),
    M("Ácido Tranexâmico", "Comprimido 250mg", "Tomar 2 comprimidos de 8 em 8 horas por até 5 dias.", "30 comprimidos", s="B c"),

    # ---------- Antibióticos ----------
    M("Amoxicilina", "Suspensão oral 500mg/5mL", "Tomar conforme peso de 8 em 8 horas por 10 dias.", ped=P(DAY, 50, 3, 500, 5, 500, days=10), s="B c"),
    M("Amoxicilina", "Comprimido 875mg", "Tomar 1 comprimido de 12 em 12 horas por 7 dias.", "14 comprimidos", s="B c"),
    M("Amoxicilina + Clavulanato", "Suspensão oral 250mg + 62,5mg/5mL", "Tomar conforme peso de 8 em 8 horas por 10 dias.", ped=P(DAY, 40, 3, 250, 5, 500, days=10, notes="Tomar no início das refeições."), s="B c"),
    M("Amoxicilina + Clavulanato", "Comprimido 875mg + 125mg", "Tomar 1 comprimido de 12 em 12 horas, no início das refeições, por 7 dias.", "14 comprimidos", s="B c"),
    M("Amoxicilina + Clavulanato", "Comprimido 500mg + 125mg", "Tomar 1 comprimido de 8 em 8 horas, no início das refeições, por 7 dias.", "21 comprimidos", s="B c"),
    M("Azitromicina", "Comprimido 500mg", "Tomar 1 comprimido 1 vez ao dia por 5 dias.", "5 comprimidos", s="B c"),
    M("Cefalexina", "Suspensão oral 500mg/5mL", "Tomar conforme peso de 6 em 6 horas por 7 dias.", ped=P(DAY, 50, 4, 500, 5, 500, days=7), s="B c"),
    M("Cefalexina", "Cápsula 500mg", "Tomar 1 cápsula de 6 em 6 horas por 7 dias.", "28 cápsulas", s="B c"),
    M("Cefadroxila", "Suspensão oral 500mg/5mL", "Tomar conforme peso de 12 em 12 horas por 10 dias.", ped=P(DAY, 30, 2, 500, 5, 1000, days=10), s="B c"),
    M("Cefadroxila", "Cápsula 500mg", "Tomar 1 cápsula de 12 em 12 horas por 10 dias.", "20 cápsulas", s="B c"),
    M("Cefaclor", "Suspensão oral 250mg/5mL", "Tomar conforme peso de 8 em 8 horas por 10 dias.", ped=P(DAY, 40, 3, 250, 5, 500, days=10), s="B c"),
    M("Cefuroxima", "Comprimido 500mg", "Tomar 1 comprimido de 12 em 12 horas por 10 dias.", "20 comprimidos", s="B c"),
    M("Ceftriaxona", "Pó para solução injetável 1g", "Aplicar 1 g intramuscular 1 vez ao dia.", "1 frasco-ampola", route=IM, ped=P(D, 50, 1, 1000, 3.5, 1000, notes="Diluir em lidocaína 1% (3,5 mL)."), s="B c"),
    M("Penicilina G Benzatina", "Pó para suspensão injetável 1.200.000 UI", "Aplicar 1.200.000 UI intramuscular profunda, dose única. Crianças < 27 kg: 600.000 UI.", "1 frasco-ampola", route=IM, s="B c"),
    M("Claritromicina", "Comprimido 500mg", "Tomar 1 comprimido de 12 em 12 horas por 7 dias.", "14 comprimidos", s="C c"),
    M("Eritromicina", "Suspensão oral 250mg/5mL", "Tomar conforme peso de 6 em 6 horas por 10 dias.", ped=P(DAY, 40, 4, 250, 5, 500, days=10), s="B c"),
    M("Sulfametoxazol + Trimetoprima", "Comprimido 400mg + 80mg", "Tomar 2 comprimidos de 12 em 12 horas por 7 dias.", "28 comprimidos", s="C u", note="Evitar no 1º trimestre e próximo ao parto."),
    M("Sulfametoxazol + Trimetoprima", "Comprimido 800mg + 160mg", "Tomar 1 comprimido de 12 em 12 horas por 7 dias.", "14 comprimidos", s="C u", note="Evitar no 1º trimestre e próximo ao parto."),
    M("Ciprofloxacino", "Comprimido 500mg", "Tomar 1 comprimido de 12 em 12 horas por 7 dias.", "14 comprimidos", s="C u"),
    M("Levofloxacino", "Comprimido 500mg", "Tomar 1 comprimido 1 vez ao dia por 7 dias.", "7 comprimidos", s="C u"),
    M("Levofloxacino", "Comprimido 750mg", "Tomar 1 comprimido 1 vez ao dia por 5 dias.", "5 comprimidos", s="C u"),
    M("Norfloxacino", "Comprimido 400mg", "Tomar 1 comprimido de 12 em 12 horas por 3 dias.", "6 comprimidos", s="C u"),
    M("Nitrofurantoína", "Cápsula 100mg", "Tomar 1 cápsula de 6 em 6 horas por 7 dias.", "28 cápsulas", s="B c", note="Evitar no final da gestação (38–42 semanas)."),
    M("Fosfomicina Trometamol", "Granulado envelope 3g", "Dissolver 1 envelope em meio copo de água e tomar em dose única, à noite, com a bexiga vazia.", "1 envelope", s="B c"),
    M("Metronidazol", "Comprimido 400mg", "Tomar 1 comprimido de 8 em 8 horas por 7 dias. Não ingerir bebida alcoólica.", "21 comprimidos", s="B u"),
    M("Metronidazol", "Comprimido 250mg", "Tomar 2 comprimidos de 12 em 12 horas por 7 dias. Não ingerir bebida alcoólica.", "28 comprimidos", s="B u"),
    M("Metronidazol", "Gel vaginal 100mg/g", "Aplicar 1 aplicador cheio via vaginal à noite, ao deitar, por 7 dias.", "1 bisnaga", route=VAG, s="B u"),
    M("Secnidazol", "Comprimido 1g", "Tomar 2 comprimidos em dose única, após uma refeição. Não ingerir bebida alcoólica.", "2 comprimidos", s="B u"),
    M("Tinidazol", "Comprimido 500mg", "Tomar 4 comprimidos em dose única, após uma refeição. Não ingerir bebida alcoólica.", "4 comprimidos", s="C u"),
    M("Doxiciclina", "Comprimido 100mg", "Tomar 1 comprimido de 12 em 12 horas por 7 dias, com bastante água.", "14 comprimidos", s="D u", note="Contraindicada na gestação."),
    M("Clindamicina", "Cápsula 300mg", "Tomar 1 cápsula de 8 em 8 horas por 7 dias.", "21 cápsulas", s="B c"),

    # ---------- Antifúngicos e antiparasitários ----------
    M("Fluconazol", "Cápsula 150mg", "Tomar 1 cápsula em dose única.", "1 cápsula", s="C c", note="Evitar no 1º trimestre."),
    M("Itraconazol", "Cápsula 100mg", "Tomar 1 cápsula 1 vez ao dia, após refeição, conforme orientação.", "15 cápsulas", s="C u"),
    M("Terbinafina", "Comprimido 250mg", "Tomar 1 comprimido 1 vez ao dia conforme orientação.", "14 comprimidos", s="B u"),
    M("Nistatina", "Creme vaginal 25.000 UI/g", "Aplicar 1 aplicador cheio via vaginal à noite, ao deitar, por 14 dias.", "1 bisnaga", route=VAG, s="C c"),
    M("Miconazol", "Creme vaginal 2%", "Aplicar 1 aplicador cheio via vaginal à noite, ao deitar, por 7 dias.", "1 bisnaga", route=VAG, s="C c"),
    M("Miconazol", "Gel oral 20mg/g", "Aplicar pequena quantidade na boca 4 vezes ao dia, após as mamadas/refeições, por 7 dias.", "1 bisnaga", route="Uso tópico oral", s="C c"),
    M("Mebendazol", "Suspensão oral 100mg/5mL", "Tomar 5 mL de 12 em 12 horas por 3 dias.", s="C c"),
    M("Mebendazol", "Comprimido 100mg", "Tomar 1 comprimido de 12 em 12 horas por 3 dias.", "6 comprimidos", s="C c"),
    M("Albendazol", "Comprimido 400mg", "Tomar 1 comprimido em dose única. Repetir após 14 dias.", "2 comprimidos", s="C u"),
    M("Ivermectina", "Comprimido 6mg", "Dose única por peso (200 mcg/kg): 15–24 kg ½ comprimido; 25–35 kg 1; 36–50 kg 1½; 51–65 kg 2; 66–79 kg 2½; 80 kg ou mais 3. Repetir após 7 dias.", "4 comprimidos", s="C u"),
    M("Nitazoxanida", "Comprimido 500mg", "Tomar 1 comprimido de 12 em 12 horas, com alimentos, por 3 dias.", "6 comprimidos", s="B u"),
    M("Permetrina", "Loção 5%", "Aplicar em todo o corpo, do pescoço para baixo, à noite; retirar no banho pela manhã. Repetir após 7 dias.", route=TOP, s="B c"),
    M("Permetrina", "Loção capilar 1%", "Aplicar no couro cabeludo seco, deixar agir 10 minutos e enxaguar. Repetir após 7 dias. Passar pente fino.", route=TOP, s="B c"),

    # ---------- Respiratórios, xaropes, antialérgicos, nebulização ----------
    M("Ambroxol", "Xarope pediátrico 15mg/5mL", "Tomar conforme peso de 8 em 8 horas por 5 dias.", ped=P(DAY, 1.5, 3, 15, 5, 30, days=5), s=" c"),
    M("Ambroxol", "Xarope adulto 30mg/5mL", "Tomar 5 mL de 8 em 8 horas por 5 dias.", s=" c"),
    M("Acetilcisteína", "Xarope pediátrico 20mg/mL", "2–4 anos: 5 mL de 12 em 12 horas. Acima de 4 anos: 5 mL de 8 em 8 horas. Por 5 dias.", s="B c"),
    M("Acetilcisteína", "Granulado envelope 600mg", "Dissolver 1 envelope em água e tomar 1 vez ao dia por 5 dias.", "5 envelopes", s="B c"),
    M("Bromexina", "Xarope pediátrico 4mg/5mL", "2–6 anos: 2,5 mL de 8 em 8 horas. 6–12 anos: 5 mL de 8 em 8 horas. Por 5 dias.", s=" c"),
    M("Levodropropizina", "Xarope 6mg/mL", "Adultos: 10 mL de 8 em 8 horas se tosse seca.", ped=P(D, 1, 3, 6, 1, 60, days=5, notes="Se tosse seca. Acima de 2 anos."), s=" u"),
    M("Dropropizina", "Xarope pediátrico 1,5mg/mL", "Acima de 3 anos: tomar 5 a 10 mL de 6 em 6 horas se tosse seca, por até 7 dias.", s=" u"),
    M("Extrato de Hedera helix", "Xarope 7mg/mL", "2–5 anos: 2,5 mL de 8 em 8 horas. 6–12 anos: 5 mL de 8 em 8 horas. Adultos: 7,5 mL de 8 em 8 horas. Por 7 dias.", s=" u"),
    M("Fenoterol (bromidrato)", "Solução para nebulização 5mg/mL (gotas)", "Adultos: 10 gotas em 3 a 5 mL de soro fisiológico 0,9% de 6 em 6 horas se falta de ar.", "1 frasco", route=NEB, ped=P(D, 0.083, 4, 5, 1, 2, drops=20, notes="Diluir em 3 a 5 mL de soro fisiológico 0,9%. Se falta de ar."), s="C c"),
    M("Brometo de Ipratrópio", "Solução para nebulização 0,25mg/mL (gotas)", "Menores de 6 anos: 10 gotas; 6–12 anos: 20 gotas; adultos: 40 gotas — em 3 a 5 mL de soro fisiológico 0,9%, até de 6 em 6 horas.", route=NEB, s="B c"),
    M("Budesonida", "Suspensão para nebulização 0,25mg/mL", "Fazer nebulização com 1 a 2 mL (0,25 a 0,5 mg) de 12 em 12 horas.", "1 caixa", route=NEB, s="B c"),
    M("Budesonida", "Spray nasal 64mcg/dose", "Aplicar 1 jato em cada narina de 12 em 12 horas por 30 dias.", route=NAS, s="B c"),
    M("Furoato de Mometasona", "Spray nasal 50mcg/dose", "Aplicar 2 jatos em cada narina 1 vez ao dia. Crianças 2–11 anos: 1 jato em cada narina 1 vez ao dia.", route=NAS, s="C c"),
    M("Propionato de Fluticasona", "Spray nasal 50mcg/dose", "Aplicar 2 jatos em cada narina 1 vez ao dia.", route=NAS, s="C c"),
    M("Oximetazolina", "Solução nasal adulto 0,05%", "Aplicar 2 a 3 gotas/jatos em cada narina de 12 em 12 horas, no máximo 3 a 5 dias.", route=NAS, s="C u"),
    M("Beclometasona", "Aerossol oral 250mcg/dose", "Inalar 1 jato com espaçador de 12 em 12 horas. Enxaguar a boca após o uso.", route=INAL, s="C c"),
    M("Budesonida + Formoterol", "Cápsula para inalação 200mcg + 6mcg", "Inalar 1 cápsula de 12 em 12 horas. Enxaguar a boca após o uso.", "60 cápsulas", route=INAL, s="C c"),
    M("Salmeterol + Fluticasona", "Aerossol oral 25mcg + 125mcg/dose", "Inalar 2 jatos de 12 em 12 horas. Enxaguar a boca após o uso.", route=INAL, s="C c"),
    M("Montelucaste", "Sachê/comprimido mastigável 4mg", "2–5 anos: 1 sachê ou comprimido mastigável à noite, uso contínuo.", "30 unidades", s="B c"),
    M("Montelucaste", "Comprimido mastigável 5mg", "6–14 anos: 1 comprimido mastigável à noite, uso contínuo.", "30 comprimidos", s="B c"),
    M("Montelucaste", "Comprimido 10mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="B c"),
    M("Loratadina", "Xarope 1mg/mL", "2–12 anos: até 30 kg 5 mL; acima de 30 kg 10 mL — 1 vez ao dia por 5 dias.", s="B c"),
    M("Desloratadina", "Comprimido 5mg", "Tomar 1 comprimido 1 vez ao dia por 5 dias.", "10 comprimidos", s="C c"),
    M("Fexofenadina", "Suspensão oral 6mg/mL", "2–11 anos: tomar 5 mL de 12 em 12 horas por 5 dias.", s="C c"),
    M("Fexofenadina", "Comprimido 120mg", "Tomar 1 comprimido 1 vez ao dia por 5 dias.", "10 comprimidos", s="C c"),
    M("Fexofenadina", "Comprimido 180mg", "Tomar 1 comprimido 1 vez ao dia por 5 dias.", "10 comprimidos", s="C c"),
    M("Cetirizina", "Comprimido 10mg", "Tomar 1 comprimido 1 vez ao dia por 5 dias.", "10 comprimidos", s="B c"),
    M("Levocetirizina", "Comprimido 5mg", "Tomar 1 comprimido 1 vez ao dia, à noite, por 5 dias.", "10 comprimidos", s="B c"),
    M("Bilastina", "Comprimido 20mg", "Tomar 1 comprimido 1 vez ao dia, em jejum, por 5 dias.", "10 comprimidos", s=" u"),
    M("Dexclorfeniramina", "Comprimido 2mg", "Tomar 1 comprimido de 8 em 8 horas por 5 dias. Pode causar sonolência.", "20 comprimidos", s="B u"),
    M("Dexclorfeniramina + Betametasona", "Xarope 0,4mg + 0,05mg/mL", "Adultos: 5 mL de 8 em 8 horas. Crianças 2–6 anos: 1,25 a 2,5 mL de 8 em 8 horas. Por 5 dias.", s="C u"),
    M("Hidroxizina", "Comprimido 25mg", "Tomar 1 comprimido de 8 em 8 horas se coceira. Pode causar sonolência.", "20 comprimidos", s="C u"),
    M("Prometazina", "Comprimido 25mg", "Tomar 1 comprimido à noite por 5 dias. Pode causar sonolência.", "20 comprimidos", s="C u"),

    # ---------- Estômago e intestino ----------
    M("Ondansetrona", "Comprimido orodispersível 8mg", "Dissolver 1 comprimido na boca de 8 em 8 horas se náuseas ou vômitos.", "10 comprimidos", route="Via sublingual", s="B c"),
    M("Bromoprida", "Solução oral gotas 4mg/mL", "Adultos: 50 gotas de 8 em 8 horas se náuseas.", ped=P(D, 0.2, 3, 4, 1, 10, drops=20, notes="Se náuseas ou vômitos. Antes das refeições."), s=" u"),
    M("Bromoprida", "Cápsula 10mg", "Tomar 1 cápsula de 8 em 8 horas, antes das refeições, se náuseas.", "20 cápsulas", s=" u"),
    M("Metoclopramida", "Comprimido 10mg", "Tomar 1 comprimido de 8 em 8 horas, antes das refeições, se náuseas.", "20 comprimidos", s="B c"),
    M("Domperidona", "Suspensão oral 1mg/mL", "Adultos: 10 mL de 8 em 8 horas, antes das refeições.", ped=P(D, 0.25, 3, 1, 1, 10, notes="15 a 30 minutos antes das refeições."), s=" c"),
    M("Domperidona", "Comprimido 10mg", "Tomar 1 comprimido de 8 em 8 horas, 15 a 30 minutos antes das refeições.", "30 comprimidos", s=" c"),
    M("Dimenidrinato + Piridoxina", "Solução oral gotas 25mg/mL", "Acima de 2 anos: tomar conforme peso de 6 em 6 horas se enjoo.", ped=P(D, 1.25, 4, 25, 1, 50, drops=20, notes="Se náuseas ou enjoo. Acima de 2 anos."), s="B c"),
    M("Dimenidrinato + Piridoxina", "Comprimido 50mg + 10mg", "Tomar 1 comprimido de 6 em 6 horas se náuseas ou enjoo.", "10 comprimidos", s="B c"),
    M("Omeprazol", "Cápsula 40mg", "Tomar 1 cápsula em jejum, 30 minutos antes do café da manhã.", "30 cápsulas", s="C c"),
    M("Pantoprazol", "Comprimido 40mg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã.", "30 comprimidos", s="B c"),
    M("Pantoprazol", "Comprimido 20mg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã.", "30 comprimidos", s="B c"),
    M("Esomeprazol", "Comprimido 40mg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã.", "28 comprimidos", s="C c"),
    M("Lansoprazol", "Cápsula 30mg", "Tomar 1 cápsula em jejum, 30 minutos antes do café da manhã.", "28 cápsulas", s="B c"),
    M("Famotidina", "Comprimido 40mg", "Tomar 1 comprimido à noite.", "30 comprimidos", s="B c"),
    M("Hidróxido de Alumínio + Hidróxido de Magnésio", "Suspensão oral", "Tomar 10 mL 1 hora após as refeições e ao deitar, se azia.", s=" c"),
    M("Simeticona", "Comprimido 40mg", "Tomar 1 comprimido de 8 em 8 horas, após as refeições, se gases.", "20 comprimidos", s="C c"),
    M("Escopolamina + Simeticona", "Cápsula 10mg + 80mg", "Tomar 1 cápsula de 8 em 8 horas se cólica ou gases.", "20 cápsulas", s="C c"),
    M("Lactulose", "Xarope 667mg/mL", "Adultos: 15 mL 1 a 2 vezes ao dia. Crianças: 1 a 2 mL/kg/dia (5 a 10 mL), ajustar conforme evacuações.", s="B c"),
    M("Macrogol 4000", "Pó para solução oral - envelope", "Dissolver 1 envelope em água e tomar 1 vez ao dia, ajustar conforme evacuações. Crianças: 0,4 a 0,8 g/kg/dia.", "10 envelopes", s="C c"),
    M("Bisacodil", "Comprimido 5mg", "Tomar 1 a 2 comprimidos à noite se constipação, no máximo 5 dias.", "20 comprimidos", s="B c"),
    M("Loperamida", "Comprimido 2mg", "Tomar 2 comprimidos e depois 1 após cada evacuação líquida (máx. 8 por dia). Não usar se febre ou sangue nas fezes.", "12 comprimidos", s="C c"),
    M("Racecadotrila", "Pó para suspensão oral - sachê 30mg", "Crianças acima de 13 kg: 1,5 mg/kg de 8 em 8 horas até parar a diarreia (máx. 7 dias). 13–27 kg: 1 sachê de 30 mg.", "16 sachês", s=" u"),
    M("Racecadotrila", "Cápsula 100mg", "Tomar 1 cápsula de 8 em 8 horas até parar a diarreia (máx. 7 dias).", "10 cápsulas", s=" u"),
    M("Saccharomyces boulardii", "Sachê/cápsula 200mg", "Tomar 1 sachê ou cápsula de 12 em 12 horas por 5 dias.", "10 unidades", s=" c"),
    M("Sulfato de Zinco", "Solução oral 4mg/mL", "Diarreia: menores de 6 meses 2,5 mL (10 mg); maiores de 6 meses 5 mL (20 mg) — 1 vez ao dia por 10 a 14 dias.", s=" c"),
    M("Trimebutina", "Cápsula 200mg", "Tomar 1 cápsula de 8 em 8 horas, antes das refeições.", "30 cápsulas", s=" u"),

    # ---------- Vitaminas e suplementos ----------
    M("Ácido Fólico", "Comprimido 5mg", "Tomar 1 comprimido 1 vez ao dia.", "30 comprimidos", s="A c"),
    M("Sulfato Ferroso", "Comprimido 40mg Fe", "Tomar 1 comprimido 1 vez ao dia, 30 minutos antes de uma refeição, com suco cítrico.", "30 comprimidos", s="A c"),
    M("Vitamina D3 (colecalciferol)", "Cápsula 7.000 UI", "Tomar 1 cápsula 1 vez por semana.", "8 cápsulas", s="A c"),
    M("Vitamina D3 (colecalciferol)", "Cápsula 50.000 UI", "Tomar 1 cápsula 1 vez por semana por 8 semanas.", "8 cápsulas", s="A c"),

    # ---------- Pressão e coração ----------
    M("Losartana Potássica", "Comprimido 25mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="D u", note=ARB),
    M("Losartana Potássica", "Comprimido 100mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="D u", note=ARB),
    M("Valsartana", "Comprimido 160mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="D u", note=ARB),
    M("Olmesartana Medoxomila", "Comprimido 20mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="D u", note=ARB),
    M("Enalapril", "Comprimido 10mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "Uso contínuo", s="D c", note=ARB),
    M("Enalapril", "Comprimido 20mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "Uso contínuo", s="D c", note=ARB),
    M("Captopril", "Comprimido 25mg", "Tomar 1 comprimido de 8 em 8 horas, uso contínuo.", "Uso contínuo", s="D c", note=ARB),
    M("Anlodipino", "Comprimido 5mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="C u"),
    M("Anlodipino", "Comprimido 10mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="C u"),
    M("Nifedipino Retard", "Comprimido 20mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "Uso contínuo", s="C c"),
    M("Hidroclorotiazida", "Comprimido 25mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "Uso contínuo", s="B c"),
    M("Clortalidona", "Comprimido 25mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "Uso contínuo", s="B u"),
    M("Indapamida", "Comprimido 1,5mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "Uso contínuo", s="B u"),
    M("Furosemida", "Comprimido 40mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "Uso contínuo", s="C u"),
    M("Espironolactona", "Comprimido 25mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="C c"),
    M("Atenolol", "Comprimido 50mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="D u"),
    M("Propranolol", "Comprimido 40mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "Uso contínuo", s="C c"),
    M("Carvedilol", "Comprimido 6,25mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "Uso contínuo", s="C u"),
    M("Carvedilol", "Comprimido 25mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "Uso contínuo", s="C u"),
    M("Succinato de Metoprolol", "Comprimido 50mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="C c"),
    M("Metildopa", "Comprimido 250mg", "Tomar 1 comprimido de 8 em 8 horas, uso contínuo.", "Uso contínuo", s="B c"),
    M("Ácido Acetilsalicílico", "Comprimido 100mg", "Tomar 1 comprimido após o almoço, uso contínuo.", "Uso contínuo", s="C c", note="Doses altas: evitar no 3º trimestre."),
    M("Clopidogrel", "Comprimido 75mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="B u"),
    M("Sinvastatina", "Comprimido 20mg", "Tomar 1 comprimido à noite, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),
    M("Sinvastatina", "Comprimido 40mg", "Tomar 1 comprimido à noite, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),
    M("Atorvastatina", "Comprimido 20mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),
    M("Atorvastatina", "Comprimido 40mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),
    M("Rosuvastatina", "Comprimido 10mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),
    M("Rosuvastatina", "Comprimido 20mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),

    # ---------- Diabetes, tireoide, outros crônicos ----------
    M("Metformina", "Comprimido 500mg", "Tomar 1 comprimido após o almoço e o jantar, uso contínuo.", "Uso contínuo", s="B c"),
    M("Metformina", "Comprimido 850mg", "Tomar 1 comprimido após o almoço e o jantar, uso contínuo.", "Uso contínuo", s="B c"),
    M("Metformina XR", "Comprimido de liberação prolongada 500mg", "Tomar 1 a 2 comprimidos após o jantar, uso contínuo.", "Uso contínuo", s="B c"),
    M("Glibenclamida", "Comprimido 5mg", "Tomar 1 comprimido antes do café da manhã, uso contínuo.", "Uso contínuo", s="C u"),
    M("Gliclazida MR", "Comprimido 60mg", "Tomar 1 comprimido no café da manhã, uso contínuo.", "Uso contínuo", s="C u"),
    M("Dapagliflozina", "Comprimido 10mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="C x", note="Não recomendada na gestação e na amamentação."),
    M("Empagliflozina", "Comprimido 25mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="C x", note="Não recomendada na gestação e na amamentação."),
    M("Sitagliptina", "Comprimido 100mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="B u"),
    M("Insulina Humana NPH", "Suspensão injetável 100 UI/mL", "Aplicar ___ UI subcutânea antes do café e ___ UI antes de dormir, uso contínuo.", "Uso contínuo", route="Via subcutânea", s="B c"),
    M("Insulina Humana Regular", "Solução injetável 100 UI/mL", "Aplicar ___ UI subcutânea 30 minutos antes das refeições, conforme glicemia.", "Uso contínuo", route="Via subcutânea", s="B c"),
    M("Levotiroxina Sódica", "Comprimido 25mcg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã, uso contínuo.", "Uso contínuo", s="A c"),
    M("Levotiroxina Sódica", "Comprimido 50mcg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã, uso contínuo.", "Uso contínuo", s="A c"),
    M("Levotiroxina Sódica", "Comprimido 75mcg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã, uso contínuo.", "Uso contínuo", s="A c"),
    M("Levotiroxina Sódica", "Comprimido 100mcg", "Tomar 1 comprimido em jejum, 30 minutos antes do café da manhã, uso contínuo.", "Uso contínuo", s="A c"),
    M("Alopurinol", "Comprimido 100mg", "Tomar 1 comprimido 1 vez ao dia, após refeição, uso contínuo.", "Uso contínuo", s="C u"),
    M("Aciclovir", "Comprimido 400mg", "Tomar 1 comprimido de 8 em 8 horas por 7 dias.", "21 comprimidos", s="B c"),
    M("Valaciclovir", "Comprimido 500mg", "Tomar 2 comprimidos de 12 em 12 horas por 7 dias.", "28 comprimidos", s="B c"),

    # ---------- Psiquiátricos e neurológicos (controle especial, 2 vias) ----------
    M("Escitalopram", "Comprimido 10mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="C c", ctrl=True),
    M("Citalopram", "Comprimido 20mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Paroxetina", "Comprimido 20mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="D u", ctrl=True, note="Evitar no 1º trimestre."),
    M("Sertralina", "Comprimido 25mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="C c", ctrl=True),
    M("Venlafaxina", "Cápsula de liberação prolongada 75mg", "Tomar 1 cápsula pela manhã, uso contínuo.", "30 cápsulas", s="C u", ctrl=True),
    M("Desvenlafaxina", "Comprimido 50mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Duloxetina", "Cápsula 30mg", "Tomar 1 cápsula pela manhã, uso contínuo.", "30 cápsulas", s="C u", ctrl=True),
    M("Bupropiona", "Comprimido de liberação prolongada 150mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Trazodona", "Comprimido 50mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Mirtazapina", "Comprimido 30mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Nortriptilina", "Cápsula 25mg", "Tomar 1 cápsula à noite, uso contínuo.", "30 cápsulas", s="D c", ctrl=True),
    M("Quetiapina", "Comprimido 25mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Quetiapina", "Comprimido 100mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Risperidona", "Comprimido 1mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Olanzapina", "Comprimido 5mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Aripiprazol", "Comprimido 10mg", "Tomar 1 comprimido pela manhã, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Haloperidol", "Comprimido 5mg", "Tomar 1 comprimido conforme orientação, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Carbonato de Lítio", "Comprimido 300mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo. Controlar litemia.", "60 comprimidos", s="D x", ctrl=True, note="Evitar no 1º trimestre."),
    M("Carbamazepina", "Comprimido 200mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "60 comprimidos", s="D c", ctrl=True),
    M("Ácido Valproico", "Cápsula 250mg", "Tomar 1 cápsula de 12 em 12 horas, uso contínuo.", "60 cápsulas", s="D u", ctrl=True, note="Evitar na gestação (risco de malformação)."),
    M("Divalproato de Sódio", "Comprimido 500mg", "Tomar 1 comprimido de 12 em 12 horas, uso contínuo.", "60 comprimidos", s="D u", ctrl=True, note="Evitar na gestação (risco de malformação)."),
    M("Topiramato", "Comprimido 25mg", "Tomar 1 comprimido à noite, uso contínuo.", "30 comprimidos", s="D u", ctrl=True),
    M("Lamotrigina", "Comprimido 25mg", "Tomar conforme esquema de aumento gradual, uso contínuo.", "30 comprimidos", s="C u", ctrl=True),
    M("Gabapentina", "Cápsula 300mg", "Tomar 1 cápsula à noite, uso contínuo.", "30 cápsulas", s="C u", ctrl=True),
    M("Pregabalina", "Cápsula 75mg", "Tomar 1 cápsula à noite, uso contínuo.", "30 cápsulas", s="C u", ctrl=True),

    # ---------- Pomadas e cremes ----------
    M("Mupirocina", "Pomada 2%", "Aplicar uma fina camada na lesão 3 vezes ao dia por 7 dias.", "1 bisnaga", route=TOP, s="B c"),
    M("Neomicina + Bacitracina", "Pomada 5mg + 250 UI/g", "Aplicar na lesão 3 vezes ao dia por 7 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Ácido Fusídico", "Creme 2%", "Aplicar na lesão 3 vezes ao dia por 7 dias.", "1 bisnaga", route=TOP, s=" c"),
    M("Sulfadiazina de Prata", "Creme 1%", "Aplicar na queimadura 1 a 2 vezes ao dia após limpeza, com curativo.", "1 bisnaga", route=TOP, s="B c", note="Evitar no final da gestação."),
    M("Dexametasona", "Creme 0,1%", "Aplicar uma fina camada na área afetada 2 vezes ao dia por 7 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Hidrocortisona (acetato)", "Creme 1%", "Aplicar uma fina camada na área afetada 2 vezes ao dia por 7 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Betametasona (valerato)", "Creme 0,1%", "Aplicar uma fina camada na área afetada 2 vezes ao dia por 7 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Furoato de Mometasona", "Creme 0,1%", "Aplicar uma fina camada na área afetada 1 vez ao dia por 7 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Propionato de Clobetasol", "Creme 0,05%", "Aplicar uma fina camada na área afetada 2 vezes ao dia por até 14 dias. Não usar no rosto.", "1 bisnaga", route=TOP, s="C c"),
    M("Cetoconazol", "Creme 2%", "Aplicar na área afetada 1 a 2 vezes ao dia por 14 a 28 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Cetoconazol", "Xampu 2%", "Aplicar no couro cabeludo, deixar 5 minutos e enxaguar, 2 vezes por semana por 4 semanas.", route=TOP, s="C c"),
    M("Clotrimazol", "Creme 1%", "Aplicar na área afetada 2 vezes ao dia por 14 a 28 dias.", "1 bisnaga", route=TOP, s="B c"),
    M("Miconazol", "Creme dermatológico 2%", "Aplicar na área afetada 2 vezes ao dia por 14 a 28 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Terbinafina", "Creme 1%", "Aplicar na área afetada 1 a 2 vezes ao dia por 14 dias.", "1 bisnaga", route=TOP, s="B c"),
    M("Nistatina + Óxido de Zinco", "Pomada 100.000 UI + 200mg/g", "Aplicar na área da fralda a cada troca, por 7 dias.", "1 bisnaga", route=TOP, s="C c"),
    M("Óxido de Zinco + Vitaminas A e D", "Pomada", "Aplicar na área da fralda a cada troca.", "1 bisnaga", route=TOP, s=" c"),
    M("Aciclovir", "Creme 5%", "Aplicar na lesão 5 vezes ao dia por 5 dias, desde os primeiros sintomas.", "1 bisnaga", route=TOP, s="B c"),
    M("Diclofenaco Dietilamônio", "Gel 11,6mg/g", "Aplicar na região dolorida 3 vezes ao dia, massageando, por 7 dias.", "1 bisnaga", route=TOP, s="C u", note=NSAID3),
    M("Lidocaína", "Gel 2%", "Aplicar no local antes do procedimento ou se dor, até 3 vezes ao dia.", "1 bisnaga", route=TOP, s="B c"),
    M("Calamina", "Loção", "Aplicar nas lesões 3 a 4 vezes ao dia se coceira.", route=TOP, s=" c"),

    # ---------- Oftalmológicos e otológicos ----------
    M("Tobramicina", "Colírio 0,3%", "Pingar 1 gota no olho afetado de 4 em 4 horas por 7 dias.", route=OFT, verb="Pingar", s="B c"),
    M("Tobramicina + Dexametasona", "Colírio 0,3% + 0,1%", "Pingar 1 gota no olho afetado de 6 em 6 horas por 7 dias.", route=OFT, verb="Pingar", s="C c"),
    M("Tobramicina", "Pomada oftálmica 0,3%", "Aplicar pequena quantidade no olho afetado de 8 em 8 horas por 7 dias.", "1 bisnaga", route=OFT, s="B c"),
    M("Ciprofloxacino", "Colírio 0,3%", "Pingar 1 gota no olho afetado de 4 em 4 horas por 7 dias.", route=OFT, verb="Pingar", s="C c"),
    M("Moxifloxacino", "Colírio 0,5%", "Pingar 1 gota no olho afetado de 8 em 8 horas por 7 dias.", route=OFT, verb="Pingar", s="C c"),
    M("Ofloxacino", "Colírio 0,3%", "Pingar 1 gota no olho afetado de 6 em 6 horas por 7 dias.", route=OFT, verb="Pingar", s="C c"),
    M("Olopatadina", "Colírio 0,1%", "Pingar 1 gota em cada olho de 12 em 12 horas.", route=OFT, verb="Pingar", s="C c"),
    M("Cetotifeno", "Colírio 0,025%", "Pingar 1 gota em cada olho de 12 em 12 horas.", route=OFT, verb="Pingar", s="C c"),
    M("Carmelose Sódica (lágrima artificial)", "Colírio 0,5%", "Pingar 1 gota em cada olho até 4 vezes ao dia.", route=OFT, verb="Pingar", s=" c"),
    M("Prednisolona (acetato)", "Colírio 1%", "Pingar 1 gota no olho afetado de 6 em 6 horas por 7 dias.", route=OFT, verb="Pingar", s="C c"),
    M("Dexametasona", "Colírio 0,1%", "Pingar 1 gota no olho afetado de 6 em 6 horas por 7 dias.", route=OFT, verb="Pingar", s="C c"),
    M("Retinol + Aminoácidos + Metionina + Cloranfenicol", "Pomada oftálmica", "Aplicar pequena quantidade no olho afetado 3 vezes ao dia por 7 dias.", "1 bisnaga", route=OFT, s=" u"),
    M("Timolol (maleato)", "Colírio 0,5%", "Pingar 1 gota em cada olho de 12 em 12 horas, uso contínuo.", route=OFT, verb="Pingar", s="C u"),
    M("Latanoprosta", "Colírio 0,005%", "Pingar 1 gota em cada olho à noite, uso contínuo.", route=OFT, verb="Pingar", s="C u"),
    M("Polimixina B + Neomicina + Hidrocortisona", "Solução otológica", "Pingar 3 a 4 gotas no ouvido afetado 3 vezes ao dia por 7 dias.", route=OTO, verb="Pingar", s="C c"),
    M("Ciprofloxacino + Hidrocortisona", "Solução otológica", "Pingar 3 gotas no ouvido afetado de 12 em 12 horas por 7 dias.", route=OTO, verb="Pingar", s="C c"),
]

LAB, IMG, CARD, END, OUT = "Laboratorial", "Imagem", "Cardiológico", "Endoscopia", "Outros"
JEJUM = "Jejum de 8 horas."
EXAMS = [Exam(name=n, category=c, preparation=p) for n, c, p in [
    ("VHS (velocidade de hemossedimentação)", LAB, ""),
    ("Hemoglobina glicada (HbA1c)", LAB, ""),
    ("Teste oral de tolerância à glicose (TOTG 75g)", LAB, JEJUM),
    ("Insulina de jejum", LAB, JEJUM),
    ("Colesterol total e frações", LAB, "Jejum de 8 a 12 horas (ou conforme o laboratório)."),
    ("Triglicerídeos", LAB, "Jejum de 8 a 12 horas (ou conforme o laboratório)."),
    ("Sódio", LAB, ""), ("Potássio", LAB, ""), ("Cálcio", LAB, ""), ("Magnésio", LAB, ""), ("Fósforo", LAB, ""),
    ("TGO (AST) e TGP (ALT)", LAB, ""), ("Gama-GT", LAB, ""), ("Fosfatase alcalina", LAB, ""),
    ("Bilirrubinas total e frações", LAB, ""), ("Proteínas totais e frações", LAB, ""),
    ("Amilase", LAB, ""), ("Lipase", LAB, ""), ("CPK", LAB, ""), ("Troponina", LAB, ""), ("DHL", LAB, ""),
    ("Ácido úrico", LAB, ""), ("Ferritina", LAB, ""), ("Ferro sérico e transferrina", LAB, ""),
    ("Vitamina B12", LAB, ""), ("Ácido fólico", LAB, ""), ("Vitamina D (25-OH)", LAB, ""),
    ("TSH", LAB, ""), ("T4 livre", LAB, ""), ("Anti-TPO", LAB, ""),
    ("Coagulograma (TP/INR e TTPa)", LAB, ""), ("Tipagem sanguínea ABO e fator Rh", LAB, ""), ("Coombs indireto", LAB, ""),
    ("Beta-hCG quantitativo", LAB, ""), ("PSA total e livre", LAB, "Evitar relação sexual e exercício de bicicleta 48 horas antes."),
    ("Anti-HIV 1 e 2", LAB, ""), ("VDRL", LAB, ""), ("HBsAg", LAB, ""), ("Anti-HBs", LAB, ""), ("Anti-HBc total", LAB, ""),
    ("Anti-HCV", LAB, ""), ("Toxoplasmose IgG e IgM", LAB, ""), ("Rubéola IgG e IgM", LAB, ""),
    ("Citomegalovírus IgG e IgM", LAB, ""), ("Dengue NS1, IgM e IgG", LAB, ""),
    ("Teste rápido COVID-19 (antígeno)", LAB, ""), ("Teste rápido para Influenza A e B", LAB, ""),
    ("Teste rápido para estreptococo (orofaringe)", LAB, ""), ("Cultura de orofaringe", LAB, ""),
    ("Monoteste (mononucleose)", LAB, ""), ("ASLO (antiestreptolisina O)", LAB, ""), ("Fator reumatoide", LAB, ""),
    ("FAN (fator antinuclear)", LAB, ""), ("Hemocultura (2 amostras)", LAB, ""), ("Gasometria arterial", LAB, ""),
    ("Reticulócitos", LAB, ""), ("Eletroforese de hemoglobina", LAB, ""),
    ("Relação albumina/creatinina em urina (microalbuminúria)", LAB, ""),
    ("Coprocultura", LAB, ""), ("Pesquisa de sangue oculto nas fezes", LAB, ""), ("Pesquisa de rotavírus nas fezes", LAB, ""),
    ("Leucócitos fecais", LAB, ""), ("Calprotectina fecal", LAB, ""),
    ("Cortisol basal", LAB, "Coleta pela manhã (até 8h)."), ("Prolactina", LAB, "Repouso de 30 minutos antes da coleta."),
    ("FSH e LH", LAB, ""), ("Estradiol", LAB, ""), ("Testosterona total", LAB, "Coleta pela manhã."),
    ("Citopatológico do colo uterino (Papanicolau)", LAB, "Evitar relação sexual, duchas e cremes vaginais 48 horas antes. Fora do período menstrual."),
    ("Raio-X de seios da face", IMG, ""), ("Raio-X de cavum", IMG, ""), ("Raio-X de abdome simples", IMG, ""),
    ("Raio-X de abdome agudo (3 incidências)", IMG, ""),
    ("Raio-X de coluna cervical", IMG, ""), ("Raio-X de coluna lombar", IMG, ""), ("Raio-X de bacia", IMG, ""),
    ("Raio-X de punho/mão", IMG, ""), ("Raio-X de joelho", IMG, ""), ("Raio-X de tornozelo/pé", IMG, ""),
    ("Ultrassonografia de abdome superior", IMG, "Jejum de 6 a 8 horas."),
    ("Ultrassonografia de rins e vias urinárias", IMG, "Bexiga cheia: beber 4 a 6 copos de água 1 hora antes e não urinar."),
    ("Ultrassonografia pélvica (via abdominal)", IMG, "Bexiga cheia: beber 4 a 6 copos de água 1 hora antes e não urinar."),
    ("Ultrassonografia transvaginal", IMG, "Esvaziar a bexiga antes do exame."),
    ("Ultrassonografia obstétrica", IMG, ""), ("Ultrassonografia morfológica", IMG, ""),
    ("Ultrassonografia de mamas", IMG, ""), ("Ultrassonografia de tireoide", IMG, ""),
    ("Ultrassonografia de partes moles", IMG, ""), ("Ultrassonografia de bolsa escrotal", IMG, ""),
    ("Doppler venoso de membros inferiores", IMG, ""), ("Mamografia bilateral", IMG, "Não usar desodorante, talco ou creme nas mamas e axilas no dia."),
    ("Densitometria óssea", IMG, ""),
    ("Tomografia de crânio", IMG, ""), ("Tomografia de tórax", IMG, ""),
    ("Tomografia de abdome e pelve", IMG, "Jejum de 4 horas se com contraste."), ("Tomografia de seios da face", IMG, ""),
    ("Ressonância magnética de crânio", IMG, ""), ("Ressonância magnética de coluna lombar", IMG, ""),
    ("Ressonância magnética de joelho", IMG, ""),
    ("Ecocardiograma transtorácico", CARD, ""), ("Teste ergométrico", CARD, "Ir com roupa e tênis confortáveis. Refeição leve 2 horas antes."),
    ("Holter 24 horas", CARD, ""), ("MAPA 24 horas", CARD, ""),
    ("Endoscopia digestiva alta", END, "Jejum de 8 horas."), ("Colonoscopia", END, "Preparo intestinal conforme orientação do serviço."),
    ("Espirometria (prova de função pulmonar)", OUT, "Não fumar 2 horas antes."), ("Eletroencefalograma", OUT, "Cabelos limpos e secos, sem creme."),
    ("Audiometria", OUT, "Evitar exposição a ruído intenso 14 horas antes."), ("Mapeamento de retina (fundo de olho)", OUT, "Ir acompanhado: as pupilas serão dilatadas."),
]]




# =====================================================================================
# Version 2: emergency / primary-care medications, exams and treatment protocols
# =====================================================================================
MEDS_V2 = [
    M("Dinitrato de Isossorbida", "Comprimido sublingual 5mg", "Colocar 1 comprimido sob a língua se dor no peito; pode repetir a cada 5 a 10 minutos (máx. 3 doses). Não usar se PA sistólica < 90 mmHg ou uso de sildenafila/tadalafila.", "3 comprimidos", route="Via sublingual", s="C u"),
    M("Atorvastatina", "Comprimido 80mg", "Tomar 1 comprimido 1 vez ao dia, uso contínuo.", "Uso contínuo", s="X x", note="Contraindicada na gestação."),
    M("Enoxaparina", "Solução injetável 40mg/0,4mL", "Aplicar 1 seringa subcutânea 1 vez ao dia (profilaxia).", "10 seringas", route="Via subcutânea", s="B c"),
    M("Enoxaparina", "Solução injetável 80mg/0,8mL", "Aplicar 1 mg/kg subcutânea de 12 em 12 horas (tratamento de TVP/TEP).", "20 seringas", route="Via subcutânea", s="B c"),
    M("Rivaroxabana", "Comprimido 15mg", "Tomar 1 comprimido de 12 em 12 horas, com alimento, por 21 dias.", "42 comprimidos", s="C x", note="Contraindicada na gestação e na amamentação."),
    M("Rivaroxabana", "Comprimido 20mg", "Após os 21 dias iniciais: tomar 1 comprimido 1 vez ao dia, com alimento, por no mínimo 3 meses.", "30 comprimidos", s="C x", note="Contraindicada na gestação e na amamentação."),
    M("Apixabana", "Comprimido 5mg", "Tomar 2 comprimidos de 12 em 12 horas por 7 dias; depois 1 comprimido de 12 em 12 horas, por no mínimo 3 meses.", "60 comprimidos", s="C x", note="Contraindicada na gestação e na amamentação."),
    M("Oseltamivir", "Cápsula 75mg", "Tomar 1 cápsula de 12 em 12 horas por 5 dias.", "10 cápsulas", s="C c"),
    M("Fenazopiridina", "Comprimido 200mg", "Tomar 1 comprimido de 8 em 8 horas por 2 dias se ardência ao urinar (deixa a urina alaranjada).", "6 comprimidos", s="B u"),
]

EXAMS_V2 = [Exam(name=n, category=c, preparation=p) for n, c, p in [
    ("D-dímero", LAB, ""),
    ("CK-MB", LAB, ""),
    ("Glicemia capilar", LAB, ""),
    ("Doppler de carótidas e vertebrais", IMG, ""),
    ("Tomografia de abdome sem contraste (protocolo litíase)", IMG, ""),
]]


def R(name, pres, instr="", qty=""):
    """Protocol item: medication (by name + presentation) with optional protocol-specific posology."""
    return (name, pres, instr, qty)


AAS, CLOPI, ATORVA80 = ("Ácido Acetilsalicílico", "Comprimido 100mg"), ("Clopidogrel", "Comprimido 75mg"), ("Atorvastatina", "Comprimido 80mg")
DIPI500, PARA750, PARA100 = ("Dipirona", "Comprimido 500mg"), ("Paracetamol", "Comprimido 750mg"), ("Paracetamol", "Suspensão oral 100mg/mL")
SFNASAL, AMOXSUSP = ("Cloreto de Sódio 0,9%", "Solução nasal"), ("Amoxicilina", "Suspensão oral 500mg/5mL")
DICLOGEL = ("Diclofenaco Dietilamônio", "Gel 11,6mg/g")

PROTOCOLS_V2 = [
    ("IAM / Dor torácica — conduta inicial", [
        R(*AAS, "Mastigar 3 comprimidos (300 mg) agora — dose de ataque.", "3 comprimidos"),
        R(*CLOPI, "Tomar 4 comprimidos (300 mg) agora — dose de ataque.", "4 comprimidos"),
        R("Dinitrato de Isossorbida", "Comprimido sublingual 5mg"),
        R(*ATORVA80, "Tomar 1 comprimido agora.", "1 comprimido"),
    ], "ECG em até 10 minutos. Acionar SAMU 192 e transferir para serviço com hemodinâmica/trombólise. Monitorizar, acesso venoso; oxigênio apenas se SatO2 < 90%. Morfina se dor refratária. Não usar nitrato se PAS < 90 mmHg, suspeita de IAM de VD ou uso de inibidor de PDE-5 nas últimas 24–48 h."),
    ("IAM — prevenção secundária (alta)", [
        R(*AAS), R(*CLOPI, "Tomar 1 comprimido 1 vez ao dia por 12 meses.", "30 comprimidos"), R(*ATORVA80),
        R("Succinato de Metoprolol", "Comprimido 50mg"), R("Enalapril", "Comprimido 10mg"), R("Pantoprazol", "Comprimido 40mg"),
    ], "Cessar tabagismo, dieta pobre em sal e gordura, atividade física orientada (reabilitação cardíaca). Retorno com cardiologista. Procurar emergência se dor no peito, falta de ar ou desmaio."),
    ("AVC isquêmico / AIT — prevenção secundária", [
        R(*AAS), R(*CLOPI, "AIT ou AVC menor: tomar 1 comprimido 1 vez ao dia por 21 dias, junto com o AAS; depois manter só o AAS.", "21 comprimidos"),
        R(*ATORVA80), R("Losartana Potássica", "Comprimido 50mg"),
    ], "SUSPEITA DE AVC AGUDO (fraqueza/dormência de um lado, boca torta, fala alterada): acionar SAMU 192 e encaminhar imediatamente ao hospital de referência — trombólise até 4,5 h do início dos sintomas. Verificar glicemia capilar. Não reduzir a PA na fase aguda, salvo > 220x120 mmHg. Controle de PA, glicemia e colesterol; cessar tabagismo."),
    ("Trombose venosa profunda (TVP)", [
        R("Rivaroxabana", "Comprimido 15mg"), R("Rivaroxabana", "Comprimido 20mg"), R(*PARA750, "Tomar 1 comprimido de 6 em 6 horas se dor.", "20 comprimidos"),
    ], "Confirmar com Doppler venoso. Elevar o membro e caminhar conforme tolerado; meia de compressão após melhora da dor. Na gestação, insuficiência renal grave ou sangramento: usar enoxaparina 1 mg/kg de 12 em 12 horas. Procurar emergência se falta de ar, dor no peito, tosse com sangue ou sangramentos (sinais de TEP)."),
    ("Urgência hipertensiva", [
        R("Captopril", "Comprimido 25mg", "Tomar 1 comprimido agora; reavaliar a PA em 60 minutos.", "1 comprimido"), R("Losartana Potássica", "Comprimido 50mg"),
    ], "Reduzir a PA de forma gradual em 24–48 h. Não usar nifedipino sublingual. Se houver lesão de órgão-alvo (dor no peito, falta de ar, déficit neurológico, confusão): emergência hipertensiva — encaminhar. Dieta com pouco sal e retorno para ajuste da medicação."),
    ("Dor na coluna — lombalgia aguda", [
        R("Ibuprofeno", "Comprimido 600mg"), R("Ciclobenzaprina", "Comprimido 5mg"),
        R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor.", "20 comprimidos"),
    ], "Manter as atividades leves e evitar repouso absoluto. Calor local 20 minutos, 3 vezes ao dia. Retornar se febre, perda de força, formigamento nas pernas, alteração para urinar/evacuar ou dor que não melhora em 4 semanas."),
    ("Lombociatalgia (dor que irradia para a perna)", [
        R("Prednisona", "Comprimido 20mg", "Tomar 2 comprimidos (40 mg) pela manhã, após o café, por 5 dias.", "10 comprimidos"),
        R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor.", "20 comprimidos"), R("Ciclobenzaprina", "Comprimido 5mg"),
    ], "Evitar repouso absoluto. Calor local. Procurar atendimento imediatamente se perda de força na perna, dormência na região genital ou alteração para urinar/evacuar."),
    ("Cervicalgia / torcicolo", [
        R("Diclofenaco Potássico", "Comprimido 50mg"), R("Ciclobenzaprina", "Comprimido 5mg"), R(*DICLOGEL),
    ], "Calor local 20 minutos, 3 vezes ao dia. Alongamentos leves. Evitar longos períodos no celular/computador sem pausa."),
    ("Dor no joelho / artrose", [
        R(*PARA750, "Tomar 1 comprimido de 8 em 8 horas se dor.", "20 comprimidos"), R(*DICLOGEL),
        R("Ibuprofeno", "Comprimido 400mg", "Tomar 1 comprimido de 8 em 8 horas, após as refeições, por até 5 dias se dor intensa.", "15 comprimidos"),
    ], "Gelo 20 minutos, 3 vezes ao dia nas crises. Fortalecimento da coxa (quadríceps) e fisioterapia. Perda de peso se sobrepeso. Retornar se inchaço importante, febre ou travamento do joelho."),
    ("Entorse / contusão", [
        R("Ibuprofeno", "Comprimido 600mg"), R(*PARA750, "Tomar 1 comprimido de 6 em 6 horas se dor.", "20 comprimidos"), R(*DICLOGEL),
    ], "Repouso relativo, gelo 20 minutos de 3 a 4 vezes ao dia nas primeiras 48–72 h, enfaixamento compressivo e elevação do membro. Retornar se não conseguir apoiar o pé ou piora do inchaço."),
    ("Cistite não complicada (fosfomicina)", [
        R("Fosfomicina Trometamol", "Granulado envelope 3g"), R("Fenazopiridina", "Comprimido 200mg"),
    ], "Beber bastante água e não segurar a urina. Retornar se febre, dor nas costas (lombar), vômitos ou se os sintomas não melhorarem em 48–72 h."),
    ("Cistite não complicada (nitrofurantoína)", [
        R("Nitrofurantoína", "Cápsula 100mg", "Tomar 1 cápsula de 6 em 6 horas por 5 dias.", "20 cápsulas"), R("Fenazopiridina", "Comprimido 200mg"),
    ], "Beber bastante água e não segurar a urina. Retornar se febre, dor nas costas (lombar), vômitos ou se os sintomas não melhorarem em 48–72 h."),
    ("Infecção urinária na gestante", [
        R("Cefalexina", "Cápsula 500mg"), R(*PARA750, "Tomar 1 comprimido de 6 em 6 horas se dor ou febre.", "20 comprimidos"),
    ], "Colher urocultura antes do tratamento e 7 dias após o término. Beber bastante água. Procurar a maternidade se febre, dor lombar, vômitos ou contrações."),
    ("Pielonefrite (tratamento ambulatorial)", [
        R("Ciprofloxacino", "Comprimido 500mg"), R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor ou febre.", "20 comprimidos"),
        R("Ondansetrona", "Comprimido orodispersível 8mg"),
    ], "Colher urocultura. Beber bastante água. Reavaliar em 48–72 h. Internar se vômitos persistentes, sinais de sepse, gestante ou sem melhora."),
    ("Pneumonia comunitária — adulto sem comorbidades", [
        R("Amoxicilina", "Cápsula 500mg"), R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor ou febre.", "20 comprimidos"),
    ], "Avaliar CRB-65 e saturação. Alternativa se alergia à penicilina: azitromicina 500 mg 1x/dia por 5 dias. Hidratação. Reavaliar em 48–72 h; retornar antes se falta de ar, confusão ou febre persistente."),
    ("Pneumonia comunitária — adulto com comorbidades", [
        R("Amoxicilina + Clavulanato", "Comprimido 875mg + 125mg"), R("Azitromicina", "Comprimido 500mg"),
        R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor ou febre.", "20 comprimidos"),
    ], "Avaliar CRB-65 e saturação (internar se SatO2 < 92%, confusão ou instabilidade). Hidratação. Reavaliar em 48–72 h."),
    ("Pneumonia — criança", [
        R(*AMOXSUSP), R(*PARA100),
    ], "Sinais de gravidade (tiragem, gemência, SatO2 < 92%, recusa alimentar, menor de 2 meses): encaminhar para internação. Reavaliar em 48 h. Manter hidratação e alimentação."),
    ("Síndrome gripal / Influenza — adulto", [
        R("Oseltamivir", "Cápsula 75mg"), R(*PARA750, "Tomar 1 comprimido de 6 em 6 horas se dor ou febre.", "20 comprimidos"), R(*SFNASAL),
    ], "Oseltamivir indicado para grupos de risco (gestantes, puérperas, idosos, crianças < 5 anos, doenças crônicas, imunossupressão) ou sinais de gravidade, de preferência até 48 h do início. Repouso e hidratação. Procurar atendimento se falta de ar, dor no peito, piora da febre após 3 dias ou confusão."),
    ("Síndrome gripal / Influenza — criança", [
        R("Oseltamivir", "Cápsula 30mg / 45mg / 75mg"), R(*PARA100), R(*SFNASAL),
    ], "Oseltamivir para menores de 5 anos ou com fator de risco. Hidratação e lavagem nasal. Retornar se respiração rápida, cansaço, lábios roxos, febre persistente ou recusa alimentar."),
    ("Resfriado comum", [
        R(*PARA750, "Tomar 1 comprimido de 6 em 6 horas se dor ou febre.", "20 comprimidos"), R(*SFNASAL), R("Loratadina", "Comprimido 10mg"),
    ], "Repouso, hidratação e lavagem nasal. Antibiótico não é necessário. Retornar se febre por mais de 3 dias ou falta de ar."),
    ("Sinusite bacteriana aguda", [
        R("Amoxicilina + Clavulanato", "Comprimido 875mg + 125mg"), R(*SFNASAL), R("Budesonida", "Spray nasal 64mcg/dose"),
    ], "Antibiótico se sintomas por mais de 10 dias, febre alta com secreção purulenta ou piora após melhora inicial. Lavagem nasal com soro várias vezes ao dia."),
    ("Otite média aguda — criança", [
        R(*AMOXSUSP), R(*PARA100),
    ], "Considerar 80–90 mg/kg/dia de amoxicilina em menores de 2 anos, creche ou uso recente de antibiótico. Não pingar nada no ouvido. Reavaliar em 48–72 h se febre ou dor persistirem."),
    ("Otite externa", [
        R("Polimixina B + Neomicina + Hidrocortisona", "Solução otológica"), R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor.", "20 comprimidos"),
    ], "Não molhar o ouvido durante o tratamento (usar algodão com vaselina no banho). Não usar cotonete."),
    ("Conjuntivite bacteriana", [
        R("Tobramicina", "Colírio 0,3%"), R("Carmelose Sódica (lágrima artificial)", "Colírio 0,5%"),
    ], "Limpar os olhos com soro fisiológico. Lavar as mãos com frequência e não compartilhar toalhas. Retornar se dor intensa, piora da visão ou sensibilidade à luz."),
    ("Conjuntivite alérgica", [
        R("Olopatadina", "Colírio 0,1%"), R("Carmelose Sódica (lágrima artificial)", "Colírio 0,5%"),
    ], "Compressas frias. Evitar coçar os olhos e contato com poeira e alérgenos."),
    ("Crise de asma — adulto (alta)", [
        R("Salbutamol", "Aerossol 100mcg/jato", "Inalar 2 a 4 jatos com espaçador de 4 em 4 horas por 48 h; depois se falta de ar ou chiado."),
        R("Prednisona", "Comprimido 20mg", "Tomar 2 comprimidos (40 mg) pela manhã, após o café, por 5 dias.", "10 comprimidos"),
        R("Beclometasona", "Aerossol oral 250mcg/dose"),
    ], "Técnica correta com espaçador. Evitar fumaça, poeira e mofo. Procurar emergência se falta de ar que não melhora com o salbutamol, dificuldade para falar ou lábios roxos."),
    ("Crise de asma / sibilância — criança", [
        R("Salbutamol", "Aerossol 100mcg/jato", "Inalar 1 jato para cada 2 a 3 kg (máx. 10 jatos) com espaçador a cada 20 minutos na 1ª hora; depois 2 a 4 jatos de 4 em 4 horas se chiado."),
        R("Prednisolona", "Solução oral 1mg/mL"),
    ], "Usar o espaçador com máscara. Procurar emergência se respiração rápida, afundamento das costelas, cansaço para mamar/falar ou lábios roxos."),
    ("Gastroenterite com vômitos — adulto", [
        R("Ondansetrona", "Comprimido orodispersível 8mg"), R("Sais para Reidratação Oral", "Pó para solução oral - envelope"),
        R("Saccharomyces boulardii", "Sachê/cápsula 200mg"),
    ], "Hidratação em pequenos goles frequentes. Dieta leve. Retornar se sangue nas fezes, febre alta, vômitos que impedem beber líquidos ou sinais de desidratação."),
    ("Dispepsia / gastrite", [
        R("Pantoprazol", "Comprimido 40mg"), R("Hidróxido de Alumínio + Hidróxido de Magnésio", "Suspensão oral"),
    ], "Evitar café, álcool, frituras, refrigerantes e anti-inflamatórios. Não deitar logo após as refeições. Retornar se vômitos com sangue, fezes escuras, perda de peso ou dificuldade para engolir."),
    ("Cólica renal", [
        R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor.", "20 comprimidos"), R("Diclofenaco Sódico", "Comprimido 50mg"),
        R("Butilbrometo de Escopolamina", "Comprimido 10mg"),
    ], "Beber bastante água. Retornar imediatamente se febre, vômitos persistentes, ausência de urina ou dor que não melhora com a medicação."),
    ("Enxaqueca / cefaleia", [
        R(*DIPI500, "Tomar 2 comprimidos no início da dor; repetir de 6 em 6 horas se necessário.", "20 comprimidos"),
        R("Naproxeno", "Comprimido 500mg"), R("Metoclopramida", "Comprimido 10mg"),
    ], "Repouso em ambiente escuro e silencioso, hidratação e sono regular. Evitar uso de analgésico mais de 10 dias por mês. Procurar emergência se pior dor da vida, febre com rigidez de nuca, déficit neurológico ou após trauma."),
    ("Rinite alérgica", [
        R("Loratadina", "Comprimido 10mg"), R("Furoato de Mometasona", "Spray nasal 50mcg/dose"), R(*SFNASAL),
    ], "Lavagem nasal diária. Evitar poeira, mofo, cheiros fortes e fumaça. Lavar roupas de cama semanalmente."),
    ("Urticária / reação alérgica leve", [
        R("Fexofenadina", "Comprimido 180mg"), R("Prednisona", "Comprimido 20mg"),
    ], "Evitar o possível causador. Procurar emergência imediatamente se inchaço nos lábios/língua, falta de ar ou tontura."),
    ("Escabiose (sarna)", [
        R("Permetrina", "Loção 5%"), R("Hidroxizina", "Comprimido 25mg"), R("Ivermectina", "Comprimido 6mg"),
    ], "Tratar todos os moradores da casa ao mesmo tempo. Lavar roupas de cama e de uso com água quente e passar a ferro; o que não puder ser lavado, guardar em saco fechado por 3 dias."),
    ("Pediculose (piolho)", [
        R("Permetrina", "Loção capilar 1%"),
    ], "Passar pente fino diariamente por 10 a 14 dias. Lavar roupas de cama, toucas e escovas. Examinar os outros moradores."),
    ("Herpes zoster", [
        R("Valaciclovir", "Comprimido 500mg", "Tomar 2 comprimidos (1 g) de 8 em 8 horas por 7 dias.", "42 comprimidos"),
        R(*PARA750, "Tomar 1 comprimido de 6 em 6 horas se dor.", "20 comprimidos"),
    ], "Iniciar de preferência até 72 h do aparecimento das lesões. Manter as lesões limpas e secas. Evitar contato com gestantes e imunossuprimidos. Retornar se lesões perto do olho."),
    ("Candidíase vaginal", [
        R("Fluconazol", "Cápsula 150mg"), R("Miconazol", "Creme vaginal 2%"),
    ], "Usar roupas íntimas de algodão, evitar duchas vaginais. Na gestação usar apenas o creme vaginal."),
    ("Vaginose bacteriana", [
        R("Metronidazol", "Comprimido 250mg"),
    ], "Não ingerir bebida alcoólica durante o tratamento e até 24 h após. Alternativa: metronidazol gel vaginal por 7 dias."),
    ("Celulite / erisipela", [
        R("Cefalexina", "Cápsula 500mg", "Tomar 1 cápsula de 6 em 6 horas por 10 dias.", "40 cápsulas"),
        R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor ou febre.", "20 comprimidos"),
    ], "Manter o membro elevado. Marcar com caneta a borda da vermelhidão para acompanhar. Retornar em 48 h ou antes se a vermelhidão aumentar, febre alta ou bolhas."),
    ("Impetigo", [
        R("Mupirocina", "Pomada 2%"),
    ], "Lavar as lesões com água e sabão e remover as crostas antes de aplicar. Cortar as unhas. Lesões extensas: considerar cefalexina."),
    ("Dengue — sem sinais de alarme (grupo A)", [
        R(*DIPI500, "Tomar 2 comprimidos de 6 em 6 horas se dor ou febre.", "20 comprimidos"),
        R("Sais para Reidratação Oral", "Pó para solução oral - envelope"),
    ], "Hidratação: 60 mL/kg/dia (1/3 com soro de reidratação). NÃO usar AAS nem anti-inflamatórios (ibuprofeno, diclofenaco, nimesulida). Retornar imediatamente se dor abdominal intensa, vômitos persistentes, sangramentos, tontura ou sonolência — principalmente quando a febre baixar."),
    ("Parasitose intestinal", [
        R("Albendazol", "Comprimido 400mg"),
    ], "Lavar bem as mãos e os alimentos, beber água filtrada ou fervida, manter as unhas curtas. Tratar os demais moradores se necessário."),
]

EXAM_GROUPS_V2 = [
    ("Dor torácica / SCA", ["Eletrocardiograma", "Troponina", "CK-MB", "Hemograma completo", "Ureia e Creatinina", "Sódio", "Potássio", "Coagulograma (TP/INR e TTPa)", "Glicemia de jejum", "Raio-X de tórax PA e perfil"]),
    ("AVC", ["Tomografia de crânio", "Glicemia capilar", "Hemograma completo", "Coagulograma (TP/INR e TTPa)", "Ureia e Creatinina", "Sódio", "Potássio", "Eletrocardiograma", "Perfil lipídico", "Hemoglobina glicada (HbA1c)", "Doppler de carótidas e vertebrais", "Ecocardiograma transtorácico"]),
    ("TVP / TEP", ["Doppler venoso de membros inferiores", "D-dímero", "Hemograma completo", "Coagulograma (TP/INR e TTPa)", "Ureia e Creatinina", "TGO (AST) e TGP (ALT)"]),
    ("Pneumonia", ["Raio-X de tórax PA e perfil", "Hemograma completo", "Proteína C reativa (PCR)", "Ureia e Creatinina", "Sódio", "Potássio"]),
    ("Pielonefrite", ["Urina tipo 1 (EAS)", "Urocultura com antibiograma", "Hemograma completo", "Proteína C reativa (PCR)", "Ureia e Creatinina", "Ultrassonografia de rins e vias urinárias"]),
    ("Cólica renal", ["Urina tipo 1 (EAS)", "Ureia e Creatinina", "Hemograma completo", "Ultrassonografia de rins e vias urinárias", "Tomografia de abdome sem contraste (protocolo litíase)"]),
    ("Dengue", ["Hemograma completo", "Dengue NS1, IgM e IgG", "TGO (AST) e TGP (ALT)", "Ureia e Creatinina"]),
    ("Dor no joelho", ["Raio-X de joelho", "VHS (velocidade de hemossedimentação)", "Proteína C reativa (PCR)", "Ácido úrico"]),
    ("Lombalgia com sinais de alerta", ["Raio-X de coluna lombar", "Hemograma completo", "VHS (velocidade de hemossedimentação)", "Proteína C reativa (PCR)", "Urina tipo 1 (EAS)"]),
    ("Hipertensão — avaliação inicial", ["Glicemia de jejum", "Perfil lipídico", "Ureia e Creatinina", "Potássio", "Ácido úrico", "Urina tipo 1 (EAS)", "Relação albumina/creatinina em urina (microalbuminúria)", "Eletrocardiograma"]),
    ("Diabetes — acompanhamento", ["Glicemia de jejum", "Hemoglobina glicada (HbA1c)", "Perfil lipídico", "Ureia e Creatinina", "Relação albumina/creatinina em urina (microalbuminúria)", "Urina tipo 1 (EAS)", "TGO (AST) e TGP (ALT)", "Mapeamento de retina (fundo de olho)"]),
    ("Pré-natal — 1º trimestre", ["Hemograma completo", "Tipagem sanguínea ABO e fator Rh", "Coombs indireto", "Glicemia de jejum", "Urina tipo 1 (EAS)", "Urocultura com antibiograma", "Anti-HIV 1 e 2", "VDRL", "HBsAg", "Anti-HCV", "Toxoplasmose IgG e IgM", "Rubéola IgG e IgM", "TSH", "Ultrassonografia obstétrica"]),
]


# =====================================================================================
# Version 3: ready-made medical report (laudo) templates for sick leave
# =====================================================================================
_INTRO = "Declaro, para fins de comprovação junto ao empregador e/ou à Previdência Social, que o(a) paciente {NOME}, {IDADE}, portador(a) do documento {DOCUMENTO}, encontra-se sob meus cuidados médicos"
_FIM = ("\n\nDiante do exposto, o(a) paciente encontra-se temporariamente incapacitado(a) para suas atividades laborais habituais, "
        "necessitando de afastamento por {DIAS} dias a partir de {DATA}, podendo ser prorrogado conforme evolução clínica.\n\nCID-10: {CID}")


def T(name, cat, cid, days, clinical):
    return ReportTemplate(name=name, category=cat, cid=cid, days=days, body=f"{_INTRO}, {clinical}{_FIM}")


REPORT_TEMPLATES_V3 = [
    T("Lombalgia aguda / lombociatalgia", "Coluna", "M54.5", 7,
      "apresentando quadro de dor lombar intensa, com irradiação para membro inferior, limitação importante da mobilidade e piora aos esforços, à flexão do tronco e à permanência prolongada em pé ou sentado(a). Em tratamento com analgésicos, anti-inflamatórios, relaxante muscular e orientação de fisioterapia."),
    T("Hérnia de disco lombar", "Coluna", "M51.1", 30,
      "com diagnóstico de hérnia de disco lombar com radiculopatia, confirmada por exame de imagem, apresentando dor lombar com irradiação, parestesia em membro inferior e limitação funcional para carregar peso, agachar e permanecer longos períodos na mesma posição. Em tratamento clínico medicamentoso e fisioterapia, com acompanhamento especializado."),
    T("Cervicalgia / cervicobraquialgia", "Coluna", "M54.2", 5,
      "apresentando dor cervical intensa com contratura muscular e irradiação para membro superior, com limitação da rotação e flexão do pescoço e piora com atividades que exigem esforço ou posição fixa da cabeça. Em tratamento medicamentoso e fisioterápico."),
    T("Episódio depressivo", "Saúde mental", "F32.1", 30,
      "em tratamento de episódio depressivo, apresentando humor deprimido, anedonia, alteração do sono e do apetite, fadiga, redução da concentração e da capacidade de tomada de decisões, com prejuízo significativo do desempenho ocupacional. Em uso de medicação antidepressiva, com indicação de acompanhamento psicoterápico."),
    T("Transtorno de ansiedade", "Saúde mental", "F41.1", 15,
      "em tratamento de transtorno de ansiedade, apresentando ansiedade persistente, inquietação, tensão muscular, insônia, irritabilidade e crises de taquicardia e sensação de falta de ar, com prejuízo da concentração e do desempenho das atividades laborais. Em tratamento medicamentoso e com indicação de psicoterapia."),
    T("Síndrome de burnout (esgotamento profissional)", "Saúde mental", "Z73.0", 30,
      "apresentando quadro compatível com síndrome de esgotamento profissional (burnout), com exaustão física e emocional, distanciamento mental do trabalho, insônia, cefaleia, irritabilidade e redução da eficácia profissional, relacionados ao ambiente de trabalho. Em tratamento medicamentoso e psicoterápico."),
    T("Fratura — imobilização", "Ortopedia / trauma", "S62.6", 30,
      "vítima de trauma com fratura confirmada por exame radiológico, em tratamento com imobilização, apresentando dor, edema e impossibilidade de uso funcional do segmento acometido. Necessita de repouso do membro e de reavaliação ortopédica com novo exame de imagem para liberação."),
    T("Entorse com lesão ligamentar", "Ortopedia / trauma", "S93.4", 10,
      "apresentando entorse com lesão ligamentar, com dor, edema e limitação para apoio e deambulação. Em tratamento com imobilização, analgesia, crioterapia e elevação do membro, com indicação de fisioterapia após a fase aguda."),
    T("Pós-operatório", "Ortopedia / trauma", "Z48.8", 30,
      "submetido(a) a procedimento cirúrgico, encontrando-se em período de recuperação pós-operatória, com restrição de esforços físicos, de carregar peso e de atividades que comprometam a cicatrização e a recuperação funcional. Em acompanhamento ambulatorial com retornos programados."),
    T("Tendinite / LER-DORT", "Membros superiores", "M65.9", 15,
      "apresentando quadro de tenossinovite/tendinite em membro superior, relacionado a esforços repetitivos, com dor, edema, perda de força e limitação para movimentos repetitivos, de preensão e de carregar peso. Em tratamento medicamentoso, com imobilização relativa e fisioterapia."),
    T("Bursite de ombro", "Membros superiores", "M75.5", 10,
      "apresentando bursite de ombro, com dor intensa à mobilização, limitação da elevação e rotação do membro superior e piora com atividades acima da linha dos ombros. Em tratamento medicamentoso e fisioterápico."),
    T("Síndrome do túnel do carpo", "Membros superiores", "G56.0", 15,
      "com diagnóstico de síndrome do túnel do carpo, apresentando parestesia e dor em território do nervo mediano, perda de força de preensão e piora noturna e com movimentos repetitivos do punho. Em tratamento com órtese, medicação e fisioterapia, com avaliação especializada."),
    T("Cardiopatia / pós-infarto", "Clínicos graves", "I25.2", 60,
      "portador(a) de cardiopatia isquêmica, com antecedente de infarto agudo do miocárdio, em reabilitação cardíaca e uso contínuo de medicações, com limitação para esforços físicos moderados a intensos e situações de estresse. Em acompanhamento cardiológico."),
    T("AVC com sequela", "Clínicos graves", "I69.4", 90,
      "com antecedente de acidente vascular cerebral, apresentando sequelas motoras e/ou de linguagem que limitam a execução das atividades laborais habituais. Em reabilitação com fisioterapia, fonoaudiologia e acompanhamento neurológico."),
    T("Diabetes descompensado", "Clínicos graves", "E11.6", 15,
      "portador(a) de diabetes mellitus em descompensação, com hiperglicemia persistente e sintomas associados, necessitando de ajuste terapêutico, controle glicêmico frequente e adequação alimentar, com risco de complicações agudas no momento."),
    T("Câncer em tratamento", "Clínicos graves", "C80.9", 90,
      "em tratamento oncológico (cirurgia, quimioterapia e/ou radioterapia), apresentando efeitos adversos como fadiga intensa, náuseas, imunossupressão e queda do estado geral, que impedem o exercício das atividades laborais durante o tratamento. Em acompanhamento oncológico."),
    T("Gestação de alto risco", "Clínicos graves", "O09.9", 30,
      "gestante, em acompanhamento de pré-natal de alto risco, apresentando condição clínica que exige repouso relativo, redução de esforços físicos e de longas jornadas, e consultas e exames frequentes, para preservação da saúde materna e fetal."),
]


async def _add_report_templates(items: list[ReportTemplate]) -> int:
    n = 0
    for t in items:
        if not await db.report_templates.find_one({"name": t.name}, {"_id": 1}):
            await db.report_templates.insert_one(t.model_dump())
            n += 1
    return n


_R = "Paciente {NOME}, {IDADE}, encaminhado(a) "
_G_COMUM = "Levar este encaminhamento, documento com foto, Cartão SUS e comprovante de endereço.\nLevar exames anteriores e a lista dos medicamentos em uso."
_G_ESPEC = _G_COMUM + "\nProcurar a UBS/regulação do seu município para agendar a consulta com o especialista.\nManter o uso das medicações prescritas até a avaliação."
_G_PS = "Em caso de piora (falta de ar, dor no peito, desmaio, fraqueza em um lado do corpo, sangramento importante, febre persistente), procurar o pronto-socorro imediatamente ou ligar 192 (SAMU)."


def RT(name, specialty, destination, reason, guidance):
    return ReferralTemplate(name=name, specialty=specialty, destination=destination, reason=_R + reason, guidance=guidance)


REFERRAL_TEMPLATES_V4 = [
    RT("UBS — acompanhamento hipertensão/diabetes", "Clínica Médica / Saúde da Família", "Unidade Básica de Saúde (UBS) de referência",
       "para acompanhamento ambulatorial contínuo de hipertensão arterial e/ou diabetes mellitus, com controle pressórico/glicêmico, renovação de receitas e solicitação de exames de rotina.",
       _G_COMUM + "\nProcurar a UBS do seu bairro nos próximos dias para agendar consulta e entrar no programa HIPERDIA.\nNão interromper os medicamentos.\nReduzir sal, açúcar e alimentos industrializados; praticar atividade física conforme orientação.\n" + _G_PS),
    RT("UBS — continuidade do cuidado após atendimento", "Clínica Médica / Saúde da Família", "Unidade Básica de Saúde (UBS) de referência",
       "atendido(a) nesta unidade em {DATA}, para continuidade do cuidado, reavaliação clínica e acompanhamento do quadro.",
       _G_COMUM + "\nProcurar a UBS em até 7 dias para reavaliação.\nSeguir a receita entregue nesta consulta.\n" + _G_PS),
    RT("UBS — pré-natal", "Saúde da Mulher / Pré-natal", "Unidade Básica de Saúde (UBS) de referência",
       "gestante, para início/continuidade do acompanhamento de pré-natal, solicitação dos exames do pré-natal e atualização vacinal.",
       _G_COMUM + "\nLevar a Caderneta da Gestante, se já tiver.\nIniciar/manter o ácido fólico conforme orientação.\nProcurar a maternidade em caso de sangramento, perda de líquido, dor em cólica forte, febre, dor de cabeça intensa, inchaço súbito ou diminuição dos movimentos do bebê."),
    RT("UBS — puericultura e vacinas", "Pediatria / Saúde da Criança", "Unidade Básica de Saúde (UBS) de referência",
       "para acompanhamento de puericultura (crescimento e desenvolvimento) e atualização do calendário vacinal.",
       "Levar a Caderneta da Criança, Cartão SUS e documento do responsável.\nManter aleitamento materno conforme orientação.\nProcurar atendimento se a criança apresentar febre alta persistente, dificuldade para respirar, recusa alimentar, vômitos repetidos ou sonolência excessiva."),
    RT("UBS — curativo / retirada de pontos", "Enfermagem", "Unidade Básica de Saúde (UBS) de referência",
       "para realização de curativos diários e/ou retirada de pontos conforme orientação.",
       "Levar este encaminhamento e o Cartão SUS.\nManter o local limpo e seco; lavar com água e sabão e não aplicar produtos caseiros.\nRetirada de pontos em ___ dias.\nProcurar atendimento se houver vermelhidão que aumenta, pus, calor local, febre ou abertura dos pontos."),
    RT("Cardiologia", "Cardiologia", "Ambulatório de Especialidades — Cardiologia",
       "para avaliação cardiológica, por apresentar ",
       _G_ESPEC + "\nLevar eletrocardiograma e exames de sangue recentes, se tiver.\n" + _G_PS),
    RT("Ortopedia", "Ortopedia", "Ambulatório de Especialidades — Ortopedia",
       "para avaliação ortopédica, por apresentar dor/limitação em ",
       _G_ESPEC + "\nLevar radiografias e laudos de exames de imagem realizados.\nEvitar esforço e carregar peso com o membro acometido até a avaliação."),
    RT("Neurologia", "Neurologia", "Ambulatório de Especialidades — Neurologia",
       "para avaliação neurológica, por apresentar ",
       _G_ESPEC + "\nAnotar a frequência e as características das crises/sintomas (diário) para mostrar ao especialista.\n" + _G_PS),
    RT("Oftalmologia", "Oftalmologia", "Ambulatório de Especialidades — Oftalmologia",
       "para avaliação oftalmológica, por apresentar ",
       _G_ESPEC + "\nLevar óculos em uso e receitas de óculos anteriores.\nProcurar pronto atendimento em caso de perda súbita da visão, dor intensa no olho ou trauma ocular."),
    RT("Otorrinolaringologia", "Otorrinolaringologia", "Ambulatório de Especialidades — Otorrinolaringologia",
       "para avaliação otorrinolaringológica, por apresentar ",
       _G_ESPEC + "\nNão introduzir cotonetes ou objetos no ouvido.\nLevar audiometria ou exames anteriores, se tiver."),
    RT("Dermatologia", "Dermatologia", "Ambulatório de Especialidades — Dermatologia",
       "para avaliação dermatológica, por apresentar lesão de pele ",
       _G_ESPEC + "\nNão aplicar produtos caseiros sobre a lesão.\nUsar protetor solar diariamente e evitar exposição ao sol das 10h às 16h."),
    RT("Ginecologia", "Ginecologia e Obstetrícia", "Ambulatório de Especialidades — Ginecologia",
       "para avaliação ginecológica, por apresentar ",
       _G_ESPEC + "\nLevar preventivo (Papanicolau), ultrassonografias e mamografias anteriores.\nAnotar a data da última menstruação."),
    RT("Urologia", "Urologia", "Ambulatório de Especialidades — Urologia",
       "para avaliação urológica, por apresentar ",
       _G_ESPEC + "\nLevar exames de urina, PSA e ultrassonografias, se tiver.\nBeber bastante água, salvo orientação contrária.\nProcurar o pronto-socorro em caso de retenção urinária, dor intensa ou febre com calafrios."),
    RT("Endocrinologia", "Endocrinologia", "Ambulatório de Especialidades — Endocrinologia",
       "para avaliação endocrinológica, por apresentar ",
       _G_ESPEC + "\nLevar exames de glicemia, hemoglobina glicada, TSH/T4 livre e ultrassonografia de tireoide, se tiver.\nSe usar insulina, levar o registro das glicemias."),
    RT("Gastroenterologia", "Gastroenterologia", "Ambulatório de Especialidades — Gastroenterologia",
       "para avaliação gastroenterológica, por apresentar ",
       _G_ESPEC + "\nLevar endoscopias, colonoscopias e ultrassonografias anteriores.\nProcurar o pronto-socorro em caso de vômito com sangue, fezes pretas ou com sangue, ou dor abdominal intensa."),
    RT("Pneumologia", "Pneumologia", "Ambulatório de Especialidades — Pneumologia",
       "para avaliação pneumológica, por apresentar ",
       _G_ESPEC + "\nLevar radiografias de tórax, espirometria e as bombinhas em uso.\nEvitar fumar e exposição a fumaça e poeira.\n" + _G_PS),
    RT("Nefrologia", "Nefrologia", "Ambulatório de Especialidades — Nefrologia",
       "para avaliação nefrológica, por apresentar alteração de função renal ",
       _G_ESPEC + "\nLevar exames de creatinina, ureia, urina e ultrassonografia de rins, se tiver.\nEvitar anti-inflamatórios sem orientação médica."),
    RT("Cirurgia Geral", "Cirurgia Geral", "Ambulatório de Especialidades — Cirurgia Geral",
       "para avaliação cirúrgica, por apresentar ",
       _G_ESPEC + "\nLevar ultrassonografias e exames de imagem realizados.\nProcurar o pronto-socorro em caso de dor abdominal intensa, vômitos persistentes, febre ou endurecimento/dor em hérnia."),
    RT("Psiquiatria / CAPS", "Psiquiatria", "CAPS / Ambulatório de Saúde Mental",
       "para avaliação e acompanhamento em saúde mental, por apresentar ",
       _G_ESPEC + "\nComparecer acompanhado(a) de um familiar, se possível.\nNão interromper medicações por conta própria.\nEm caso de pensamentos de se machucar, procurar o pronto-socorro ou ligar 188 (CVV) / 192 (SAMU)."),
    RT("Psicologia", "Psicologia", "Serviço de Psicologia / UBS",
       "para acompanhamento psicológico (psicoterapia), por apresentar ",
       _G_COMUM + "\nProcurar a UBS ou o serviço de psicologia do município para agendar.\nEm caso de crise, procurar o pronto-socorro ou ligar 188 (CVV)."),
    RT("Fisioterapia", "Fisioterapia", "Serviço de Fisioterapia",
       "para avaliação e tratamento fisioterápico (___ sessões), devido a ",
       _G_COMUM + "\nLevar exames de imagem realizados.\nUsar roupas confortáveis nas sessões.\nFazer os exercícios orientados também em casa."),
    RT("Nutrição", "Nutrição", "Serviço de Nutrição / UBS",
       "para avaliação e acompanhamento nutricional, devido a ",
       _G_COMUM + "\nLevar exames de sangue recentes.\nAnotar o que come em 3 dias da semana para mostrar ao nutricionista."),
    RT("Pronto-Socorro / urgência", "Pronto-Socorro", "Pronto-Socorro / Hospital de referência",
       "para avaliação de urgência, por apresentar ",
       "Dirigir-se IMEDIATAMENTE ao pronto-socorro, de preferência acompanhado(a).\nLevar este encaminhamento, documento com foto e Cartão SUS.\nNão comer nem beber até a avaliação, salvo orientação.\nEm caso de piora no caminho, ligar 192 (SAMU)."),
]


async def _add_referral_templates(items: list[ReferralTemplate]) -> int:
    n = 0
    for t in items:
        if not await db.referral_templates.find_one({"name": t.name}, {"_id": 1}):
            await db.referral_templates.insert_one(t.model_dump())
            n += 1
    return n


# ---------- application ----------
async def _add_meds(items: list[Medication]) -> int:
    n = 0
    for m in items:
        if not await db.medications.find_one({"name": m.name, "presentation": m.presentation}, {"_id": 1}):
            await db.medications.insert_one(m.model_dump())
            n += 1
    return n


async def _add_exams(items: list[Exam]) -> int:
    n = 0
    for e in items:
        if not await db.exams.find_one({"name": e.name}, {"_id": 1}):
            await db.exams.insert_one(e.model_dump())
            n += 1
    return n


async def _add_protocols(protocols) -> int:
    n = 0
    for name, items, notes in protocols:
        if await db.rx_templates.find_one({"name": name}, {"_id": 1}):
            continue
        ids, overrides = [], {}
        for mname, pres, instr, qty in items:
            m = await db.medications.find_one({"name": mname, "presentation": pres}, {"_id": 0, "id": 1})
            if not m or m["id"] in ids:
                continue  # removed by the doctor
            ids.append(m["id"])
            if instr or qty:
                overrides[m["id"]] = RxItemOverride(instructions=instr, quantity=qty)
        if ids:
            await db.rx_templates.insert_one(RxTemplate(name=name, medication_ids=ids, notes=notes, overrides=overrides).model_dump())
            n += 1
    return n


async def _add_exam_groups(groups) -> int:
    n = 0
    for name, exam_names in groups:
        if await db.exam_groups.find_one({"name": name}, {"_id": 1}):
            continue
        ids = []
        for en in exam_names:
            e = await db.exams.find_one({"name": en}, {"_id": 0, "id": 1})
            if e:
                ids.append(e["id"])
        if ids:
            await db.exam_groups.insert_one(ExamGroup(name=name, exam_ids=ids).model_dump())
            n += 1
    return n


def CP(field, name, text):
    return ClinicalPhrase(field=field, name=name, text=text)


CLINICAL_PHRASES_V5 = [
    CP("history", "Nega comorbidades", "Nega comorbidades, alergias medicamentosas e uso de medicações contínuas."),
    CP("history", "Nega outras queixas", "Nega febre, vômitos, diarreia ou outras queixas."),
    CP("history", "Sintomas gripais", "Refere tosse, coriza e dor de garganta há ___ dias. Nega falta de ar."),
    CP("history", "Dor", "Refere dor em ___ há ___ dias, intensidade ___/10, sem fatores de melhora."),
    CP("history", "Sintomas urinários", "Refere ardência para urinar, aumento da frequência e urgência miccional há ___ dias. Nega febre e dor lombar."),
    CP("history", "Vacinas em dia", "Vacinação em dia, conforme informação/caderneta."),
    CP("history", "Sem medicação prévia", "Não fez uso de medicações antes da consulta."),
    CP("physical_exam", "Exame normal (completo)",
       "BEG, LOTE, corado(a), hidratado(a), acianótico(a), anictérico(a), afebril.\nAC: RCR em 2T, BNF, sem sopros.\nAR: MV presente bilateralmente, sem ruídos adventícios.\nAbdome: plano, flácido, RHA+, indolor à palpação, sem massas ou visceromegalias.\nMMII: sem edemas, panturrilhas livres."),
    CP("physical_exam", "Sinais vitais", "PA: ___ mmHg | FC: ___ bpm | FR: ___ irpm | Tax: ___ °C | SatO2: ___% | Glicemia: ___ mg/dL"),
    CP("physical_exam", "Estado geral", "BEG, LOTE, corado(a), hidratado(a), acianótico(a), anictérico(a), afebril."),
    CP("physical_exam", "Cardíaco", "AC: RCR em 2T, BNF, sem sopros."),
    CP("physical_exam", "Pulmonar", "AR: MV presente bilateralmente, sem ruídos adventícios, sem esforço respiratório."),
    CP("physical_exam", "Abdome", "Abdome: plano, flácido, RHA+, indolor à palpação, sem sinais de irritação peritoneal."),
    CP("physical_exam", "Orofaringe", "Oroscopia: hiperemia de orofaringe, sem placas ou exsudato."),
    CP("physical_exam", "Otoscopia", "Otoscopia: membranas timpânicas íntegras e brilhantes, sem abaulamentos bilateralmente."),
    CP("physical_exam", "Neurológico", "Neuro: Glasgow 15, pupilas isocóricas e fotorreagentes, sem déficits focais."),
    CP("physical_exam", "Membros", "MMII: sem edemas, panturrilhas livres, pulsos presentes e simétricos."),
    CP("conduct", "Sintomáticos + alarme", "Prescritos sintomáticos. Orientado(a) sobre sinais de alarme e a retornar se houver piora."),
    CP("conduct", "Medicado no serviço", "Realizada medicação no serviço, com melhora dos sintomas. Alta com orientações."),
    CP("conduct", "Exames e retorno", "Solicitados exames. Retorno com os resultados."),
    CP("conduct", "Orientações gerais", "Orientado(a) quanto a hidratação, repouso e uso correto das medicações."),
    CP("conduct", "Encaminhado", "Encaminhado(a) para avaliação especializada."),
    CP("conduct", "Atestado", "Fornecido atestado médico."),
    CP("conduct", "Reavaliar", "Reavaliar em ___ dias ou antes, se piora."),
]


async def _add_clinical_phrases(items: list[ClinicalPhrase]) -> int:
    n = 0
    for t in items:
        if not await db.clinical_phrases.find_one({"name": t.name, "field": t.field}, {"_id": 1}):
            await db.clinical_phrases.insert_one(t.model_dump())
            n += 1
    return n


async def apply_catalog() -> dict:
    """Apply each catalog version not applied yet (idempotent; never edits or re-adds what exists)."""
    s = await db.settings.find_one({"key": "main"}, {"_id": 0, "catalog_version": 1}) or {}
    done = int(s.get("catalog_version") or 0)
    added = {"medications": 0, "exams": 0, "protocols": 0, "exam_groups": 0}
    if done >= CATALOG_VERSION:
        return added
    if done < 1:
        added["medications"] += await _add_meds(MEDS)
        added["exams"] += await _add_exams(EXAMS)
        # fix of the original sample: ibuprofeno 50 mg/mL has 20 gotas/mL (1 gota = 2,5 mg), not 10
        await db.medications.update_many(
            {"name": "Ibuprofeno", "presentation": "Suspensão oral gotas 50mg/mL", "drops_per_ml": 10}, {"$set": {"drops_per_ml": 20}}
        )
    if done < 2:
        added["medications"] += await _add_meds(MEDS_V2)
        added["exams"] += await _add_exams(EXAMS_V2)
        added["protocols"] += await _add_protocols(PROTOCOLS_V2)
        added["exam_groups"] += await _add_exam_groups(EXAM_GROUPS_V2)
    if done < 3:
        added["report_templates"] = await _add_report_templates(REPORT_TEMPLATES_V3)
    if done < 4:
        added["referral_templates"] = await _add_referral_templates(REFERRAL_TEMPLATES_V4)
    if done < 5:
        added["clinical_phrases"] = await _add_clinical_phrases(CLINICAL_PHRASES_V5)
    await db.settings.update_one({"key": "main"}, {"$set": {"catalog_version": CATALOG_VERSION}}, upsert=True)
    if FILE_MODE:
        from lib import filestore

        await filestore.save(["medications", "exams", "rx_templates", "exam_groups", "report_templates", "referral_templates", "clinical_phrases", "settings"])
    return added
