@echo off
chcp 65001 >nul
title MedDrive - nao feche esta janela
cd /d "%~dp0"
echo Iniciando o MedDrive... aguarde, o navegador vai abrir.
"%~dp0python\python.exe" "%~dp0app\run_portable.py"
if errorlevel 1 (
  echo.
  echo Ocorreu um erro ao iniciar. Veja a mensagem acima.
  pause
)
